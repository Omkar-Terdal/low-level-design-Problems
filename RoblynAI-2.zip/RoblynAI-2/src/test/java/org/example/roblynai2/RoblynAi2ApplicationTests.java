package org.example.roblynai2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoblynAi2ApplicationTests {

	@Test
	void contextLoads() {
	}

}

package org.example.roblynai2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoblynAi2Application {

	public static void main(String[] args) {
		SpringApplication.run(RoblynAi2Application.class, args);
	}

}

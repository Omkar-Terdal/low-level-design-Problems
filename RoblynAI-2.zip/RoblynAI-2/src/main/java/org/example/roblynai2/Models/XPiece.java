package org.example.roblynai2.Models;

import org.example.roblynai2.Enums.PieceType;

public class XPiece extends PlayingPiece{

	public XPiece() {
		super(PieceType.X);
	}
}

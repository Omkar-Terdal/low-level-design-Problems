package org.example.roblynai2.Enums;

public enum PieceType {
	X,O
}

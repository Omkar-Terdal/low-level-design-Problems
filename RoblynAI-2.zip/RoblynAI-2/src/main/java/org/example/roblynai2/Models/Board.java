package org.example.roblynai2.Models;

public class Board {
	private final int size;
	private final Cell[][] cells;
	private int occupiedCells=0;

	public Board(int size) {
		this.size = size;
		this.cells = new Cell[size][size];
	}

	public boolean placePiece(int row,int col,PlayingPiece piece) {
		if (row < 0 || row >= size || col < 0 || col >= size) {
			return false;
		}
		if(!cells[row][col].isEmpty()) {
			return false;
		}
		cells[row][col].setPlayingPiece(piece);
		occupiedCells++;
		return true;

	}



	public boolean checkWinner(int row,int col){
		PlayingPiece piece = cells[row][col].getPlayingPiece();

		if(piece==null) {
			return false;
		}

		return checkRow(row,piece) || checkColumn(col,piece) || checkDiagonal(piece) || checkAntiDiagonal(piece);
	}

	private boolean checkRow(int row, PlayingPiece piece) {


		for(int col=0; col<size; col++){
			if(cells[row][col].getPlayingPiece()==null || cells[row][col].getPlayingPiece().getType()!=piece.getType()) {
				return false;
			}

		}
		return true;
	}

	private boolean checkColumn(int col, PlayingPiece piece) {

		for(int row=0; row<size; row++){
			if(cells[row][col].getPlayingPiece()==null ||cells[row][col].getPlayingPiece().getType()!=piece.getType()){
				return false;
			}
		}
		return true;
	}

	private boolean checkDiagonal(PlayingPiece piece) {
		int digCount=0;
		for(int i=0; i<size; i++){

			if(cells[i][i].getPlayingPiece()==null ||  cells[i][i].getPlayingPiece().getType()!=piece.getType()){
				return false;
			}
			digCount++;
		}
		return digCount==WinningThreshold? true:false;
	}

	private boolean checkAntiDiagonal(PlayingPiece piece) {
		//0 3-1-0= 0,2
		for(int i=0; i<size; i++) {
			if (cells[i][size - 1 - i].getPlayingPiece() == null || cells[i][size - 1 - i].getPlayingPiece().getType() != piece.getType()) {

				return false;
				}
			}
		return true;
	}

	public boolean isFull(){
		return occupiedCells==size*size;
	}


}

















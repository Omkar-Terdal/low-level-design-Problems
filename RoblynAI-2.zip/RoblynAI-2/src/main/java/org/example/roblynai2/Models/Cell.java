package org.example.roblynai2.Models;

public class Cell {

	private PlayingPiece playingPiece;

	public boolean isEmpty() {
		return playingPiece == null;
	}

	public void setPlayingPiece(PlayingPiece playingPiece) {
		this.playingPiece = playingPiece;
	}

	public PlayingPiece getPlayingPiece() {
		return playingPiece;
	}

}

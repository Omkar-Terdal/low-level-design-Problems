package org.example.roblynai2.Models;

import org.example.roblynai2.Enums.PieceType;

public class OPiece extends PlayingPiece {

	public OPiece(PieceType type) {
		super(PieceType.O);
	}
}

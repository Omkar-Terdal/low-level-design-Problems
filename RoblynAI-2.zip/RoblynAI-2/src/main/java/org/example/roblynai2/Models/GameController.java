package org.example.roblynai2.Models;

import java.sql.SQLOutput;
import java.util.LinkedList;
import java.util.Queue;

public class GameController {
	private final Board board;
	private final Queue<Player> players;

	GameController(Board board,Player p1,Player p2) {
		this.board = board;
		players=new LinkedList<>();
		players.add(p1);
		players.add(p2);
	}
	public void play(int row,int col){
		Player currentPlayer=players.poll();

		boolean placed=board.placePiece(row,col,currentPlayer.getPlayingPiece());

		if(!placed){
			System.out.println("Invalid Move");
		}

		if(board.checkWinner(row,col)){
			System.out.println(currentPlayer.getName()+ "Is Winner");
			return;
		}

		if(board.isFull()){
			System.out.println(currentPlayer.getName()+ "Game is Draw!");
			return;
		}
		players.add(currentPlayer);

	}
}

package org.example.roblynai2.Models;

import org.example.roblynai2.Enums.PieceType;

public class PlayingPiece {

	private final PieceType piece;

	PlayingPiece(PieceType piece) {
		this.piece=piece;
	}

	public PieceType getType() {
		return piece;
	}
}

package org.example.roblynai;

import ch.qos.logback.core.net.SyslogOutputStream;

import java.util.HashMap;
import java.util.Map;

public class RateLimiter {

	private static final int MAX_REQUESTS=10;
	private static final int BUCKET_SIZE=60;
	private int startTime=0;

	private Map<String,Integer> requestedCount=new HashMap<>();

	private boolean allowedRequest(String userId,int timeStamp){

		if(timeStamp>=startTime+BUCKET_SIZE){
			startTime=startTime+BUCKET_SIZE;
			requestedCount.clear();
		}


		int count=requestedCount.getOrDefault(userId,0);
		if(count>=MAX_REQUESTS){
			return false;
		}
		requestedCount.put(userId,count+1);
		return true;
	}

	public static void main(String[] args) {

		RateLimiter limiter=new RateLimiter();
		for(int i=0; i<75; i++){
			System.out.println("Sameer"+ limiter.allowedRequest("sameer",i));
		}

	}
}

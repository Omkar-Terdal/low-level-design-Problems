package org.example.roblynai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoblynAiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoblynAiApplication.class, args);
	}

}

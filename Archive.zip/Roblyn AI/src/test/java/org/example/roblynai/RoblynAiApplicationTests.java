package org.example.roblynai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoblynAiApplicationTests {

	@Test
	void contextLoads() {
	}

}

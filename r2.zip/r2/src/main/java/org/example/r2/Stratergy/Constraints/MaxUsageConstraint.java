package org.example.r2.Stratergy.Constraints;

import org.example.r2.Models.Cart;
import org.example.r2.Models.Coupon;
import org.example.r2.Models.User;
import org.example.r2.Models.ValidationResult;
import org.example.r2.Repository.CouponUsageRepository;

public class MaxUsageConstraint implements Constraints{
	private int maxCount;
	private CouponUsageRepository couponUsageRepository;


	public MaxUsageConstraint(CouponUsageRepository couponUsageRepository, int maxCount) {
		this.couponUsageRepository = couponUsageRepository;
		this.maxCount = maxCount;
	}

	@Override
	public ValidationResult validate(User user, Cart cart, Coupon coupon){
		int userUsageCount= couponUsageRepository.getCouponUsageCount(coupon.getCouponId());
		if(userUsageCount>maxCount){
			return  ValidationResult.failure("\"Coupon usage limit exceeded for this user.\"");
		}
		return ValidationResult.success();
	}
}

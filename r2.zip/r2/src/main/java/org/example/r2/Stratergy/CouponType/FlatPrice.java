package org.example.r2.Stratergy.CouponType;

import org.example.r2.Models.Cart;

public class FlatPrice implements CouponType{
	private double discountAmount;

	public FlatPrice(double discountAmount) {
		this.discountAmount = discountAmount;
	}
	@Override
	public double calculateDiscount(Cart cart) {
		return Math.min(cart.getTotalAmount(), discountAmount);
	}

}

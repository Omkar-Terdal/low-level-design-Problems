package org.example.r2.Models;

import java.util.List;

public class Cart {
	private List<CartItem> cartItemList;
	private Coupon coupon;

	public Cart(List<CartItem> cartItemList) {
		this.cartItemList = cartItemList;
	}
	public List<CartItem> getCartItemList() {
		return cartItemList;
	}
	public Coupon getCoupon() {
		return coupon;
	}
	public double getTotalAmount() {

		double total = 0;

		for (CartItem cartItem : cartItemList) {
			total += cartItem.getProduct().getPrice()
					* cartItem.getQuantity();
		}

		return total;
	}

}

package org.example.r2.Stratergy.Constraints;

import org.example.r2.Models.Cart;
import org.example.r2.Models.Coupon;
import org.example.r2.Models.User;
import org.example.r2.Models.ValidationResult;

public interface Constraints {
	ValidationResult validate(User user, Cart cart, Coupon coupon);

}

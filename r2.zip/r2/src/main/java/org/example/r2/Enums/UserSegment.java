package org.example.r2.Enums;

public enum UserSegment {
	GOLD,
	DIAMOND,
	PREMIUM

}

package org.example.r2.Repository;

public interface CouponUsageRepository {

	int getUserUsageCount(String couponId, String userId);

	int getCouponUsageCount(String couponId);

	void incrementUserUsageCount(String couponId, String userId);
}

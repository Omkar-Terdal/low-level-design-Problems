package org.example.r2.Stratergy.ApplicabilityRules;

import org.example.r2.Enums.UserSegment;
import org.example.r2.Models.Cart;
import org.example.r2.Models.CartItem;
import org.example.r2.Models.User;

import java.util.Set;

public class productRule implements ApplicabilityRules {
	private Set<Long> allowedProductIds;

	public productRule(Set<Long> productIds) {
		this.allowedProductIds = productIds;
	}

	public boolean isApplicable(User user, Cart cart) {
		for (CartItem cartItem:cart.getCartItemList()) {
			if(allowedProductIds.contains(cartItem.getProduct().getProductId())){
				return true;
			}
		}
		return false;
	}
}

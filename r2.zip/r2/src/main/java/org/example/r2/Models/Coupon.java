package org.example.r2.Models;

import org.example.r2.Stratergy.ApplicabilityRules.ApplicabilityRules;
import org.example.r2.Stratergy.Constraints.Constraints;
import org.example.r2.Stratergy.CouponType.CouponType;

import java.util.List;

public class Coupon {

	private String couponId;
	private String couponName;
	private String couponDescription;
	private CouponType couponType;
	private List<ApplicabilityRules> applicabilityRulesllList;
	private List<Constraints> constraintsList;

	public Coupon(CouponType couponType, String couponName, String couponId, String couponDescription,List<ApplicabilityRules> applicabilityRulesllList, List<Constraints> constraintsList) {
		this.couponType = couponType;
		this.couponName = couponName;
		this.couponId = couponId;
		this.couponDescription = couponDescription;
		this.applicabilityRulesllList = applicabilityRulesllList;
		this.constraintsList = constraintsList;
	}
	public String getCouponId() {
		return couponId;
	}

	public String getCouponDescription() {
		return couponDescription;
	}

	public String getCouponName() {
		return couponName;
	}

	public List<ApplicabilityRules> getApplicabilityRulesllList() {
		return applicabilityRulesllList;
	}

	public List<Constraints> getConstraintsList() {
		return constraintsList;
	}

	public CouponType getCouponType() {
		return couponType;
	}
}

package org.example.r2.Stratergy.CouponType;

import org.example.r2.Models.Cart;

public interface CouponType {
	double calculateDiscount(Cart cart);
}

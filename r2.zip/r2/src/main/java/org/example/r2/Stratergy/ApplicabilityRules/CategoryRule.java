package org.example.r2.Stratergy.ApplicabilityRules;

import org.example.r2.Models.Cart;
import org.example.r2.Models.CartItem;
import org.example.r2.Models.User;

import java.util.Set;

public class CategoryRule implements ApplicabilityRules{
	private Set<String> allowedCategory;
	public CategoryRule(Set<String> allowedCategory) {
		this.allowedCategory = allowedCategory;
	}
	@Override
	public boolean isApplicable(User user, Cart cart) {
		for(CartItem cartItem:cart.getCartItemList()){
			if(allowedCategory.contains(cartItem.getProduct().getCategory())){
				return true;
			}
		}
		return false;
	}
}


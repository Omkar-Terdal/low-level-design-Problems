package org.example.r2.Stratergy.Constraints;

import org.example.r2.Models.Cart;
import org.example.r2.Models.Coupon;
import org.example.r2.Models.User;
import org.example.r2.Models.ValidationResult;

import java.time.LocalDate;

public class DateRangeConstraint implements Constraints{
	private LocalDate startDate;
	private LocalDate endDate;
	public DateRangeConstraint(LocalDate startDate, LocalDate endDate) {
		this.startDate = startDate;
		this.endDate = endDate;
	}

	@Override
	public ValidationResult validate(User user, Cart cart, Coupon coupon){
		LocalDate currentDate = LocalDate.now();
		if(currentDate.isBefore(startDate) || currentDate.isAfter(endDate)){
			return ValidationResult.failure("Start date must be before end date");
		}
		return ValidationResult.success();
	}
}

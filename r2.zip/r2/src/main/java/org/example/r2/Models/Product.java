package org.example.r2.Models;

public class Product {
	private String productId;
	private String productName;
	private String category;
	private Double price;

	public Product(String category, Double price, String productId, String productName) {
		this.category = category;
		this.price = price;
		this.productId = productId;
		this.productName = productName;
	}

	public String getCategory() {
		return category;
	}

	public Double getPrice() {
		return price;
	}

	public String getProductId() {
		return productId;
	}

	public String getProductName() {
		return productName;
	}
}

package org.example.r2.Stratergy.ApplicabilityRules;

import org.example.r2.Enums.UserSegment;
import org.example.r2.Models.Cart;
import org.example.r2.Models.CartItem;
import org.example.r2.Models.User;

import java.util.List;
import java.util.Set;

public class UserSegmentRule implements ApplicabilityRules{
	private Set<UserSegment> allowedUserSegment;

	public UserSegmentRule(Set<UserSegment> allowedUserSegment) {
		this.allowedUserSegment = allowedUserSegment;
	}

	@Override
	public boolean isApplicable(User user, Cart cart) {

	return allowedUserSegment.contains(user.getUserSegment());
	}
}

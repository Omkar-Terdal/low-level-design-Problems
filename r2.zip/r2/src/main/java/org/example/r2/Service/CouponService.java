package org.example.r2.Service;

import org.example.r2.Models.*;
import org.example.r2.Repository.CouponUsageRepository;
import org.example.r2.Stratergy.ApplicabilityRules.ApplicabilityRules;
import org.example.r2.Stratergy.Constraints.Constraints;



public class CouponService {
	private CouponUsageRepository couponUsageRepository;

	public CouponService(CouponUsageRepository couponUsageRepository) {
		this.couponUsageRepository = couponUsageRepository;
	}

	public CouponResult applyCoupon(Coupon coupon, User user, Cart cart) {
		for(ApplicabilityRules rule:coupon.getApplicabilityRulesllList()){
			if(!rule.isApplicable(user,cart)){
				return CouponResult.failure(
						"Coupon is not applicable."
				);
			}
		}

		for(Constraints constraint :coupon.getConstraintsList()){
			if(!constraint.validate(user,cart,coupon).isSuccess()){
				return  CouponResult.failure("Constraint violated.");
			}
		}

		double discount=coupon.getCouponType().calculateDiscount(cart);

		double finalAmount=cart.getTotalAmount()-discount;

		couponUsageRepository.incrementUserUsageCount(coupon.getCouponId(),user.getUserID());

		return CouponResult.success(discount,finalAmount);

	}
}

package org.example.r2.Stratergy.Constraints;

import org.example.r2.Models.*;

public class MinimumCartValueConstraint implements Constraints{
	private double minimumCartValue;
	public MinimumCartValueConstraint(double minimumCartValue){
		this.minimumCartValue = minimumCartValue;
	}

	@Override
	public ValidationResult validate(User user, Cart cart, Coupon coupon){
		double cartTotalValue = 0.0;

		for(CartItem cartItem : cart.getCartItemList()){
			cartTotalValue+=cartItem.getProduct().getPrice() * cartItem.getQuantity();
		}

		if(cartTotalValue < minimumCartValue){
			return ValidationResult.failure("Cart value is less than minimum cart value");
		}
		return ValidationResult.success();
	}
}

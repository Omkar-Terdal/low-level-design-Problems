package org.example.r2.Stratergy.ApplicabilityRules;

import org.example.r2.Models.Cart;
import org.example.r2.Models.User;

public interface ApplicabilityRules {
	boolean isApplicable(User user, Cart cart);

}

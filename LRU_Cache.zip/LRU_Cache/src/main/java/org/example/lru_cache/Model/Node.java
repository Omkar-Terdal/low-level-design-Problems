package org.example.lru_cache.Model;

public class Node<K,V> {
	private K key;
	private V value;
	public Node<K,V> next;
	public Node<K,V> prev;

	public Node (K key, V value) {
		this.key = key;
		this.value = value;
	}
	public K getKey() {
		return key;
	}

	public Node<K, V> setKey(K key) {
		this.key = key;
		return this;
	}

	public V getValue() {
		return value;
	}

	public Node<K, V> setValue(V value) {
		this.value = value;
		return this;
	}


}

package org.example.lru_cache.DataStructure;

import org.example.lru_cache.Model.Node;

public class DoublyLinkedList <K,V>{
	private Node<K,V> head;
	private Node<K,V> tail;
	public DoublyLinkedList(){
		this.head = new Node<>(null,null);
		this.tail = new Node<>(null,null);
		head.next=tail;
		tail.prev=head;
	}

	public void  addToHead(Node<K,V> node){
		node.next=head.next;
		node.prev=head;
		head.next.prev=node;
		head.next=node;
	}

	public void removeNode(Node<K,V> node){
		node.prev.next = node.next;
		node.next.prev=node.prev;
		node.prev = null;
		node.next = null;
	}

	public void moveToHead(Node<K,V> node){
		removeNode(node);
		addToHead(node);
	}

	public Node<K,V> removeFromTail(){
		if(tail.prev==head)return null;

		Node<K,V> temp=tail.prev;
		removeNode(temp);
		return temp;
	}

	public void clear() {
		head.next = tail;
		tail.prev = head;
	}
	public Node<K,V> getHead(){
		return head;
	}
	public Node<K,V> getTail(){
		return tail;
	}


}
//    N
 // H - T
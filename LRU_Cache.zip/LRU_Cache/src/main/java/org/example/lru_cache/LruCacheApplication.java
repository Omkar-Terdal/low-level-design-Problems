package org.example.lru_cache;

import org.example.lru_cache.DataStructure.DoublyLinkedList;
import org.example.lru_cache.LRUCache.Cache;
import org.example.lru_cache.Model.Node;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LruCacheApplication {

	public static void main(String[] args) {

		Cache<Integer, String> cache=new Cache<>(5);

		cache.put(1,"Omkar");
		cache.put(2,"Prateek");
		cache.put(3,"anurag");

//		System.out.println("Get Cache "+ cache.get(1));

		cache.put(4,"okm");
		cache.put(5,"omomkm");

		System.out.println("Get Cache "+ cache.get(1));  // most recent accessed

		cache.put(6,"onnn");

		System.out.println("Get Cache "+ cache.get(3));
		cache.put(3,"updated");
		System.out.println("Get Cache "+ cache.get(3));


	}

}

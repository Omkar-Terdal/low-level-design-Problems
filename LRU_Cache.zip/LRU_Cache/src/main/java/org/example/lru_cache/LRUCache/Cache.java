package org.example.lru_cache.LRUCache;

import org.example.lru_cache.DataStructure.DoublyLinkedList;
import org.example.lru_cache.Model.Node;

import java.util.HashMap;
import java.util.Map;

public class Cache<K,V> {
	private final int capacity;
	private final DoublyLinkedList<K,V> nodeList;
	private final Map<K, Node<K,V>> nodeMap;

	private int hits=0;
	private int misses=0;


	public Cache(int capacity) {
		this.capacity = capacity;
		this.nodeList = new DoublyLinkedList<>();
		this.nodeMap = new HashMap<>();
	}

	//get
	public synchronized V get(K key) {

		Node<K,V> node = nodeMap.get(key);

		if (node == null) {
			misses++;
			return null;
		}

		hits++;

		nodeList.moveToHead(node);

		return node.getValue();
	}


	public synchronized void put(K key, V value){
		if(nodeMap.containsKey(key)){
			Node<K,V> node = nodeMap.get(key);
			node.setValue(value);
			nodeList.moveToHead(node);
		}else{
			if (nodeMap.size() >= capacity) {
				Node<K,V> newNode = nodeList.removeFromTail();
				if(newNode!=null){
					nodeMap.remove(newNode.getKey());
				}
			}
			Node<K,V> node = new Node<>(key, value);
			nodeList.addToHead(node);
			nodeMap.put(key, node);
		}
	}
	public synchronized void clear() {
		nodeMap.clear();
		nodeList.clear();
	}



	@Override
	public String toString() {
		return "Cache{" +
				", nodeMap=" + nodeMap +
				'}';
	}
}

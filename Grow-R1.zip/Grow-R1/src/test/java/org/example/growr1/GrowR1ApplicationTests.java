package org.example.growr1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrowR1ApplicationTests {

	@Test
	void contextLoads() {
	}

}

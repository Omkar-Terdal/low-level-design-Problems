package org.example.growr1.Enums;

public enum BrokerPlan {
	REGULAR,
	PRO,
	ULTRA
}

package org.example.growr1;

import org.example.growr1.Enums.BrokerPlan;
import org.example.growr1.Enums.TradeAction;
import org.example.growr1.Enums.TradeType;
import org.example.growr1.Models.ChargeBreakdown;
import org.example.growr1.Models.Trade;
import org.example.growr1.Service.BrokerageService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GrowR1Application {

	public static void main(String[] args) {
		Trade trade1=new Trade("T1", TradeType.EQUITY_DELIVERY, TradeAction.SELL,100000.0);
		Trade trade2=new Trade("T2", TradeType.EQUITY_INTRADAY, TradeAction.BUY,200000.0);

		BrokerageService brokerageService=new BrokerageService();
		ChargeBreakdown result=brokerageService.calculateCharges(trade1, BrokerPlan.REGULAR);

		System.out.println("Trade ID: "+ trade1.getTradeId());
		System.out.println("Trade Type: "+ trade1.getTradeType());
		System.out.println("Trade Action: "+ trade1.getTradeAction());
		System.out.println("Plan: "+ BrokerPlan.REGULAR);


		System.out.println(result);

		ChargeBreakdown result2=brokerageService.calculateCharges(trade2,BrokerPlan.ULTRA);

		System.out.println(result2);

	}

}

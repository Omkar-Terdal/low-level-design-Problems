package org.example.growr1.Enums;

public enum TradeType {
	EQUITY_DELIVERY,
	EQUITY_INTRADAY,
	FNO
}

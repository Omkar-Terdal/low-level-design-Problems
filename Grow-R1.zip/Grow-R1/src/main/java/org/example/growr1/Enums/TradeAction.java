package org.example.growr1.Enums;

public enum TradeAction {
	BUY,
	SELL
}

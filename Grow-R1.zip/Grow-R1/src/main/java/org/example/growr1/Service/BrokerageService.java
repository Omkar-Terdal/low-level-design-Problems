package org.example.growr1.Service;

import org.example.growr1.Enums.BrokerPlan;
import org.example.growr1.Models.AdditionalChargesCalculator;
import org.example.growr1.Models.BrokerageCalculator;
import org.example.growr1.Models.ChargeBreakdown;
import org.example.growr1.Models.Trade;

public class BrokerageService {
	private BrokerageCalculator brokerageCalculator;
	private AdditionalChargesCalculator additionalChargesCalculator;

	public BrokerageService() {
		this.brokerageCalculator = new BrokerageCalculator();
		this.additionalChargesCalculator = new AdditionalChargesCalculator();
	}

	public ChargeBreakdown calculateCharges(Trade trade, BrokerPlan brokerPlan){
		double brokerage =brokerageCalculator.CalculateBrokerage(trade,brokerPlan);
		
		double stt= additionalChargesCalculator.calculateSTT(trade);
		double gstAmount = additionalChargesCalculator.calculateGST(brokerage);
		double transactionCharges= additionalChargesCalculator.calculateTransactionCharges();
		double totalCharges = brokerage + stt + transactionCharges + gstAmount;

		return new ChargeBreakdown(brokerage,stt,transactionCharges,gstAmount,totalCharges);

	}
}

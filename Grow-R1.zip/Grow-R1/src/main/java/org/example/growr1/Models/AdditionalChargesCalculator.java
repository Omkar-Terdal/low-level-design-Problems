package org.example.growr1.Models;

import org.example.growr1.Enums.TradeAction;
import org.example.growr1.Enums.TradeType;

public class AdditionalChargesCalculator {

	public double calculateSTT(Trade trade){
		if(trade.getTradeAction()!= TradeAction.SELL){
			return 0.0;
		}
		if(trade.getTradeType()== TradeType.EQUITY_DELIVERY){
			return trade.getTradeValue() * 0.001;
		}
		if(trade.getTradeType()== TradeType.EQUITY_INTRADAY){
			return trade.getTradeValue() * 0.00025;
		}
		if(trade.getTradeType()==TradeType.FNO){
			return trade.getTradeValue() * 0.00025;
		}
		return 0.0;
	}

	public double calculateGST(double brokerage){
		return  brokerage * 0.18;
	}

	public double calculateTransactionCharges(){
		return 10.0;
	}
}

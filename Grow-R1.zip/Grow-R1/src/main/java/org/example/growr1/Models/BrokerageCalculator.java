package org.example.growr1.Models;

import org.example.growr1.Enums.BrokerPlan;

public class BrokerageCalculator {

	public double CalculateBrokerage(Trade trade, BrokerPlan brokerPlan){

		switch (brokerPlan){
			case REGULAR :
				return calculateRegular(trade);

			case PRO :
				return calculatePro(trade);

			case ULTRA:
				return 10.0;

			default:
				throw new IllegalArgumentException("Invalid brokerPlan");
		}
	}

	private double calculateRegular(Trade trade){
		switch (trade.getTradeType()){
			case EQUITY_DELIVERY :
				return trade.getTradeValue()*0.005;
			case EQUITY_INTRADAY:
				return trade.getTradeValue()*0.0003;
			case FNO:
				return trade.getTradeValue()*0.0005;

			default:
				throw new IllegalArgumentException("Invalid tradeType");
		}
	}

	private double calculatePro(Trade trade){
		switch (trade.getTradeType()){
			case EQUITY_DELIVERY :
				return 20.0;
			case EQUITY_INTRADAY:
				return 10.0;
			case FNO:
				return 15.0;

			default:
				throw new IllegalArgumentException("Invalid tradeType");
		}
	}

}

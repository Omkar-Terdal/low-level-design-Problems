package org.example.growr1.Models;

import org.example.growr1.Enums.BrokerPlan;
import org.example.growr1.Enums.TradeAction;
import org.example.growr1.Enums.TradeType;

public class Trade {
	private String tradeId;
	private TradeType tradeType;
	private TradeAction tradeAction;
	private double tradeValue;

	public Trade(String tradeId,TradeType tradeType, TradeAction tradeAction, double tradeValue) {
		this.tradeId = tradeId;
		this.tradeType = tradeType;
		this.tradeAction = tradeAction;
		this.tradeValue = tradeValue;
	}

	public String getTradeId() {
		return tradeId;
	}

	public Trade setTradeId(String tradeId) {
		this.tradeId = tradeId;
		return this;
	}

	public TradeType getTradeType() {
		return tradeType;
	}

	public Trade setTradeType(TradeType tradeType) {
		this.tradeType = tradeType;
		return this;
	}

	public TradeAction getTradeAction() {
		return tradeAction;
	}

	public Trade setTradeAction(TradeAction tradeAction) {
		this.tradeAction = tradeAction;
		return this;
	}

	public double getTradeValue() {
		return tradeValue;
	}

	public Trade setTradeValue(double tradeValue) {
		this.tradeValue = tradeValue;
		return this;
	}

}

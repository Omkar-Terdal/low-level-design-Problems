package org.example.growr1.Models;

public class ChargeBreakdown {
	private double brokerage;
	private double stt;
	private double transactionCharge;
	private double gst;
	private double totalCharges;

	public ChargeBreakdown(double brokerage, double stt, double transactionCharge, double gst, double totalCharges) {
		this.brokerage = brokerage;
		this.stt = stt;
		this.transactionCharge = transactionCharge;
		this.gst = gst;
		this.totalCharges =  brokerage+stt+transactionCharge+gst;
	}

	@Override
	public String toString() {
		return "ChargeBreakdown{" +
				"brokerage=" + brokerage +
				", stt=" + stt +
				", transactionCharge=" + transactionCharge +
				", gst=" + gst +
				", totalCharges=" + totalCharges +
				'}';
	}
}

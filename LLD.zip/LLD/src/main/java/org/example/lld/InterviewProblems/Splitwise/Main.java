//package org.example.lld.InterviewProblems.Splitwise;
//
//import org.example.lld.InterviewProblems.Splitwise.Models.*;
//import org.example.lld.InterviewProblems.Splitwise.Service.ExpenseService;
//import org.example.lld.InterviewProblems.Splitwise.SplitStratergy.*;
//
//import java.util.*;
//
//public class Main {
//
//	public static void main(String[] args) {
//
//		Scanner sc = new Scanner(System.in);
//
//		ExpenseService expenseService = new ExpenseService();
//
//		// Create Users
//		Map<String, User> userMap = new HashMap<>();
//
//		userMap.put("u1", new User("u1", "Omkar"));
//		userMap.put("u2", new User("u2", "Rahul"));
//		userMap.put("u3", new User("u3", "Amit"));
//		userMap.put("u4", new User("u4", "John"));
//
//		while (true) {
//
//			String command = sc.next();
//
//			if (command.equalsIgnoreCase("EXIT")) {
//				break;
//			}
//
//			if (command.equalsIgnoreCase("EXPENSE")) {
//
//				String paidById = sc.next();
//				double amount = sc.nextDouble();
//
//				int totalUsers = sc.nextInt();
//
//				List<User> users = new ArrayList<>();
//
//				for (int i = 0; i < totalUsers; i++) {
//					users.add(userMap.get(sc.next()));
//				}
//
//				String splitType = sc.next();
//
//				List<Split> splits = new ArrayList<>();
//				SplitStrategry strategy = null;
//
//				switch (splitType.toUpperCase()) {
//
//					case "EQUAL":
//
//						strategy = new EqualSplitStrategy();
//
//						for (User user : users) {
//							splits.add(new Split(user));
//						}
//
//						break;
//
//					case "EXACT":
//
//						strategy = new ExactSplitStrategy();
//
//						for (User user : users) {
//							Split split = new Split(user);
//							split.setAmount(sc.nextDouble());
//							splits.add(split);
//						}
//
//						break;
//
//					case "PERCENT":
//
//						strategy = new PercentageSplitStrategy();
//
//						for (User user : users) {
//							PercentageSplit split = new PercentageSplit(user);
//							split.setPercentage(sc.nextDouble());
//							splits.add(split);
//						}
//
//						break;
//
//					default:
//						System.out.println("Invalid Split Type");
//						continue;
//				}
//
//				expenseService.addExpense(
//						userMap.get(paidById),
//						amount,
//						splits,
//						strategy
//				);
//
//				System.out.println("Expense Added Successfully");
//			}
//		}
//
//		sc.close();
//	}
//}

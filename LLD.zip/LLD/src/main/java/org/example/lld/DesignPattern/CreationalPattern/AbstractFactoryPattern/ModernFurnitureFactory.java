package org.example.lld.DesignPattern.CreationalPattern.AbstractFactoryPattern;

public class ModernFurnitureFactory implements FurnitureFactory {
	@Override
	public Chair createChair() {
		return new ModernChair();
	}
	@Override
	public Bed createBed() {
		return new ModernBed();
	}
}

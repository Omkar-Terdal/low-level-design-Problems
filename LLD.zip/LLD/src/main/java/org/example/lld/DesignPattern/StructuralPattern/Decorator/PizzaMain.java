package org.example.lld.DesignPattern.StructuralPattern.Decorator;

public class PizzaMain {

	public static void main(String[] args) {
		BasePizza onlyMargheritaPizza=new MargheritaPizza();
		System.out.println(onlyMargheritaPizza.cost());

		BasePizza margheritaPizzaWithCheese=new ExtraCheese(new MargheritaPizza());
		System.out.println(margheritaPizzaWithCheese.cost());

		BasePizza margheritaPizzaWithCheeseAndMashroom=new MashroomPizza(new ExtraCheese(new MargheritaPizza()));
		System.out.println(margheritaPizzaWithCheeseAndMashroom.cost());
	}
}

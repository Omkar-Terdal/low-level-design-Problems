package org.example.lld.InterviewProblems.ATM.Models;

public class ATM {
	private CashDispenser cashDispenser;
	private CardReader cardReader;
	private Screen screen;

	public ATM(CardReader cardReader, Screen screen, CashDispenser cashDispenser){
		this.cardReader = cardReader;
		this.screen = screen;
		this.cashDispenser= cashDispenser;
	}

	public void insertCard(Card card){
		cardReader.insertCard(card);
		System.out.println("Card inserted successfully");
	}
	public boolean authenticateCard(int pin){
		Card card=cardReader.readCard();
		if(card==null){
			screen.displayError("Please insert your card.");
			return false;
		}
		boolean authenticated= card.authenticateCard(pin);
		if(authenticated){
			screen.displayMessage("Card authenticated successfully");
		}else{
			screen.displayError("Invalid pin number");
			return false;
		}

		return authenticated;
	}

	public double checkBalance(){
		Card card=cardReader.readCard();
		if(card==null){
			screen.displayError("Please insert your card.");
		}
		System.out.println("Balance amount: "+ card.getAccount().getBalance());
		return card.getAccount().getBalance();
	}


	public void withDraw(int amount){
		Card card=cardReader.readCard();
		if(card==null){
			screen.displayError("Please insert your card.");
		}
		Account account=card.getAccount();
		if(account.getBalance()<amount){
			screen.displayError("Insufficient balance");
			return;
		}
		if(!cashDispenser.canDispense(amount)){
			screen.displayError("ATM has Insufficient balance");
		}

		account.debitAmount(amount);
		cashDispenser.dispense(amount);
		screen.displayMessage("Card withdraw successfully");
		return;
	}

	public void ejectCard(){

		if(!cardReader.isCardInserted()){
			screen.displayError("Please insert your card.");
			return;
		}
		cardReader.ejectCard();
		screen.displayMessage("Card ejected successfully");
	}

}

package org.example.lld.InterviewProblems.Elevator.Enums;

public enum DoorState {
	OPEN,
	CLOSE
}

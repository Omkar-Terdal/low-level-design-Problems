package org.example.lld.DesignPattern.BehaviouralPattern.StratergryPattern.WithStratergyPattern.Stratergy;

public interface DriverStratergy {

	void drive();
}

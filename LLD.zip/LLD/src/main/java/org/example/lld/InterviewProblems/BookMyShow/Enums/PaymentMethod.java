package org.example.lld.InterviewProblems.BookMyShow.Enums;

public enum PaymentMethod {
	UPI,
	CREDIT_CARD,
	CASH
}

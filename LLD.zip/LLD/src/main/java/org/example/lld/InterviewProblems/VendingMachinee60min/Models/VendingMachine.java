package org.example.lld.InterviewProblems.VendingMachinee60min.Models;

public class VendingMachine {

	private final Inventory inventory;

	private Product selectedProduct;
	private int balance;

	public VendingMachine(Inventory inventory) {
		this.inventory = inventory;
		this.balance = 0;
		this.selectedProduct = null;
	}

	public void selectProduct(String productId) {

		Product product = inventory.getProduct(productId);

		if (product == null) {
			throw new IllegalArgumentException(
					"Product does not exist"
			);
		}

		if (!inventory.isAvailable(productId)) {
			throw new IllegalStateException(
					"Product is out of stock"
			);
		}

		selectedProduct = product;

		System.out.println(
				"Selected: " + product.getProductName()
		);

		System.out.println(
				"Price: ₹" + product.getPrice()
		);
	}

	public void insertMoney(int amount) {

		if (amount <= 0) {
			throw new IllegalArgumentException(
					"Invalid amount"
			);
		}

		balance += amount;

		System.out.println(
				"Inserted: ₹" + amount
		);

		System.out.println(
				"Current balance: ₹" + balance
		);
	}

	public void dispense() {

		if (selectedProduct == null) {
			throw new IllegalStateException(
					"Please select a product first"
			);
		}

		double price = selectedProduct.getPrice();

		if (balance < price) {

			throw new IllegalStateException(
					"Insufficient money. Required: ₹"
							+ price
							+ ", inserted: ₹"
							+ balance
			);
		}

		// Reduce stock only after all validations pass.
		inventory.reduceStock(
				selectedProduct.getId()
		);

		double change = balance - price;

		System.out.println(
				"Dispensed: "
						+ selectedProduct.getProductName()
		);

		System.out.println(
				"Change returned: ₹" + change
		);

		// Reset machine for next customer.
		selectedProduct = null;
		balance = 0;
	}

	public int cancel() {

		int refund = balance;

		selectedProduct = null;
		balance = 0;

		System.out.println(
				"Transaction cancelled."
		);

		System.out.println(
				"Refund: ₹" + refund
		);

		return refund;
	}

	public int getBalance() {
		return balance;
	}

	public Product getSelectedProduct() {
		return selectedProduct;
	}
}

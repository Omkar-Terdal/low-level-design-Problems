package org.example.lld.InterviewProblems.TicTacToe.Models;

import org.example.lld.InterviewProblems.TicTacToe.Enums.PieceType;

public class Player {
	private String name;
	private PlayingPiece playingPiece;

	public Player(String name, PlayingPiece playingPiece) {
		this.name = name;
		this.playingPiece = playingPiece;
	}

	public String getName() {
		return name;
	}
	public PlayingPiece getPlayingPiece() {
		return playingPiece;
	}

}

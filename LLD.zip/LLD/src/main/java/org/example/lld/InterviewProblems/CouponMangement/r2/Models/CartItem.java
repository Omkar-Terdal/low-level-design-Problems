package org.example.lld.InterviewProblems.CouponMangement.r2.Models;

public class CartItem {
	private Product product;
	private int quantity;

	public CartItem(Product product, int quantity) {
		this.product = product;
		this.quantity = quantity;
	}


	public Product getProduct() {
		return product;
	}
	public int getQuantity() {
		return quantity;
	}
}

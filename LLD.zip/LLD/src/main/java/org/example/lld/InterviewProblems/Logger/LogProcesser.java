package org.example.lld.InterviewProblems.Logger;

public abstract class LogProcesser {
	public static int INFO=1;
	public static int WARN=2;
	public static int ERROR=3;

	LogProcesser nextLogProcessor;
	LogProcesser(LogProcesser nextLogProcessor){
		this.nextLogProcessor=nextLogProcessor;
	}

	public void log(int level,String message){
		if(nextLogProcessor!=null){
			nextLogProcessor.log(level,message);
		}
	};

}

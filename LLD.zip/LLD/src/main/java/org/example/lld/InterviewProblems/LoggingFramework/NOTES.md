# Logging Framework — LLD Notes

> Source: **CodeNCode** — "L03: Logging Framework | Low Level Design" (Java LLD course, lecture 3), 1:06:24.
> Notes reconstructed from the video captions — a few identifier names may differ slightly from the on-screen code.

---

## 1. Approach — "CARDD"

The interviewer gives a deliberately vague prompt ("design a logging framework"). Turning it into a
crisp problem statement is part of the evaluation. Steps used in the video:

| Letter | Step | What you produce |
|---|---|---|
| **C** | Clarify requirements | functional + non-functional requirements |
| **A** | (define) Entities | the major nouns / building blocks |
| **R** | Responsibilities | one clear job per entity |
| **D** | (define) Interactions / relationships | how classes talk → UML diagram |
| **D** | Durability | is the design open to future change (OCP)? + **thread safety** (treated as mandatory, not optional) |

Tip repeated throughout: **suggest, don't just ask.** e.g. "I'll support multiple log levels (DEBUG…FATAL)
and multiple appenders (console/file/DB)" instead of "what levels do you want?".

---

## 2. Mental model

A logging framework has **two core pluggable pieces**:

- **Appender** — *where* the log goes. Writes the log to a destination: console, file, database.
- **Formatter** — *how* the log looks. Turns a `LogMessage` object into a formatted string.

Everything else (Logger, LoggerManager, LogLevel, LogMessage) wires these together.

---

## 3. Requirements

### Functional
- Support multiple **log levels**: `DEBUG, INFO, WARN, ERROR, FATAL`.
- Support multiple **appenders**: console, file, database.
- Support multiple **formatters** (pluggable output format).
- Logger must be **configurable** (level + appenders per logger).
- Logger **filters by level** — a logger with min level `ERROR` drops `DEBUG`/`INFO` calls.

### Non-functional
- **Must not block the main business flow.** Logging is a *sub-feature*; a payment service must not
  slow down because it logs. ⇒ logging path must be **asynchronous**.
- **High performance / throughput.**
- **Extensible (OCP)** — adding an appender or formatter = new class, no edits to existing code.
- **Thread-safe** — a single logger instance is shared across many threads.
- **Clean separation of concerns.**

---

## 4. Entities

`LogLevel`, `LogMessage`, `Formatter`, `Appender`, `Logger`, `LoggerManager`.

> If you can't brainstorm all entities up front, that's fine — they surface while coding. The list just
> gives a high-level shape of the system.

---

## 5. Responsibilities

| Entity | Responsibility |
|---|---|
| `LogLevel` (enum) | Defines the levels **and their numeric priority** (DEBUG=1 … FATAL=5). Used for filtering. |
| `LogMessage` | Holds the message **+ metadata**: level, timestamp, logger name, thread name. **Immutable.** |
| `Formatter` (interface) | `String format(LogMessage)` — convert a `LogMessage` to a formatted string. Many impls. |
| `Appender` (interface) | `void append(LogMessage)` — write the log to one destination. Many impls. Holds one `Formatter`. |
| `Logger` | Entry point for callers. Exposes `debug/info/warn/error/fatal(String)`. **Filters by level**, builds the `LogMessage`, **delegates to its configured appenders**. |
| `LoggerManager` | Creates loggers and **caches them by name** (`Map<String, Logger>`). App's single entry point. **Singleton.** |

Logger naming convention: use the **fully-qualified class name** of the caller
(`LoggerManager.getLogger(MyClass.class.getName())`) — industry best practice, uniquely identifies the source.

---

## 6. Interactions / flow

**Typical flow:**
1. A class asks `LoggerManager` for a `Logger` (by name).
2. Caller invokes `logger.info("something happened")`.
3. `Logger` **filters**: if `message.level < logger.level` → return, do nothing.
4. Else `Logger` builds a `LogMessage` (adds timestamp, thread name, logger name).
5. `Logger` **delegates** the `LogMessage` to each configured `Appender`.
6. Each `Appender` calls its `Formatter.format(logMessage)` → string, then writes it to its destination.

**Relationships (for the UML):**

```
LoggerManager  ──creates / has──▶  Logger        (1 → *)   [solid = has-a]
Logger         ──has──▶  LogLevel  (current/min level)     [solid]
Logger         ──creates──▶  LogMessage                    [solid]
Logger         ──has──▶  Appender  (1 → *  — multi-destination) [solid]
LogMessage     ──has──▶  LogLevel  (level it was logged at) [solid]
Appender       ──has──▶  Formatter (1 → 1)                  [solid]
ConsoleAppender / FileAppender  ──▶ Appender               [dashed = is-a]
DefaultFormatter                ──▶ Formatter              [dashed = is-a]
```

Why `Logger → Appender` is **1-to-many**: one logger can write to console **and** DB at once — if the
app crashes you lose the console but still have the DB copy.

---

## 7. Package structure

Two common conventions:
- **By layer** (Spring/MVC style): `controller/`, `service/`, `repository/`, `model/`.
- **By feature** (used here): `core/` (Logger, LoggerManager, LogLevel, LogMessage), `appender/`,
  `formatter/`, `demo/`.

Core = classes without which the system can't work. Appender/Formatter are "important but not core"
(you could hardcode a `System.out.println` in the logger and still have a logger).

---

## 8. Class-by-class implementation

Build **bottom-up**: `LogLevel` → `LogMessage` → `Formatter` → `Appender`s → `Logger` → `LoggerManager` → async.

### 8.1 `LogLevel` (enum)

```java
public enum LogLevel {
    DEBUG(1), INFO(2), WARN(3), ERROR(4), FATAL(5);
    private final int level;
    LogLevel(int level) { this.level = level; }
    public int getLevel() { return level; }
}
```
Priority number drives filtering: "print only if `msg.level.getLevel() >= logger.level.getLevel()`".

### 8.2 `LogMessage` — immutable ⇒ thread-safe

```java
public final class LogMessage {
    private final String message;
    private final LogLevel level;
    private final String loggerName;
    private final LocalDateTime timestamp;   // set internally: LocalDateTime.now()
    private final String threadName;         // set internally: Thread.currentThread().getName()

    public LogMessage(String message, LogLevel level, String loggerName) {
        this.message = message;
        this.level = level;
        this.loggerName = loggerName;
        this.timestamp = LocalDateTime.now();
        this.threadName = Thread.currentThread().getName();
    }
    // getters only, no setters
}
```
Only `message`, `level`, `loggerName` are passed in; timestamp + thread name are captured by the object
itself. No setters → **immutable → safe to share across threads and appenders**.

### 8.3 `Formatter` (Strategy)

```java
public interface Formatter {
    String format(LogMessage message);
}

public class DefaultFormatter implements Formatter {
    private static final DateTimeFormatter DTF =
        DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
    public String format(LogMessage m) {
        return DTF.format(m.getTimestamp()) + " [" + m.getThreadName() + "] "
             + m.getLoggerName() + " " + m.getLevel() + " - " + m.getMessage();
    }
}
```
`LogMessage.timestamp` is a `LocalDateTime`; convert it with a `DateTimeFormatter` at format time (any
format you want).

### 8.4 `Appender` (Strategy) + `ConsoleAppender`

```java
public interface Appender {
    void append(LogMessage message);
}

public class ConsoleAppender implements Appender {
    private final Formatter formatter;
    public ConsoleAppender(Formatter formatter) { this.formatter = formatter; }
    public void append(LogMessage message) {
        System.out.println(formatter.format(message));
    }
}
```

### 8.5 `FileAppender` — the thread-safety showcase

```java
public class FileAppender implements Appender {
    private final Formatter formatter;
    private final BufferedWriter writer;
    private final Object lock = new Object();

    public FileAppender(Formatter formatter, String filePath) throws IOException {
        this.formatter = formatter;
        this.writer = new BufferedWriter(new FileWriter(filePath, true));
        Runtime.getRuntime().addShutdownHook(new Thread(this::shutdown));
    }

    public void append(LogMessage message) {
        synchronized (lock) {
            try {
                writer.write(formatter.format(message));
                writer.newLine();
                writer.flush();
            } catch (IOException e) { /* handle */ }
        }
    }

    private void shutdown() {
        synchronized (lock) {
            try { writer.flush(); writer.close(); } catch (IOException e) { /* handle */ }
        }
    }
}
```

Key points the video stresses:
- **`synchronized` on `append` is unavoidable.** The OS serializes writes to a single file — only one
  thread can write at a time. Multiple `BufferedWriter`s wouldn't help (they'd all target the same file
  and still serialize at the OS level).
- **Shutdown hook** (`Runtime.getRuntime().addShutdownHook`): a `BufferedWriter` keeps data in memory
  until `flush()`. If the JVM dies mid-write you lose buffered logs. The hook flushes + closes gracefully.
  `shutdown()` is `synchronized` on the same `lock` so it can't run while an `append` is in progress.
- **`flush()` on every message is a known cost.** Expected interview follow-up: *"why flush every log?"*
  → Answer: *"kept simple for the interview; in production flush **periodically** (a scheduler that
  flushes every 5–10 s) instead of per-message — much better throughput."*

### 8.6 `Logger`

```java
public class Logger {
    private final String name;
    private volatile LogLevel level;                       // changeable at runtime, seen by all threads
    private final List<Appender> appenders = new CopyOnWriteArrayList<>();

    public Logger(String name, LogLevel level) { this.name = name; this.level = level; }

    public void setLevel(LogLevel level) { this.level = level; }
    public void addAppender(Appender appender) { appenders.add(appender); }

    public void debug(String msg) { log(LogLevel.DEBUG, msg); }
    public void info (String msg) { log(LogLevel.INFO,  msg); }
    public void warn (String msg) { log(LogLevel.WARN,  msg); }
    public void error(String msg) { log(LogLevel.ERROR, msg); }
    public void fatal(String msg) { log(LogLevel.FATAL, msg); }

    public void log(LogLevel msgLevel, String msg) {
        if (msgLevel.getLevel() < level.getLevel()) return;         // FILTER
        LogMessage lm = new LogMessage(msg, msgLevel, name);
        for (Appender a : appenders) a.append(lm);                  // DELEGATE
    }
}
```

Two concurrency decisions:
- **`level` is `volatile`** — the same `Logger` instance is shared by many threads (see `LoggerManager`);
  a level change by one thread must be visible to the others immediately.
- **`appenders` is `CopyOnWriteArrayList`**:
  - Thread A iterating the appender list while thread B calls `addAppender` → plain `ArrayList` throws
    `ConcurrentModificationException`. `CopyOnWriteArrayList` copies the backing array on every write,
    so iterators never see a concurrent mutation.
  - It's inherently thread-safe.
  - **Only appropriate for read-heavy / write-rare** data. Appenders are configured once and read on
    every log call → perfect fit. (If writes were ~30%+, the per-write array copy would be too costly.)

### 8.7 `LoggerManager` — Singleton

```java
public class LoggerManager {
    public static final LoggerManager INSTANCE = new LoggerManager();
    private final Map<String, Logger> loggers;

    private LoggerManager() { this.loggers = new ConcurrentHashMap<>(); }
    public static LoggerManager getInstance() { return INSTANCE; }

    public Logger getLogger(String name) {
        return loggers.computeIfAbsent(name, n -> new Logger(n, LogLevel.INFO));
    }
}
```

- **Singleton**: private constructor, `static final INSTANCE`. One entry point that owns all loggers.
- **`ConcurrentHashMap`, not `synchronized getLogger`**: a `synchronized` method serializes *all*
  `getLogger` calls. `ConcurrentHashMap` locks at **bucket level**, so lookups for different names
  proceed in parallel → higher throughput. (Same reasoning as lecture 2.)
- `computeIfAbsent` → create-once, then always return the cached instance. That's why the same name
  from different threads yields the *same* `Logger` object (hence the `volatile`/COW choices above).
- Default level for a freshly created logger: `INFO`.

---

## 9. Thread-safety summary

| Concern | Mechanism |
|---|---|
| `LogMessage` shared across appenders/threads | **immutable** (all `final`, no setters) |
| Logger cache shared across threads | `ConcurrentHashMap` + `computeIfAbsent` |
| Runtime level changes visible everywhere | `volatile LogLevel level` |
| Appender list mutated while iterated | `CopyOnWriteArrayList` |
| Concurrent writes to one file | `synchronized (lock)` in `append` **and** `shutdown` |
| Buffered data lost on JVM exit | `Runtime.addShutdownHook` → flush + close |
| Main thread blocked by logging | **AsyncAppender** (section 10) |

---

## 10. Asynchronous logging — `AsyncAppender`

### Why
Synchronous logging blocks the caller:
```
... important work ...
logger.debug("done step 1");   // <-- next line waits until this is fully written
... more important work ...    // delayed by logging
```
A payment is far more important than its log line. The log call should **return immediately** and the
actual write should happen on a background thread.

### Design — **Decorator pattern**
`AsyncAppender` **wraps** any other `Appender` (console or file) and adds background processing without
changing it.

```java
public class AsyncAppender implements Appender {
    private final Appender delegate;                 // real appender (file/console)
    private final BlockingQueue<LogMessage> queue;
    private final Thread worker;
    private volatile boolean running = true;
    private static final int BATCH_SIZE = 50;

    public AsyncAppender(Appender delegate, int capacity) {
        this.delegate = delegate;
        this.queue = new LinkedBlockingQueue<>(capacity);   // e.g. 10_000
        this.worker = new Thread(this::process, "async-logger-worker");
        this.worker.setDaemon(true);
        this.worker.start();
        Runtime.getRuntime().addShutdownHook(new Thread(this::shutdown));
    }

    @Override
    public void append(LogMessage message) {
        try {
            queue.put(message);            // enqueue instead of writing; blocks only if queue is FULL
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();   // don't swallow the interrupt
        }
    }

    private void process() {
        List<LogMessage> batch = new ArrayList<>();
        while (running || !queue.isEmpty()) {
            try {
                queue.drainTo(batch, BATCH_SIZE);         // grab up to 50 in ONE call, non-blocking
                if (batch.isEmpty()) {
                    batch.add(queue.take());              // nothing to do → BLOCK here, save CPU
                }
                for (LogMessage m : batch) delegate.append(m);
                batch.clear();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    private void shutdown() {
        running = false;
        worker.interrupt();     // wake it if blocked on put()/take()
    }
}
```

### Why each piece

- **`BlockingQueue` (`LinkedBlockingQueue`, capacity ~10 000)** — classic **producer/consumer**: the
  business threads produce logs; the worker thread consumes them. Thread-safe by design.
  - `put()` blocks the *producer* only when the queue is **full** (back-pressure).
  - `take()` blocks the *consumer* when the queue is **empty**.
- **`worker` thread, `setDaemon(true)`** — background thread; doesn't keep the JVM alive on its own.
- **`running` flag** — on shutdown set `false`; the loop condition `running || !queue.isEmpty()` means
  the worker **drains the remaining queue** before stopping (no lost logs).
- **Batching with `drainTo(batch, 50)`** — `queue.take()` per message is expensive (empty-checks,
  waiter bookkeeping every call). `drainTo` fetches up to 50 in a single operation and **does not
  block** (returns whatever is there, even 0).
- **`if (batch.isEmpty()) batch.add(queue.take());`** — the CPU-saving trick. Without it, an empty
  queue makes the `while` loop spin forever burning a core. With it, an empty queue parks the worker
  on `take()` until a message arrives.
- **`InterruptedException` → `Thread.currentThread().interrupt()`** — the JVM clears the interrupt flag
  when the exception is thrown; re-set it so callers higher up still see the interruption.
- **Shutdown hook** — `running=false` + `worker.interrupt()` to unblock it from `put()`/`take()`, then
  it finishes draining and exits. The wrapped `FileAppender`'s own hook then flushes the file.

---

## 11. Design patterns used

| Pattern | Where | Why |
|---|---|---|
| **Singleton** | `LoggerManager` | one owner/entry point for all loggers |
| **Strategy** | `Formatter` + `Appender` (interface + swappable impls) | same call site, different behaviour |
| **Decorator** | `AsyncAppender` wrapping another `Appender` | add async behaviour without touching the wrapped class |

---

## 12. Extensibility (Durability / OCP)

- **New formatter** → new class `implements Formatter`, write `format()`. Nothing else changes.
- **New appender** (e.g. `KafkaAppender`, `DBAppender`) → new class `implements Appender`. Nothing else
  changes. `AsyncAppender` can wrap it for free.

---

## 13. Worked example (from the demo)

Config: `Logger` named `...LoggingDemo`, one `ConsoleAppender(new DefaultFormatter())`.

- `logger.setLevel(FATAL); logger.fatal("...")` → **printed**
  `03-02-2026 12:00:00 [main] logging.framework.demo.LoggingDemo FATAL - <message>`
- `logger.debug("...")` with min level `FATAL` → **nothing** (DEBUG=1 < FATAL=5). Output empty →
  proves the filter works.

**Async demo:** 3 threads `worker-1/2/3`, each logs 50 messages (`message 1..50 from worker-N`),
appenders = `AsyncAppender(fileAppender, 10_000)` + `ConsoleAppender`. Threads started 1→2→3 and
`join()`ed. Result: **150 lines**, but interleaved — `worker-3` finishes its 50 before `worker-1`,
even though it started last. The scrambled order **is the proof** that writing happens asynchronously,
off the caller's thread. Elapsed time measured with `System.currentTimeMillis()` around the run.

---

## 14. Likely interview follow-ups (call these out proactively)

- *Why flush on every log?* → don't in prod; periodic flush via a scheduler (5–10 s).
- *Why `synchronized` on file write?* → OS serializes single-file writes; more writers don't help.
- *Why `CopyOnWriteArrayList` for appenders and not elsewhere?* → read-heavy, write-once; wrong choice
  for balanced read/write.
- *Why `ConcurrentHashMap` instead of `synchronized getLogger`?* → bucket-level locking → parallel
  lookups for distinct names.
- *How do you not block the payment service?* → `AsyncAppender` + `BlockingQueue`; `append` just
  enqueues.
- *What happens to in-flight / queued logs on shutdown?* → shutdown hooks: async worker drains the
  queue (`running || !queue.isEmpty()`), file appender flushes + closes.
- *Queue full?* → `put()` applies back-pressure (blocks producer); alternative is drop-oldest / drop-new
  with a metric.

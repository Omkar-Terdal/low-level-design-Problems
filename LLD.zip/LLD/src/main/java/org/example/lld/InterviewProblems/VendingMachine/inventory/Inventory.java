package org.example.lld.InterviewProblems.VendingMachine.inventory;

import org.example.lld.InterviewProblems.VendingMachine.model.Product;

import java.util.HashMap;
import java.util.Map;

public class Inventory {
	private final Map<Product, Integer> stock = new HashMap<>();

	public void addProduct(Product product, int quantity) {
		stock.put(product, stock.getOrDefault(product, 0) + quantity);
	}

	public boolean isAvailable(Product product) {
		return stock.getOrDefault(product, 0) > 0;
	}

	public void reduceStock(Product product) {
		int current = stock.getOrDefault(product, 0);
		if (current <= 0) {
			throw new IllegalStateException("Product out of stock: " + product.getName());
		}
		stock.put(product, current - 1);
	}

	public void restock(Product product, int quantity) {
		stock.put(product, stock.getOrDefault(product, 0) + quantity);
	}

	public int getQuantity(Product product) {
		return stock.getOrDefault(product, 0);
	}
}

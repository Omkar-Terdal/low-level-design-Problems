package org.example.lld.InterviewProblems.BookMyShow.Models;

import org.example.lld.InterviewProblems.BookMyShow.Enums.BookingStatus;

import java.util.ArrayList;
import java.util.List;

public class BookMyShow {
	private List<City> citiesList;
	private List<Movie> movieList;
	private List<User> userList;
	private List<Booking> bookingList;

	public BookMyShow( ) {
		this.citiesList = new ArrayList<>();
		this.movieList = new ArrayList<>();
		this.userList = new ArrayList<>();
		this.bookingList = new ArrayList<>();
	}

	public void addCity(City city) {
		citiesList.add( city );
	}
	public void addMovie(Movie movie) {
		movieList.add( movie );
	}
	public void addUser(User user) {
		userList.add( user );
	}
	public void addBooking(Booking booking) {
		bookingList.add( booking );
	}

	public List<City> getCitiesList() {
		return citiesList;
	}

	public List<Movie> getMovieList() {
		return movieList;

	}

	public List<User> getUserList() {
		return userList;
	}
	public List<Booking> getBookingList() {
		return bookingList;
	}

	public Movie findMovie(String movieName) {
		for ( Movie movie : movieList ) {
			if(movie.getTitle().equalsIgnoreCase(movieName)){
				return movie;
			}
		}
		return null;
	}
	public City findCity(String cityName) {
		for ( City city : citiesList ) {
			if(city.getCityName().equalsIgnoreCase(cityName)){
				return city;
			}
		}
		return null;
	}

	public Booking findBooking(Long bookingId) {
		for ( Booking booking : bookingList ) {
			if(booking.getBookingId().equals(bookingId)){
				return booking;
			}
		}
		return null;
	}

	public void cancelBooking(Long bookingId) {
		Booking booking = findBooking(bookingId);
		if(booking != null){
			booking.setBookingStatus(BookingStatus.CANCELLED);
		}
	}

}

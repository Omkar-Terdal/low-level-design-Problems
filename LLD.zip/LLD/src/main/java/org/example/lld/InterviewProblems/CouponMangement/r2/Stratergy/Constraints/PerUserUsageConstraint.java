package org.example.lld.InterviewProblems.CouponMangement.r2.Stratergy.Constraints;

import org.example.lld.InterviewProblems.CouponMangement.r2.Models.Cart;
import org.example.lld.InterviewProblems.CouponMangement.r2.Models.Coupon;
import org.example.lld.InterviewProblems.CouponMangement.r2.Models.User;
import org.example.lld.InterviewProblems.CouponMangement.r2.Models.ValidationResult;
import org.example.lld.InterviewProblems.CouponMangement.r2.Repository.CouponUsageRepository;

public class PerUserUsageConstraint implements Constraints{
	private int maxCount;
	private CouponUsageRepository couponUsageRepository;


	public PerUserUsageConstraint(CouponUsageRepository couponUsageRepository, int maxCount) {
		this.couponUsageRepository = couponUsageRepository;
		this.maxCount = maxCount;
	}

	@Override
	public ValidationResult validate(User user, Cart cart, Coupon coupon){
		int userUsageCount= couponUsageRepository.getUserUsageCount(coupon.getCouponId(),user.getUserID());
		if(userUsageCount>maxCount){
			return  ValidationResult.failure("\"Coupon usage limit exceeded for this user.\"");
		}
		return ValidationResult.success();
	}
}

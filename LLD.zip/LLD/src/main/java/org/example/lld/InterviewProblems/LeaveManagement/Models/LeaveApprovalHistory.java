package org.example.lld.InterviewProblems.LeaveManagement.Models;

import org.example.lld.InterviewProblems.LeaveManagement.Enums.LeaveStatus;
import org.example.lld.InterviewProblems.LeaveManagement.Enums.LeaveType;

import java.time.LocalDateTime;
import java.util.Map;

public class LeaveApprovalHistory {
	private String historyId;
	private LeaveRequest  request;
	private LeaveStatus leaveStatus;
	private Employee actionBy;
	private LocalDateTime actionTime;
	private String comment;

	public LeaveApprovalHistory(String historyId, LeaveRequest request, LeaveStatus leaveStatus, Employee actionBy, LocalDateTime actionTime, String comment) {
		this.historyId = historyId;
		this.request = request;
		this.leaveStatus = leaveStatus;
		this.actionBy = actionBy;
		this.actionTime = actionTime;
		this.comment = comment;
	}

	public String getHistoryId() {
		return historyId;
	}

	public LeaveRequest getRequest() {
		return request;
	}

	public LeaveStatus getLeaveStatus() {
		return leaveStatus;
	}

	public Employee getActionBy() {
		return actionBy;
	}

	public LocalDateTime getActionTime() {
		return actionTime;
	}

	public String getComment() {
		return comment;
	}
}

package org.example.lld.DesignPattern.BehaviouralPattern.ObserverPattern;

public class EmailObserver implements Observer{
	private String name;

	EmailObserver(String name){
		this.name=name;
	}

	@Override
	public void update(){
		System.out.println(name +  " Email notification sent");
	}
}

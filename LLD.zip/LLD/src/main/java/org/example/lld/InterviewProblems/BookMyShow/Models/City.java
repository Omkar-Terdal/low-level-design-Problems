package org.example.lld.InterviewProblems.BookMyShow.Models;

import java.util.ArrayList;
import java.util.List;

public class City {
	private String cityName;
	private List<Theatre> theatreList;

	public City(String cityName) {
		this.cityName = cityName;
		this.theatreList = new ArrayList<>();
	}

	public String getCityName() {
		return cityName;
	}
	public List<Theatre> getTheatreList() {
		return theatreList;
	}
	public void addTheatre(Theatre theatre) {
		theatreList.add(theatre);
	}

}

package org.example.lld.InterviewProblems.CouponMangement.r2.Stratergy.CouponType;

import org.example.lld.InterviewProblems.CouponMangement.r2.Models.Cart;

public class PercentageCoupon implements CouponType {
	private double percentage;

	public PercentageCoupon(double percentage) {
		this.percentage = percentage;
	}

	@Override
	public double calculateDiscount(Cart cart){
		return cart.getTotalAmount()*percentage/100;
	}

}

package org.example.lld.InterviewProblems.Elevator.Enums;

public enum ElevatorState {
	IDLE,
	MOVING,
	DOOR_OPEN,
	MAINTENANCE

}

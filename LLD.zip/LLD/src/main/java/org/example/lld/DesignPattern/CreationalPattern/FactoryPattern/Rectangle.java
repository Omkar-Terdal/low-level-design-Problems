package org.example.lld.DesignPattern.CreationalPattern.FactoryPattern;

public class Rectangle implements Shape {
	@Override
	public void draw() {
		System.out.println("Drawing Rectangle");
	}
}

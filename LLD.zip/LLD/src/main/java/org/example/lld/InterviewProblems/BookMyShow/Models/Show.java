package org.example.lld.InterviewProblems.BookMyShow.Models;

import java.time.LocalDateTime;
import java.util.List;

public class Show {
	private Long showId;
	private Movie movie;
	private Screen screen;
	private LocalDateTime startTime;
	private LocalDateTime endTime;
	private List<Seat> seats;

	public Show(Long showId, Movie movie, Screen screen, LocalDateTime startTime, LocalDateTime endTime, List<Seat> seats) {
		this.showId = showId;
		this.movie = movie;
		this.screen = screen;
		this.startTime = startTime;
		this.endTime = endTime;
		this.seats = seats;
	}

	public Long getShowId() {
		return showId;
	}
	public Movie getMovie() {
		return movie;
	}
	public Screen getScreen() {
		return screen;
	}
	public LocalDateTime getStartTime() {
		return startTime;
	}
	public LocalDateTime getEndTime() {
		return endTime;
	}
	public List<Seat> getSeats() {
		return seats;
	}
}

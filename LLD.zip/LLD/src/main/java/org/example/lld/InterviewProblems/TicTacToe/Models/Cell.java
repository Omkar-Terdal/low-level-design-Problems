package org.example.lld.InterviewProblems.TicTacToe.Models;

import org.example.lld.InterviewProblems.TicTacToe.Enums.PieceType;

public class Cell {
	private int row;
	private int col;
	private PlayingPiece piece;

	public Cell(int row, int col) {
		this.row = row;
		this.col = col;
		this.piece = null;

	}

	public PlayingPiece getPiece() {
		return piece;
	}
	public void setPiece(PlayingPiece piece) {
		this.piece = piece;
	}
}

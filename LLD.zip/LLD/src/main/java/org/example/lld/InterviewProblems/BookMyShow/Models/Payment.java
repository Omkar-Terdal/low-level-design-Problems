package org.example.lld.InterviewProblems.BookMyShow.Models;

import org.example.lld.InterviewProblems.BookMyShow.Enums.PaymentMethod;
import org.example.lld.InterviewProblems.BookMyShow.Enums.PaymentStatus;

public class Payment {
	private int paymentId;
	private double amount;
	private PaymentMethod paymentMethod;
	private PaymentStatus paymentStatus;

	public Payment(int paymentId, double amount, PaymentMethod paymentMethod, PaymentStatus paymentStatus) {
		this.paymentId = paymentId;
		this.amount = amount;
		this.paymentMethod = paymentMethod;
		this.paymentStatus = paymentStatus;

	}

	public int getPaymentId() {
		return paymentId;
	}
	public double getAmount() {
		return amount;
	}
	public PaymentMethod getPaymentMethod() {
		return paymentMethod;
	}
	public PaymentStatus getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(PaymentStatus paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

}

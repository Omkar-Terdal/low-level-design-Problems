package org.example.lld.InterviewProblems.CarRental;

import org.example.lld.InterviewProblems.CarRental.Enums.CarType;
import org.example.lld.InterviewProblems.CarRental.Models.Car;
import org.example.lld.InterviewProblems.CarRental.Models.Customer;
import org.example.lld.InterviewProblems.CarRental.Models.Payment;
import org.example.lld.InterviewProblems.CarRental.Models.Reservation;
import org.example.lld.InterviewProblems.CarRental.Models.Store;
import org.example.lld.InterviewProblems.CarRental.Service.CarRentalService;
import org.example.lld.InterviewProblems.CarRental.Strategy.DailyPricingStrategy;

import java.time.LocalDate;
import java.util.List;

public class CarRentalMain {
	public static void main(String[] args) {

		CarRentalService service = new CarRentalService(new DailyPricingStrategy());

		// ---- stores + inventory ----
		Store pune = new Store("S1", "Pune - Kharadi", "Pune");
		pune.addCar(new Car("C1", "MH12AB1111", CarType.SEDAN, 2000, "S1"));
		pune.addCar(new Car("C2", "MH12AB2222", CarType.SUV, 3500, "S1"));

		Store mumbai = new Store("S2", "Mumbai - Andheri", "Mumbai");
		mumbai.addCar(new Car("C3", "MH01CD3333", CarType.SEDAN, 2200, "S2"));

		service.addStore(pune);
		service.addStore(mumbai);

		Customer customer = new Customer("U1", "Omkar", "DL-1234567");

		LocalDate start = LocalDate.now().plusDays(1);
		LocalDate end = LocalDate.now().plusDays(4);

		// ---- search ----
		List<Car> available = service.searchCars("Pune", CarType.SEDAN, start, end);
		System.out.println("Available SEDANs in Pune : " + available.size());

		// ---- reserve ----
		Reservation reservation = service.createReservation(customer, "C1", start, end);
		System.out.println("Reservation : " + reservation.getReservationId()
				+ " | status " + reservation.getStatus());

		// second search should now skip C1
		System.out.println("Available SEDANs in Pune after booking : "
				+ service.searchCars("Pune", CarType.SEDAN, start, end).size());

		// ---- pickup ----
		service.pickupCar(reservation.getReservationId());
		System.out.println("After pickup : " + reservation.getStatus());

		// ---- return + pay ----
		Payment payment = service.returnCar(reservation.getReservationId());
		System.out.println("After return : " + reservation.getStatus());
		System.out.println("Days billed  : " + reservation.getDays());
		System.out.println("Amount       : " + payment.getAmount()
				+ " | " + payment.getStatus());
	}
}

package org.example.lld.InterviewProblems.Splitwise.SplitStratergy;

import org.example.lld.InterviewProblems.Splitwise.Models.Expense;
import org.example.lld.InterviewProblems.Splitwise.Models.Split;

import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.List;

public class ExactSplitStrategy implements SplitStrategry {

	@Override
	public void calculatePrice(double amount,List<Split> splitList) {
		double total=0.0;
		for(Split split : splitList) {
			total+=split.getAmount();
		}
		if(Math.abs(total-amount)>0.01) {
			throw new IllegalArgumentException("Invalid Exact Split");
		}
	}
}

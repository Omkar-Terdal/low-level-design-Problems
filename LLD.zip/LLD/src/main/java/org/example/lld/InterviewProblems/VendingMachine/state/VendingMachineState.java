package org.example.lld.InterviewProblems.VendingMachine.state;

import org.example.lld.InterviewProblems.VendingMachine.machine.VendingMachine;
import org.example.lld.InterviewProblems.VendingMachine.model.Product;

public interface VendingMachineState {
	void selectProduct(VendingMachine machine, Product product);
	void insertMoney(VendingMachine machine, double amount);
	void dispenseProduct(VendingMachine machine);
	void cancelTransaction(VendingMachine machine);
}

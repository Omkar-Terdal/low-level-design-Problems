package org.example.lld.InterviewProblems.ParkingLotSystem.Models;

import org.example.lld.InterviewProblems.ParkingLotSystem.Enums.VehicelType;

public class Vehicle {

	private String vehicleNumberPlate;
	private final VehicelType vehicelType;

	public Vehicle(String vehicleNumberPlate, VehicelType vehicelType) {
		this.vehicleNumberPlate = vehicleNumberPlate;
		this.vehicelType = vehicelType;
	}

	public VehicelType getVehicleType() {
		return vehicelType;
	}

	public String getVehiclePlateNumber() {
		return vehicleNumberPlate;
	}


}

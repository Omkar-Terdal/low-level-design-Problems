package org.example.lld.InterviewProblems.VendingMachinee60min.Models;

class InventoryItem {

	private final Product product;
	private int quantity;

	public InventoryItem(Product product, int quantity) {
		this.product = product;
		this.quantity = quantity;
	}

	public Product getProduct() {
		return product;
	}

	public int getQuantity() {
		return quantity;
	}

	public void increase(int amount) {
		quantity += amount;
	}

	public void decrease() {
		if (quantity <= 0) {
			throw new IllegalStateException("Out of stock");
		}
		quantity--;
	}
}

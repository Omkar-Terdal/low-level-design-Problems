package org.example.lld.InterviewProblems.CarRental.Enums;

public enum ReservationStatus {
	SCHEDULED,
	ONGOING,
	COMPLETED,
	CANCELLED
}

package org.example.lld.DesignPattern.BehaviouralPattern.ObserverPattern;

public class Subscribe implements Observer{

	private String name;

	public Subscribe(String name){
		this.name = name;
	}

	@Override
	public void update() {
		System.out.println(name+ " Received notification");
	}
}



package org.example.lld.InterviewProblems.BookMyShow.Enums;

public enum SeatStatus {
	AVAILABLE,
	LOCKED,
	BOOKED
}

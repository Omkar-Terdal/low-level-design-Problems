package org.example.lld.InterviewProblems.BookMyShow.Models;

import java.util.ArrayList;
import java.util.List;

public class Screen {
	private Long screenId;
	private List<Seat> seatList;
	private List<Show> showList;

	public Screen(Long screenId) {
		this.screenId = screenId;
		this.seatList = new ArrayList<>();
		this.showList = new ArrayList<>();
	}

	public Long getScreenId() {
		return screenId;
	}

	public List<Seat> getSeatsList() {
		return seatList;
	}
	public List<Show> getShowsList() {
		return showList;
	}
	public void addSeats(Seat seat) {
		this.seatList.add(seat);
	}
	public void addShows(Show show) {
		this.showList.add(show);
	}

	@Override
	public String toString() {
		return "Screen{" +
				"screenId=" + screenId +
				", seats=" + seatList.size() +
				", shows=" + showList.size() +
				'}';
	}
}

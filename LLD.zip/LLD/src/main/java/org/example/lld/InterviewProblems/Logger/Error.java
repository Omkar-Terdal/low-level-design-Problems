package org.example.lld.InterviewProblems.Logger;

public class Error extends LogProcesser{

	Error(LogProcesser nextLogProcessor){
		super(nextLogProcessor);
	}

	public void log(int level,String message){
		if(level==ERROR){
			System.out.println(level+":"+message);
		}else{
			super.log(level,message);
		}
	}
}

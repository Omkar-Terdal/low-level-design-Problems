package org.example.lld.InterviewProblems.LeaveManagement.Models;

import org.example.lld.InterviewProblems.LeaveManagement.Enums.LeaveType;

import java.util.Map;

public class Employee {
	private String employerId;
	private String employerName;

	private Map<LeaveType,Integer> leaveBalance;
	private Employee manager;

	public Employee(String employerId, String employerName, Map<LeaveType, Integer> leaveBalance, Employee manager) {
		this.employerId = employerId;
		this.employerName = employerName;
		this.leaveBalance = leaveBalance;
		this.manager = manager;
	}
	public String employerId() {
		return employerId;
	}

	public void setEmployerId(String employerId) {
		this.employerId = employerId;
	}

	public String employerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public Map<LeaveType, Integer> leaveBalance() {
		return leaveBalance;
	}

	public void setLeaveBalance(Map<LeaveType, Integer> leaveBalance) {
		this.leaveBalance = leaveBalance;
	}

	public Employee manager() {
		return manager;
	}

	public void setManager(Employee manager) {
		this.manager = manager;
	}



}

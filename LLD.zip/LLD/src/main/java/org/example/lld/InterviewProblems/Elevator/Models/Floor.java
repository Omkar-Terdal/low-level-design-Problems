package org.example.lld.InterviewProblems.Elevator.Models;

import org.example.lld.InterviewProblems.Elevator.Enums.Direction;

public class Floor {
	private int floorNumber;
	private HallButton upButton;
	private HallButton downButton;

	public Floor(int floorNumber,int totalFloors) {
		this.floorNumber = floorNumber;

		// Ground Floor
		if (floorNumber == 0) {
			this.upButton = new HallButton(Direction.UP, floorNumber);
			this.downButton = null;
		}

		// Top Floor
		else if (floorNumber == totalFloors - 1) {
			this.upButton = null;
			this.downButton = new HallButton(Direction.DOWN, floorNumber);
		}

		// Middle Floors
		else {
			this.upButton = new HallButton(Direction.UP, floorNumber);
			this.downButton = new HallButton(Direction.DOWN, floorNumber);
		}
	}

	public int getFloorNumber() {
		return floorNumber;
	}
	public HallButton getUpButton() {
		return upButton;
	}
	public HallButton getDownButton() {
		return downButton;
	}

	@Override
	public String toString() {
		return "Floor{" +
				", floorNumber=" + floorNumber +
				'}';
	}
}

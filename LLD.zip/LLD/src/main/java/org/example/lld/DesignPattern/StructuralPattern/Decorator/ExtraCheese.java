package org.example.lld.DesignPattern.StructuralPattern.Decorator;

public class ExtraCheese extends ToppingsDecorator{

	 BasePizza pizza;

	 public ExtraCheese(BasePizza pizza) {
		 this.pizza = pizza;
	 }
	 @Override
	 public int cost() {
		 return this.pizza.cost() +20;
	 }
}

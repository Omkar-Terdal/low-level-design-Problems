package org.example.lld.InterviewProblems.LeaveManagement.Enums;

public enum LeaveType {
	EARNED_LEAVE,
	CASUAL_LEAVE,
	SICK_LEAVE
}

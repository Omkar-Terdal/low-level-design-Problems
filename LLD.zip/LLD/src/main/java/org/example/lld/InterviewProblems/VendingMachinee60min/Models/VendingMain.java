package org.example.lld.InterviewProblems.VendingMachinee60min.Models;

public class VendingMain {

	public static void main(String[] args) {

		// -----------------------------
		// Create inventory
		// -----------------------------

		Inventory inventory = new Inventory();

		Product coke = new Product(
				"P1",
				"Coke",
				25
		);

		Product chips = new Product(
				"P2",
				"Chips",
				40
		);

		Product water = new Product(
				"P3",
				"Water",
				20
		);

		inventory.addProduct(coke, 5);
		inventory.addProduct(chips, 3);
		inventory.addProduct(water, 2);


		// -----------------------------
		// Create vending machine
		// -----------------------------

		VendingMachine machine =
				new VendingMachine(inventory);


		// -----------------------------
		// Display products
		// -----------------------------

		System.out.println("===== PRODUCTS =====");

		inventory.displayProducts();


		// -----------------------------
		// Successful purchase
		// -----------------------------

		System.out.println(
				"\n===== PURCHASE COKE ====="
		);

		machine.selectProduct("P1");

		machine.insertMoney(30);

		machine.dispense();


		// -----------------------------
		// Check inventory
		// -----------------------------

		System.out.println(
				"\n===== INVENTORY AFTER PURCHASE ====="
		);

		inventory.displayProducts();


		// -----------------------------
		// Insufficient money
		// -----------------------------

		System.out.println(
				"\n===== INSUFFICIENT MONEY ====="
		);

		machine.selectProduct("P2");

		machine.insertMoney(20);

		try {
			machine.dispense();
		} catch (Exception e) {
			System.out.println(
					"Error: " + e.getMessage()
			);
		}


		// -----------------------------
		// Add more money
		// -----------------------------

		System.out.println(
				"\n===== ADD MORE MONEY ====="
		);

		machine.insertMoney(20);

		machine.dispense();


		// -----------------------------
		// Cancel transaction
		// -----------------------------

		System.out.println(
				"\n===== CANCEL ====="
		);

		machine.selectProduct("P3");

		machine.insertMoney(10);

		machine.cancel();


		// -----------------------------
		// Out of stock example
		// -----------------------------

		System.out.println(
				"\n===== OUT OF STOCK ====="
		);

		Inventory smallInventory = new Inventory();

		Product biscuit = new Product(
				"P4",
				"Biscuit",
				10
		);

		smallInventory.addProduct(biscuit, 1);

		VendingMachine smallMachine =
				new VendingMachine(smallInventory);

		smallMachine.selectProduct("P4");
		smallMachine.insertMoney(10);
		smallMachine.dispense();

		// Now P4 is out of stock.
		try {
			smallMachine.selectProduct("P4");
		} catch (Exception e) {
			System.out.println(
					"Error: " + e.getMessage()
			);
		}
	}
}

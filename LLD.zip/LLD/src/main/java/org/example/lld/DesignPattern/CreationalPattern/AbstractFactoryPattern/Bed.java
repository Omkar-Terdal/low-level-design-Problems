package org.example.lld.DesignPattern.CreationalPattern.AbstractFactoryPattern;

public interface Bed {
	void lieOn();
}

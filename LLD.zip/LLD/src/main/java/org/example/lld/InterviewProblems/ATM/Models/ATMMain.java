package org.example.lld.InterviewProblems.ATM.Models;


public class ATMMain {
	public static void main(String[] args) {
		Account account=new Account(1000.0,"123456");
		Card card=new Card("13456426",8805, account);

		CashDispenser cashDispenser=new CashDispenser();
		cashDispenser.addNotes(500,10);
		cashDispenser.addNotes(200,20);
		cashDispenser.addNotes(100,30);
		CardReader cardReader=new CardReader(card);

		Screen screen=new Screen();
		screen.displayMessage("Processing");

		ATM atm = new ATM(cardReader,screen,cashDispenser);

		System.out.println(atm.checkBalance());
		atm.authenticateCard(8805);
		atm.insertCard(card);
		atm.withDraw(200);
		atm.checkBalance();

	}
}


package org.example.lld.InterviewProblems.BookMyShow.Enums;

public enum PaymentStatus {
	PENDING,
	SUCCESS,
	FAILED
}

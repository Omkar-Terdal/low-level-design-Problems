package org.example.lld.InterviewProblems.CarRental.Models;

import org.example.lld.InterviewProblems.CarRental.Enums.PaymentStatus;

public class Payment {
	private final String paymentId;
	private final String reservationId;
	private final double amount;
	private PaymentStatus status;

	public Payment(String paymentId, String reservationId, double amount) {
		this.paymentId = paymentId;
		this.reservationId = reservationId;
		this.amount = amount;
		this.status = PaymentStatus.PENDING;
	}

	public String getPaymentId() {
		return paymentId;
	}

	public String getReservationId() {
		return reservationId;
	}

	public double getAmount() {
		return amount;
	}

	public PaymentStatus getStatus() {
		return status;
	}

	public void setStatus(PaymentStatus status) {
		this.status = status;
	}
}

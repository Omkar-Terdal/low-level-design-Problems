package org.example.lld.InterviewProblems.VendingMachine.state;

import org.example.lld.InterviewProblems.VendingMachine.machine.VendingMachine;
import org.example.lld.InterviewProblems.VendingMachine.model.Product;

public class MoneyInsertedState implements VendingMachineState {

	@Override
	public void selectProduct(VendingMachine machine, Product product) {
		System.out.println("Cannot select a new product now, dispense or cancel first");
	}

	@Override
	public void insertMoney(VendingMachine machine, double amount) {
		System.out.println("Money already sufficient, proceed to dispense");
	}

	@Override
	public void dispenseProduct(VendingMachine machine) {
		machine.setState(new DispensingState());
		machine.getCurrentState().dispenseProduct(machine);
	}

	@Override
	public void cancelTransaction(VendingMachine machine) {
		System.out.println("Transaction cancelled, refunding inserted money");
		machine.getPayment().refund(machine.getInsertedAmount());
		machine.setSelectedProduct(null);
		machine.setInsertedAmount(0);
		machine.setState(new IdleState());
	}
}

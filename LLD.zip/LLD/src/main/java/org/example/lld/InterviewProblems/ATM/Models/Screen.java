package org.example.lld.InterviewProblems.ATM.Models;

public class Screen {

	public void displayMessage(String message){
		System.out.println(message);
	}

	public void displayBalance(double balance){
		System.out.println("Balance: "+balance);
	}
	public void displayTrasactionSuccess(double amount){
		System.out.println("Collect the cash: "+amount);
	}

	public void displayError(String error){
		System.out.println("Error: "+error);
	}
}

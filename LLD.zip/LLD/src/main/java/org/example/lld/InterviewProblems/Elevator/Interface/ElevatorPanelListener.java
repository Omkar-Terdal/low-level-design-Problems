package org.example.lld.InterviewProblems.Elevator.Interface;

import org.example.lld.InterviewProblems.Elevator.Models.Elevator;

public interface ElevatorPanelListener {
	void onFloorButtonPressed(Elevator elevator, int destinationFloor);
}

package org.example.lld.DesignPattern.StructuralPattern.Decorator;

public class VegFarmHousePizza extends BasePizza{

	@Override
	public int cost() {
		return 250;
	}
}

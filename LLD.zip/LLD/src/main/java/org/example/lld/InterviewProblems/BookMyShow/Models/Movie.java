package org.example.lld.InterviewProblems.BookMyShow.Models;

import java.util.Objects;

public class Movie {
	private Long movieId;
	private String title;
	private int duration;
	private String language;
	private String genre;

	public Movie(Long movieId, String title, String language, String genre, int duration) {
		this.movieId = movieId;
		this.title = title;
		this.language = language;
		this.genre = genre;
		this.duration = duration;
	}

	public Long getMovieId() {
		return movieId;
	}
	public String getTitle() {
		return title;
	}
	public String getLanguage() {
		return language;
	}
	public String getGenre() {
		return genre;
	}
	public int getDuration() {
		return duration;
	}

	@Override
	public String toString() {
		return "Movie{" +
				"movieId"+ movieId +"\"" + title + "\"" + language + "\"" + genre + "\"" + duration + "\"" +
				'}';
	}

//	@Override
//	public boolean equals(Object o) {
//		if (this == o) return true;
//		if (!(o instanceof Movie)) return false;
//		Movie movie = (Movie) o;
//		return Objects.equals(movieId, movie.movieId);
//	}
//
//	@Override
//	public int hashCode() {
//		return Objects.hash(movieId);
//	}


}

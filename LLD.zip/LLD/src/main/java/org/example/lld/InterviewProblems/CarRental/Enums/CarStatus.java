package org.example.lld.InterviewProblems.CarRental.Enums;

public enum CarStatus {
	AVAILABLE,
	RESERVED,
	RENTED,
	UNDER_MAINTENANCE
}

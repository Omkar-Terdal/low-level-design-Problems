package org.example.lld.DesignPattern.CreationalPattern.AbstractFactoryPattern;

public class ModernBed implements Bed {
	@Override
	public void lieOn() {
		System.out.println("laying on modern bed");
	}
}

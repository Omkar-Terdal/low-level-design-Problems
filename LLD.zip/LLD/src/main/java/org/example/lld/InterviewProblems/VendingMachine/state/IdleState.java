package org.example.lld.InterviewProblems.VendingMachine.state;

import org.example.lld.InterviewProblems.VendingMachine.machine.VendingMachine;
import org.example.lld.InterviewProblems.VendingMachine.model.Product;

public class IdleState implements VendingMachineState {

	@Override
	public void selectProduct(VendingMachine machine, Product product) {
		if (!machine.getInventory().isAvailable(product)) {
			System.out.println(product.getName() + " is out of stock");
			return;
		}
		machine.setSelectedProduct(product);
		machine.setState(new ProductSelectedState());
		System.out.println(product.getName() + " selected. Price: " + product.getPrice());
	}

	@Override
	public void insertMoney(VendingMachine machine, double amount) {
		System.out.println("Please select a product first");
	}

	@Override
	public void dispenseProduct(VendingMachine machine) {
		System.out.println("Please select a product first");
	}

	@Override
	public void cancelTransaction(VendingMachine machine) {
		System.out.println("Nothing to cancel");
	}
}

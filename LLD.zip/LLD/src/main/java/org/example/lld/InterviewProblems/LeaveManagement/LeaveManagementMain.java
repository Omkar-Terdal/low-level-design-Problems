package org.example.lld.InterviewProblems.LeaveManagement;

import org.example.lld.InterviewProblems.LeaveManagement.Enums.LeaveType;
import org.example.lld.InterviewProblems.LeaveManagement.Models.Employee;
import org.example.lld.InterviewProblems.LeaveManagement.Models.LeaveManagementService;
import org.example.lld.InterviewProblems.LeaveManagement.Models.LeaveRequest;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

public class LeaveManagementMain {
	public static void main(String[] args) {

		// Manager Leave Balance
		Map<LeaveType, Integer> managerBalance = new HashMap<>();
		managerBalance.put(LeaveType.CASUAL_LEAVE, 20);
		managerBalance.put(LeaveType.SICK_LEAVE, 15);
		managerBalance.put(LeaveType.EARNED_LEAVE, 25);

		// Employee Leave Balance
		Map<LeaveType, Integer> employeeBalance = new HashMap<>();
		employeeBalance.put(LeaveType.CASUAL_LEAVE, 10);
		employeeBalance.put(LeaveType.SICK_LEAVE, 8);
		employeeBalance.put(LeaveType.EARNED_LEAVE, 15);

		// Create Manager
		Employee manager = new Employee(
				"M101",
				"Rahul",
				managerBalance,
				null
		);

		// Create Employee
		Employee employee = new Employee(
				"E101",
				"Omkar",
				employeeBalance,
				manager
		);

		LeaveManagementService service = new LeaveManagementService();

		// Register Employees
		service.addEmployee(manager);
		service.addEmployee(employee);

		System.out.println("======================================");
		System.out.println("         APPLY LEAVE");
		System.out.println("======================================");

		LeaveRequest request = service.applyLeave(
				employee,
				LocalDate.of(2026, 8, 10),
				LocalDate.of(2026, 8, 12),
				LeaveType.CASUAL_LEAVE,
				"Family Function"
		);

		System.out.println("Request Id : " + request.getReqId());
		System.out.println("Status     : " + request.getLeaveStatus());

		System.out.println("\n======================================");
		System.out.println("       LEAVE BALANCE");
		System.out.println("======================================");

		service.getLeaveBalance(employee)
				.forEach((type, count) ->
						System.out.println(type + " : " + count));

		System.out.println("\n======================================");
		System.out.println("     PENDING REQUESTS");
		System.out.println("======================================");

		for (LeaveRequest leave : service.getPendingRequests(manager)) {
			System.out.println(
					leave.getReqId() + " | " +
							leave.getEmployee().employerName() + " | " +
							leave.getLeaveStatus()
			);
		}

		System.out.println("\n======================================");
		System.out.println("       APPROVE LEAVE");
		System.out.println("======================================");

		service.approveLeave(request.getReqId(), manager);

		System.out.println("Status : " + request.getLeaveStatus());

		System.out.println("\n======================================");
		System.out.println(" BALANCE AFTER APPROVAL");
		System.out.println("======================================");

		service.getLeaveBalance(employee)
				.forEach((type, count) ->
						System.out.println(type + " : " + count));

		System.out.println("\n======================================");
		System.out.println("       CANCEL LEAVE");
		System.out.println("======================================");

		service.cancelLeave(request.getReqId(), employee);

		System.out.println("Status : " + request.getLeaveStatus());

		System.out.println("\n======================================");
		System.out.println(" BALANCE AFTER CANCELLATION");
		System.out.println("======================================");

		service.getLeaveBalance(employee)
				.forEach((type, count) ->
						System.out.println(type + " : " + count));

		System.out.println("\n======================================");
		System.out.println("      PENDING REQUESTS");
		System.out.println("======================================");

		System.out.println(service.getPendingRequests(manager).size());
	}
}

package org.example.lld.InterviewProblems.ParkingLotSystem.Models;

import org.example.lld.InterviewProblems.ParkingLotSystem.Enums.VehicelType;

public class Bike extends Vehicle {

	public Bike(String VehiclePlateNumber, VehicelType vehicelType) {
		super(VehiclePlateNumber, VehicelType.BIKE);
	}
}

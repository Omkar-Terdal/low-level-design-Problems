package org.example.lld.InterviewProblems.CarRental.Service;

import org.example.lld.InterviewProblems.CarRental.Enums.CarStatus;
import org.example.lld.InterviewProblems.CarRental.Enums.CarType;
import org.example.lld.InterviewProblems.CarRental.Enums.PaymentStatus;
import org.example.lld.InterviewProblems.CarRental.Enums.ReservationStatus;
import org.example.lld.InterviewProblems.CarRental.Models.*;
import org.example.lld.InterviewProblems.CarRental.Strategy.PricingStrategy;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Facade + in-memory repositories. Single entry point for the whole flow:
 * search -> reserve -> pickup -> return(+pay), plus cancel.
 */
public class CarRentalService {

	private final Map<String, Store> stores = new HashMap<>();
	private final Map<String, Reservation> reservations = new HashMap<>();
	private final Map<String, Payment> payments = new HashMap<>();
	private final PricingStrategy pricingStrategy;

	public CarRentalService(PricingStrategy pricingStrategy) {
		this.pricingStrategy = pricingStrategy;
	}

	public void addStore(Store store) {
		stores.put(store.getStoreId(), store);
	}

	/** Cars of the given type in the given city that are free for the whole [start, end] window. */
	public List<Car> searchCars(String city, CarType type, LocalDate start, LocalDate end) {
		validateDates(start, end);
		List<Car> result = new ArrayList<>();
		for (Store store : stores.values()) {
			if (!store.getCity().equalsIgnoreCase(city)) {
				continue;
			}
			for (Car car : store.getCars()) {
				if (car.getType() == type
						&& car.getStatus() != CarStatus.UNDER_MAINTENANCE
						&& isFree(car, start, end)) {
					result.add(car);
				}
			}
		}
		return result;
	}

	public Reservation createReservation(Customer customer, String carId,
	                                     LocalDate start, LocalDate end) {
		validateDates(start, end);
		Car car = findCar(carId);

		if (car.getStatus() == CarStatus.UNDER_MAINTENANCE) {
			throw new IllegalStateException("Car is under maintenance");
		}
		if (!isFree(car, start, end)) {
			throw new IllegalStateException("Car is not available for the selected dates");
		}

		Reservation reservation = new Reservation(
				UUID.randomUUID().toString(), customer, car, start, end);
		reservations.put(reservation.getReservationId(), reservation);
		car.setStatus(CarStatus.RESERVED);
		return reservation;
	}

	public void cancelReservation(String reservationId) {
		Reservation reservation = getReservation(reservationId);
		if (reservation.getStatus() != ReservationStatus.SCHEDULED) {
			throw new IllegalStateException("Only a SCHEDULED reservation can be cancelled");
		}
		reservation.setStatus(ReservationStatus.CANCELLED);
		reservation.getCar().setStatus(CarStatus.AVAILABLE);
	}

	public void pickupCar(String reservationId) {
		Reservation reservation = getReservation(reservationId);
		if (reservation.getStatus() != ReservationStatus.SCHEDULED) {
			throw new IllegalStateException("Reservation is not in SCHEDULED state");
		}
		reservation.setStatus(ReservationStatus.ONGOING);
		reservation.getCar().setStatus(CarStatus.RENTED);
	}

	/** Close the rental, price it, record a paid Payment. */
	public Payment returnCar(String reservationId) {
		Reservation reservation = getReservation(reservationId);
		if (reservation.getStatus() != ReservationStatus.ONGOING) {
			throw new IllegalStateException("Reservation is not ONGOING");
		}

		reservation.setStatus(ReservationStatus.COMPLETED);
		reservation.getCar().setStatus(CarStatus.AVAILABLE);

		double amount = pricingStrategy.calculatePrice(reservation.getCar(), reservation.getDays());
		Payment payment = new Payment(
				UUID.randomUUID().toString(), reservationId, amount);
		payment.setStatus(PaymentStatus.PAID);
		payments.put(payment.getPaymentId(), payment);
		return payment;
	}

	// ---------- helpers ----------

	private boolean isFree(Car car, LocalDate start, LocalDate end) {
		for (Reservation r : reservations.values()) {
			if (!r.getCar().getCarId().equals(car.getCarId())) {
				continue;
			}
			if (r.getStatus() == ReservationStatus.SCHEDULED
					|| r.getStatus() == ReservationStatus.ONGOING) {
				if (r.overlaps(start, end)) {
					return false;
				}
			}
		}
		return true;
	}

	private Car findCar(String carId) {
		for (Store store : stores.values()) {
			for (Car car : store.getCars()) {
				if (car.getCarId().equals(carId)) {
					return car;
				}
			}
		}
		throw new IllegalArgumentException("Car not found: " + carId);
	}

	private Reservation getReservation(String reservationId) {
		Reservation reservation = reservations.get(reservationId);
		if (reservation == null) {
			throw new IllegalArgumentException("Reservation not found: " + reservationId);
		}
		return reservation;
	}

	private void validateDates(LocalDate start, LocalDate end) {
		if (start == null || end == null || start.isAfter(end)) {
			throw new IllegalArgumentException("Invalid date range");
		}
		if (start.isBefore(LocalDate.now())) {
			throw new IllegalArgumentException("Start date is in the past");
		}
	}
}

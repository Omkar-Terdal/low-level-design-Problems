package org.example.lld.DesignPattern.BehaviouralPattern.StratergryPattern.WithStratergyPattern;


import org.example.lld.DesignPattern.BehaviouralPattern.StratergryPattern.WithStratergyPattern.Stratergy.NormalDriveStratergy;

public class OffRoadVehicle extends Vehicle {

	OffRoadVehicle() {
		super(new NormalDriveStratergy());
	}
}

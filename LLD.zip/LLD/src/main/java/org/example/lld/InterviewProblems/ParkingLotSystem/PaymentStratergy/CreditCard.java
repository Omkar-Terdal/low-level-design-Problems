package org.example.lld.InterviewProblems.ParkingLotSystem.PaymentStratergy;

public class CreditCard implements PaymentStratergy {
	@Override
	public void pay(double amount) {
		System.out.println("Paid ₹"+ amount +"using CreditCard");
	}
}

package org.example.lld.DesignPattern.BehaviouralPattern.StratergryPattern.WithStratergyPattern.Stratergy;

public class SportsDriveStratergy implements DriverStratergy {

	@Override
	public void drive() {
		System.out.println("Sports drive");
	}
}

package org.example.lld.DesignPattern.BehaviouralPattern.StratergryPattern.WithStratergyPattern.Stratergy;



public class NormalDriveStratergy implements DriverStratergy {

	@Override
	public void drive() {
		System.out.println("Normal Drive");
	}
}

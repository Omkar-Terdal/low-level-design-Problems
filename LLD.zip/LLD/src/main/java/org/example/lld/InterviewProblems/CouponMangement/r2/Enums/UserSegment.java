package org.example.lld.InterviewProblems.CouponMangement.r2.Enums;

public enum UserSegment {
	GOLD,
	DIAMOND,
	PREMIUM

}

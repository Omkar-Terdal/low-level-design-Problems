package org.example.lld.InterviewProblems.Splitwise.Models;

public class User {
	private Long id;
	private String name;
	private String email;
	private BalanceSheet balanceSheet;

	public User(Long id, String name, String email) {
		this.id = id;
		this.name = name;
		this.email = email;
		this.balanceSheet=new BalanceSheet();
	}
	public Long getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public String getEmail() {
		return email;
	}
	public BalanceSheet getBalanceSheet() {
		return balanceSheet;
	}

	public void setBalanceSheet(BalanceSheet balanceSheet) {
		this.balanceSheet = balanceSheet;
	}

	@Override
	public String toString() {
		return "User{" +
				"name='" + name + '\'' +
				'}';
	}
}

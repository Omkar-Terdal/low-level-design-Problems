package org.example.lld.DesignPattern.CreationalPattern.AbstractFactoryPattern;

 interface FurnitureFactory {
	 Chair createChair();
	 Bed createBed();
}

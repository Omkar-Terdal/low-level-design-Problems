package org.example.lld.InterviewProblems.ParkingLotSystem.PaymentStratergy;

public class Upi implements PaymentStratergy {
	@Override
	public void pay(double amount) {
		System.out.println("Paid ₹"+ amount +"using Upi");
	}
}

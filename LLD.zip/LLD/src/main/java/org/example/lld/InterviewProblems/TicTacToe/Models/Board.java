package org.example.lld.InterviewProblems.TicTacToe.Models;

public class Board {
	private int size;
	private Cell[][] board;

	public Board(int size) {
		this.size = size;
		board = new Cell[size][size];
		initializeBoard();
	}

	private void initializeBoard() {
		for (int i = 0; i < size; i++) {
			for (int j = 0; j < size; j++) {
				board[i][j] = new Cell(i,j);
			}
		}
	}

	public boolean placePiece(int row,int col,PlayingPiece piece) {
		if(row<0 || row>=size || col<0 || col>=size){
			return false;
		}
		Cell cell = board[row][col];
		if(cell.getPiece()!=null){
			return false;
		}
		cell.setPiece(piece);
		return true;
	}

	public void  printBoard() {
		for (int i = 0; i < size; i++) {
			for (int j = 0; j < size; j++) {
				Cell cell = board[i][j];
				if(cell.getPiece()!=null){
					System.out.print(cell.getPiece().getType()+ " ");
				}else{
					System.out.print("_ ");
				}
			}
			System.out.println();
		}
		System.out.println();

	}

	public boolean checkWinner(int row,int col,PlayingPiece piece) {

		boolean rowMatch = rowCheck(row,col,piece);
		boolean colMatch = colCheck(row,col,piece);
		boolean diagonalMatch = diagonalCheck(row,col,piece);
		boolean antiDiagonalMatch = antiDiagonalCheck(row,col,piece);

		return rowMatch || colMatch || diagonalMatch || antiDiagonalMatch;
	}

	private boolean rowCheck(int row,int col,PlayingPiece piece) {
		boolean rowMatch =true;
		for(int j=0;j<size;j++){
			Cell cell = board[row][j];
			if(cell.getPiece()==null || cell.getPiece().getType()!=piece.getType()){
				rowMatch= false;
				break;
			}
		}
		return rowMatch;
	}

	private boolean colCheck(int row,int col,PlayingPiece piece) {
		boolean colMatch =true;
		for(int i=0;i<size;i++){
			Cell cell = board[i][col];
			if(cell.getPiece()==null || cell.getPiece().getType()!=piece.getType()){
				colMatch= false;
				break;
			}
		}
		return colMatch;
	}

	private boolean diagonalCheck(int row,int col,PlayingPiece piece) {
		boolean diagonalMatch =true;
		if(row==col){
			for(int i=0;i<size;i++){
				Cell cell = board[i][i];
				if(cell.getPiece()==null ||cell.getPiece().getType()!=piece.getType()){
					diagonalMatch= false;
					break;
				}
			}
		}else {
			diagonalMatch= false;
		}
		return diagonalMatch;
	}

	private boolean antiDiagonalCheck(int row,int col,PlayingPiece piece) {
		boolean antiDiagonalMatch =true;
		if(row+col==size-1){
			for(int i=0;i<size;i++){
				Cell cell = board[i][size-1-i];
				if(cell.getPiece()==null || cell.getPiece().getType()!=piece.getType()){
					antiDiagonalMatch= false;
					break;
				}
			}
		}else{
			antiDiagonalMatch= false;
		}
		return antiDiagonalMatch;
	}

	public boolean isBoardFull() {
		for (int i = 0; i < size; i++) {
			for (int j = 0; j < size; j++) {
				Cell cell = board[i][j];
				if(cell.getPiece()==null){
					return false;
				}
			}
		}
		return true;
	}




}


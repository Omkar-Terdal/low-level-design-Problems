package org.example.lld.InterviewProblems.Splitwise;

import org.example.lld.InterviewProblems.Splitwise.Models.*;
import org.example.lld.InterviewProblems.Splitwise.Service.ExpenseService;
import org.example.lld.InterviewProblems.Splitwise.SplitStratergy.EqualSplitStrategy;
import org.example.lld.InterviewProblems.Splitwise.SplitStratergy.ExactSplitStrategy;
import org.example.lld.InterviewProblems.Splitwise.SplitStratergy.PercentageSplitStratergy;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SplitWiseMain {
	public static void main(String[] args) {
		List<User> userList=new ArrayList<>(Arrays.asList(
				new User(1L,"Omkar","omkar@gmail.com"),
				new User(2L,"Rahul","Rahul@gmail.com"),
				new User(3L,"Ankit","Ankit@gmail.com"),
				new User(4L,"Pratheek","Pratheek@gmail.com")
		));
		Group group=new Group(1L,"Goa Trip");
		group.setUsers(userList);

		List<Split> equalSplitList=new ArrayList<>(Arrays.asList(
				new EqualSplit(userList.get(0)),
				new EqualSplit(userList.get(1)),
				new EqualSplit(userList.get(2)),
				new EqualSplit(userList.get(3))
		));

		ExpenseService expenseService=new ExpenseService();
		Expense breakFastExpense= expenseService.addExpense(1L,"BreakFast",1000.00,userList.get(0),equalSplitList,new EqualSplitStrategy());
		group.setExpenses(breakFastExpense);


		List<Split> exactSplitList=new ArrayList<>(Arrays.asList(
				new ExactSplit(userList.get(0),300),
				new ExactSplit(userList.get(1),300),
				new ExactSplit(userList.get(2),400),
				new ExactSplit(userList.get(3),200)
		));

		Expense lunchExpense=expenseService.addExpense(2L,"Lunch",1200.00,userList.get(0),exactSplitList,new ExactSplitStrategy());
		group.setExpenses(lunchExpense);


		List<Split> percentageSplitList=new ArrayList<>(Arrays.asList(
				new PercentageSplit(userList.get(0),20),
				new PercentageSplit(userList.get(1),20),
				new PercentageSplit(userList.get(2),30),
				new PercentageSplit(userList.get(3),30)
		));

		Expense dinnerExpense=expenseService.addExpense(3L,"Dinner",1000.00,userList.get(0),percentageSplitList,new PercentageSplitStratergy());

		group.setExpenses(dinnerExpense);

		System.out.println("\n===== GROUP EXPENSES =====");

		group.getExpenses().forEach(System.out::println);
		System.out.println();
		for (User user : userList) {
			user.getBalanceSheet().getAmountToPay()
					.forEach((creditor, amt) -> System.out.printf("%s owes %s: %.2f%n", user.getName(), creditor.getName(), amt));
		}

	}

}

package org.example.lld.InterviewProblems.Splitwise.Models;

public class PercentageSplit extends Split {

	private double percentage;

	public PercentageSplit(User user,double percentage) {
		super(user,0);
		this.percentage=percentage;
	}

	public double getPercentage(){
		return percentage;
	}
	public void setPercentage(double percentage){
		this.percentage=percentage;
	}

	// PercentageSplit.java — add this method
	@Override
	public String toString() {
		return getUser().getName() + ": " + getAmount() + " (" + percentage + "%)";
	}
}

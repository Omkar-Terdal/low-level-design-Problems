package org.example.lld.InterviewProblems.Splitwise.SplitStratergy;

import org.example.lld.InterviewProblems.Splitwise.Models.Expense;
import org.example.lld.InterviewProblems.Splitwise.Models.Split;
import org.example.lld.InterviewProblems.Splitwise.Models.User;

import java.util.List;

public interface SplitStrategry {

	void calculatePrice(double amount, List<Split>splitList);
}

package org.example.lld.InterviewProblems.Splitwise.Models;

import java.util.ArrayList;
import java.util.List;

public class Group {
	private Long  groupId;
	private String groupName;
	private List<User> usersList;
	private List<Expense> expenseList;


	public Group(Long groupId, String groupName) {
		this.groupId = groupId;
		this.groupName = groupName;
		this.usersList = new ArrayList<>();
		this.expenseList = new ArrayList<>();
	}
	public Long getGroupId() {
		return groupId;
	}
	public String getGroupName() {
		return groupName;
	}
	public List<User> getUsers() {
		return usersList;
	}
	public void setUsers(User user) {
		usersList.add(user);
	}
	public void setExpenses(Expense expense){
		expenseList.add(expense);
	}
	public void setUsers(List<User> users) {
		usersList = users;
	}
	public List<Expense> getExpenses() {
		return expenseList;
	}


	@Override
	public String toString() {
		return "Group{" +
				"groupId=" + groupId +
				", groupName='" + groupName + '\'' +
				", usersList=" + usersList +
				", expenseList=" + expenseList +
				'}';
	}


}

package org.example.lld.InterviewProblems.Logger;

import static org.example.lld.InterviewProblems.Logger.LogProcesser.*;

public class Main {

	public static void main(String[] args) {

		LogProcesser logger=new Info(new Warn(new Error(null)));

		logger.log(ERROR,"Error msg");
		logger.log(WARN,"Warn msg");
		logger.log(INFO,"Info msg");
	}
}

package org.example.lld.InterviewProblems.ParkingLotSystem.Models;

import org.example.lld.InterviewProblems.ParkingLotSystem.Enums.VehicelType;

import java.util.List;

import static org.example.lld.InterviewProblems.ParkingLotSystem.Enums.VehicelType.*;

public class ParkingFloors {
	private List<ParkingSpots> parkingSpotsList;
	private Long floorNumber;
	private int availableCarSpots;
	private int availableBikeSpots;
	private int availableTruckSpots;

	public ParkingFloors(Long floorNumber,List<ParkingSpots> parkingSpotsList) {
			this.parkingSpotsList = parkingSpotsList;
			this.floorNumber=floorNumber;

			initializeAvailableSpots();
	}

	public Long getFloorNumber() {
		return floorNumber;
	}

	private void initializeAvailableSpots(){
		for(ParkingSpots spot :parkingSpotsList){
			switch(spot.getParkingSpotType()){
				case CAR :
					 availableCarSpots++;
					 break;
				case BIKE :
					availableBikeSpots++;
					break;
				case TRUCK:
					availableTruckSpots++;
					break;
				default:
					throw new IllegalStateException("Unexpected value: " + spot.getParkingSpotType());
			}
		}
	}



	public ParkingSpots parkVehicle(Vehicle vehicle) {
		for(ParkingSpots spot : parkingSpotsList) {
			if(spot.canPark(vehicle)){
				spot.parkVehicle(vehicle);
				decrementAvailableSpot(vehicle.getVehicleType());
				return spot;
			}
		}
		return null;
	}

	private  void decrementAvailableSpot(VehicelType vehicleType){
			switch(vehicleType){
				case CAR :
					availableCarSpots--;
					break;
				case BIKE :
					availableBikeSpots--;
					break;
				case TRUCK:
					availableTruckSpots--;
					break;
				default:
					throw new IllegalStateException("Unexpected value: " + vehicleType);
			}
	}

	public boolean removeVehicle(ParkingSpots spot) {
		if(spot.isAvailable()){
			return false;
		}

		spot.removeVehicle();

		VehicelType vehicelType=spot.getParkingSpotType();

		incrementAvailableSpot(vehicelType);

		return true;
	}

	private void incrementAvailableSpot(VehicelType vehicleType){
		switch(vehicleType){
			case CAR :
				availableCarSpots++;
				break;
			case BIKE :
				availableBikeSpots++;
				break;
			case TRUCK:
				availableTruckSpots++;
				break;
			default:
				throw new IllegalStateException("Unexpected value: " + vehicleType);
		}
	}

	public int  getAvailableCarSpots() {
		return availableCarSpots;
	}

	public int getAvailableBikeSpots() {
		return availableBikeSpots;
	}

	public int getAvailableTruckSpots() {
		return availableTruckSpots;
	}

}

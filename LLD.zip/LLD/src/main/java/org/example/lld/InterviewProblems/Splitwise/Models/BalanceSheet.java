package org.example.lld.InterviewProblems.Splitwise.Models;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class BalanceSheet {

	private Map<User,Double> amountToGetBack=new ConcurrentHashMap<>();
	private Map<User,Double> amountToPay=new ConcurrentHashMap<>();

	public Map<User,Double> getAmountToGetBack() {
		return amountToGetBack;
	}
	public Map<User,Double> getAmountToPay() {
		return amountToPay;
	}

	@Override
	public String toString() {
		return "BalanceSheet{" +
				"amountToGetBack=" + amountToGetBack +
				", amountToPay=" + amountToPay +
				'}';
	}
}

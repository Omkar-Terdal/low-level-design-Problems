package org.example.lld.InterviewProblems.LeaveManagement.Models;

import org.example.lld.InterviewProblems.LeaveManagement.Enums.LeaveStatus;
import org.example.lld.InterviewProblems.LeaveManagement.Enums.LeaveType;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class LeaveRequest {
	private String reqId;
	private Employee employee;
	private LeaveType leaveType;
	private LocalDate startTime;
	private LocalDate endTime;
	private LeaveStatus leaveStatus;
	private LocalDateTime applicationTime;
	private String reason;

	public LeaveRequest(String reqId, Employee employee, LeaveType leaveType, LocalDate startTime, LocalDate endTime, LeaveStatus leaveStatus, LocalDateTime applicationTime, String reason) {
		this.reqId = reqId;
		this.employee = employee;
		this.leaveType = leaveType;
		this.startTime = startTime;
		this.endTime = endTime;
		this.leaveStatus = leaveStatus;
		this.applicationTime = applicationTime;
		this.reason = reason;
	}

	public String getReqId() {
		return reqId;
	}

	public LeaveRequest setReqId(String reqId) {
		this.reqId = reqId;
		return this;
	}

	public Employee getEmployee() {
		return employee;
	}

	public LeaveRequest setEmployee(Employee employee) {
		this.employee = employee;
		return this;
	}

	public LeaveType getLeaveType() {
		return leaveType;
	}

	public LeaveRequest setLeaveType(LeaveType leaveType) {
		this.leaveType = leaveType;
		return this;
	}

	public LocalDate getStartTime() {
		return startTime;
	}

	public LeaveRequest setStartTime(LocalDate startTime) {
		this.startTime = startTime;
		return this;
	}

	public LocalDate getEndTime() {
		return endTime;
	}

	public LeaveRequest setEndTime(LocalDate endTime) {
		this.endTime = endTime;
		return this;
	}

	public LeaveStatus getLeaveStatus() {
		return leaveStatus;
	}

	public LeaveRequest setLeaveStatus(LeaveStatus leaveStatus) {
		this.leaveStatus = leaveStatus;
		return this;
	}

	public LocalDateTime getApplicationTime() {
		return applicationTime;
	}

	public LeaveRequest setApplicationTime(LocalDateTime applicationTime) {
		this.applicationTime = applicationTime;
		return this;
	}

	public String getReason() {
		return reason;
	}

	public LeaveRequest setReason(String reason) {
		this.reason = reason;
		return this;
	}
}

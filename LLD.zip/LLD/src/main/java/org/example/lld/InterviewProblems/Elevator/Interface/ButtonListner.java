package org.example.lld.InterviewProblems.Elevator.Interface;

import org.example.lld.InterviewProblems.Elevator.Enums.Direction;

public interface ButtonListner {
	void onPressHallButton(int floorNumber, Direction direction);
}

package org.example.lld.DesignPattern.CreationalPattern.AbstractFactoryPattern;

public class TraditionalChair implements Chair{
	@Override
	public void sitOn() {
		System.out.println("sitting on Traditional Chair");
	}
}

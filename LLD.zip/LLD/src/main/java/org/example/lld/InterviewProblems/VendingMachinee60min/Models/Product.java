package org.example.lld.InterviewProblems.VendingMachinee60min.Models;

public class Product {
	private String id;
	private String name;
	private double price;
	public Product(String id, String productName, double price) {
		this.id = id;
		this.name = productName;
		this.price = price;
	}
	public String getId() {
		return id;
	}

	public Product setId(String id) {
		this.id = id;
		return this;
	}

	public String getProductName() {
		return name;
	}

	public Product setProductName(String productName) {
		this.name = productName;
		return this;
	}

	public double getPrice() {
		return price;
	}

	public Product setPrice(double price) {
		this.price = price;
		return this;
	}

	@Override
	public String toString() {
		return "Product{" +
				"id='" + id + '\'' +
				", productName='" + name + '\'' +
				", price=" + price +
				'}';
	}
}

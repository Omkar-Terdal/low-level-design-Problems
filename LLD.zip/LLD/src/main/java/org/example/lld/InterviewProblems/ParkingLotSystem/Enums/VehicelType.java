package org.example.lld.InterviewProblems.ParkingLotSystem.Enums;

public enum VehicelType {
	CAR,
	BIKE,
	TRUCK
}

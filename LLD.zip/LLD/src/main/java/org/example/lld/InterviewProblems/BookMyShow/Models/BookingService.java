package org.example.lld.InterviewProblems.BookMyShow.Models;

import org.example.lld.InterviewProblems.BookMyShow.Enums.BookingStatus;
import org.example.lld.InterviewProblems.BookMyShow.Enums.PaymentMethod;
import org.example.lld.InterviewProblems.BookMyShow.Enums.PaymentStatus;
import org.example.lld.InterviewProblems.BookMyShow.Enums.SeatStatus;

import java.awt.print.Book;
import java.util.List;

public class BookingService {
	private Long bookingId = 1L;
	private int paymentId = 1;
	public Booking bookTicket(User user, Show show, List<Seat> selectedSeat, PaymentMethod paymentMethod) {

		for(Seat seat : selectedSeat) {
			if(seat.getSeatStatus()!= SeatStatus.AVAILABLE) {
				return null;
			}
		}

		for(Seat seat : selectedSeat) {
			seat.setSeatStatus(SeatStatus.LOCKED);
		}

		double amount=selectedSeat.size()*500;

		Payment payment=new Payment(paymentId++,amount,paymentMethod, PaymentStatus.PENDING);

		boolean paymentStatus=processPayment(payment);

		if(!paymentStatus) {
			for(Seat seat : selectedSeat) {
				seat.setSeatStatus(SeatStatus.AVAILABLE);
				System.out.println("Payment Failed");
			}
			return null;
		}

		for(Seat seat : selectedSeat) {
			seat.setSeatStatus(SeatStatus.BOOKED);
		}

		return new Booking(bookingId++,user,show,selectedSeat,payment,BookingStatus.CONFIRMED);

	}

	private boolean processPayment(Payment payment) {
		payment.setPaymentStatus(PaymentStatus.SUCCESS);
		return true;
	}
}

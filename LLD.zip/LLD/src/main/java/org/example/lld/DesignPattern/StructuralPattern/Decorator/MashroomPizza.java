package org.example.lld.DesignPattern.StructuralPattern.Decorator;

public class MashroomPizza extends ToppingsDecorator{

	 BasePizza pizza;

	 public MashroomPizza(BasePizza pizza) {
		 this.pizza = pizza;
	 }
	 @Override
	 public int cost() {
		 return this.pizza.cost() + 35;
	 }
}

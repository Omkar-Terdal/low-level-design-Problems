package org.example.lld.InterviewProblems.CarRental.Models;

import java.util.ArrayList;
import java.util.List;

public class Store {
	private final String storeId;
	private final String name;
	private final String city;
	private final List<Car> cars = new ArrayList<>();

	public Store(String storeId, String name, String city) {
		this.storeId = storeId;
		this.name = name;
		this.city = city;
	}

	public void addCar(Car car) {
		cars.add(car);
	}

	public String getStoreId() {
		return storeId;
	}

	public String getName() {
		return name;
	}

	public String getCity() {
		return city;
	}

	public List<Car> getCars() {
		return cars;
	}
}

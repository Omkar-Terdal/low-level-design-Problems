package org.example.lld.DesignPattern.BehaviouralPattern.StratergryPattern.WithStratergyPattern;

import org.example.lld.DesignPattern.BehaviouralPattern.StratergryPattern.WithStratergyPattern.Stratergy.NormalDriveStratergy;

public class GoodsVehicle extends Vehicle{

	public GoodsVehicle() {
		super(new NormalDriveStratergy());
	}

	public GoodsVehicle(NormalDriveStratergy normalDriveStratergy) {
		super(new NormalDriveStratergy());
	}
}

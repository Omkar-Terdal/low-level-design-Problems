package org.example.lld.InterviewProblems.Splitwise.Service;

import org.example.lld.InterviewProblems.Splitwise.Models.Expense;
import org.example.lld.InterviewProblems.Splitwise.Models.Split;
import org.example.lld.InterviewProblems.Splitwise.Models.User;
import org.example.lld.InterviewProblems.Splitwise.SplitStratergy.SplitStrategry;

import java.util.List;

public class ExpenseService {


	public Expense addExpense(Long id, String description, Double amount, User paidBy, List<Split> splitList,SplitStrategry splitStrategry) {

		splitStrategry.calculatePrice(amount,splitList);

		Expense expense=new Expense(id,description,amount,paidBy,splitList);

		updateBalance(expense);

		return expense;
	}

	private void updateBalance(Expense expense) {
		//omkar
		User paidBy=expense.getPaidBy();

		for(Split split : expense.getSplitList()){
			//Rahul
			User borrower=split.getUser();
			if(borrower.equals(paidBy)){
				continue;
			}

			double share=split.getAmount();

			//borrower has to be paid to paidBy person
			borrower.getBalanceSheet().getAmountToPay()
					.compute(paidBy,
						(k,v)-> v==null? share: v + share);

			// Payer should receive money
			paidBy.getBalanceSheet().getAmountToGetBack()
					.compute(borrower,
							(k,v)-> v==null? share:v + share);

		}
	}
}

package org.example.lld.InterviewProblems.ParkingLotSystem.Models;

import org.example.lld.InterviewProblems.ParkingLotSystem.ParkingStratergy.PriceStratergy;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class ParkingLot {
	private List<ParkingFloors> parkingFloors;
	private Map<String,Ticket>  activeTickets;
	private PriceStratergy priceStratergy;

	public ParkingLot(List<ParkingFloors> parkingFloors, PriceStratergy priceStratergy) {
		this.parkingFloors = parkingFloors;
		this.priceStratergy = priceStratergy;
		activeTickets = new HashMap<>();
	}



	public ParkingResponse parkVehicle(Vehicle vehicle) {
		for(ParkingFloors parkingFloors : parkingFloors) {
			ParkingSpots parkingSpot=parkingFloors.parkVehicle(vehicle);

			if(parkingSpot!=null) {
				String ticketId=UUID.randomUUID().toString();
				Ticket ticket=new Ticket(ticketId,vehicle,parkingSpot, LocalDateTime.now().minusHours(2));
				activeTickets.put(ticketId, ticket);
				return new ParkingResponse(true,"Vehicel Parked",ticket);
			}
		}
		return new ParkingResponse(false,"Parking is Full",null);
	}

	public double exitVehicle(String ticketId) {
		Ticket ticket=activeTickets.get(ticketId);
		if(ticket==null) {
			throw new RuntimeException("Invalid Ticket");
		}
		ticket.setExitTime();
		double amount=priceStratergy.calculatePrice(ticket);

		ParkingSpots spot=ticket.getParkingSpot();
		boolean removedVehicle=false;

		for (ParkingFloors parkingFloors : parkingFloors) {
			if(parkingFloors.removeVehicle(spot)){
				removedVehicle=true;
				break;
			}
		}
		if (!removedVehicle) {
			throw new RuntimeException("Parking Spot not found in any floor.");
		}

		activeTickets.remove(ticketId);

		return amount;
	}

	public void displayAvailability() {

		for (ParkingFloors floor :parkingFloors) {

			System.out.println(
					"Floor " + floor.getFloorNumber() +
							" -> Cars: " + floor.getAvailableCarSpots() +
							", Bikes: " + floor.getAvailableBikeSpots() +
							", Trucks: " + floor.getAvailableTruckSpots()
			);
		}
	}
}

package org.example.lld.InterviewProblems.CarRental.Strategy;

import org.example.lld.InterviewProblems.CarRental.Models.Car;

public interface PricingStrategy {
	double calculatePrice(Car car, long days);
}

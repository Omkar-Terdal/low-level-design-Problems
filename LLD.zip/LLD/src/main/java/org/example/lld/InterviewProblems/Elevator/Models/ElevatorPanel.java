package org.example.lld.InterviewProblems.Elevator.Models;

import org.example.lld.InterviewProblems.Elevator.Interface.ElevatorPanelListener;

public class ElevatorPanel {
	private  Elevator elevator;
	private ElevatorPanelListener listener;

	public ElevatorPanel(Elevator elevator, ElevatorPanelListener listener) {
		this.elevator=elevator;
		this.listener=listener;
	}
	public Elevator getElevator() {
		return elevator;
	}
	public void   pressButton(int destinationFloor){
		listener.onFloorButtonPressed(elevator, destinationFloor);
	}
}

package org.example.lld.InterviewProblems.CouponMangement.r2.Models;

public class ValidationResult {

	private boolean success;
	private String message;

	public ValidationResult(boolean success, String message) {
		this.success = success;
		this.message = message;
	}

	public static ValidationResult success() {
		return new ValidationResult(true, "Validation Successful");
	}

	public static ValidationResult failure(String message) {
		return new ValidationResult(false, message);
	}

	public boolean isSuccess() {
		return success;
	}

	public String getMessage() {
		return message;
	}
}

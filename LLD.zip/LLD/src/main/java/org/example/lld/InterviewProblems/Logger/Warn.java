package org.example.lld.InterviewProblems.Logger;

public class Warn extends LogProcesser{

	Warn(LogProcesser nextLogProcessor){
		super(nextLogProcessor);
	}

	public void log(int level,String message){
		if(level==WARN){
			System.out.println(level+":"+message);
		}else{
			super.log(level,message);
		}
	}
}

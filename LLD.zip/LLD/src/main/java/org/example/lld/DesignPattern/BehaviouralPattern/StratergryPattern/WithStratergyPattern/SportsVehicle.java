package org.example.lld.DesignPattern.BehaviouralPattern.StratergryPattern.WithStratergyPattern;

import org.example.lld.DesignPattern.BehaviouralPattern.StratergryPattern.WithStratergyPattern.Stratergy.SportsDriveStratergy;

public class SportsVehicle extends Vehicle {

	public SportsVehicle() {
		super(new SportsDriveStratergy());
	}

}

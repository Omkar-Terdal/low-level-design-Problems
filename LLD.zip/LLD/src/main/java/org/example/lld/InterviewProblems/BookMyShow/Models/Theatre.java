package org.example.lld.InterviewProblems.BookMyShow.Models;

import java.util.List;

public class Theatre {
	private Long theatreId;
	private String theatreName;
	private String locationName;
	private List<Screen> screenList;

	public Theatre(Long theatreId, String theatreName, String locationName, List<Screen> screenList) {
		this.theatreId = theatreId;
		this.theatreName = theatreName;
		this.locationName = locationName;
		this.screenList = screenList;
	}

	public Long getTheatreId() {
		return theatreId;
	}
	public String getTheatreName() {
		return theatreName;
	}

	public String getLocationName() {
		return locationName;
	}
	public List<Screen> getScreenList() {
		return screenList;
	}
	public void addScreen(Screen screen) {
		this.screenList.add(screen);
	}
}

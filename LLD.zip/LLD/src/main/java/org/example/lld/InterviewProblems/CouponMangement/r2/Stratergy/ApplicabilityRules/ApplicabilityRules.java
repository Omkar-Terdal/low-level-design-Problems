package org.example.lld.InterviewProblems.CouponMangement.r2.Stratergy.ApplicabilityRules;

import org.example.lld.InterviewProblems.CouponMangement.r2.Models.Cart;
import org.example.lld.InterviewProblems.CouponMangement.r2.Models.User;

public interface ApplicabilityRules {
	boolean isApplicable(User user, Cart cart);

}

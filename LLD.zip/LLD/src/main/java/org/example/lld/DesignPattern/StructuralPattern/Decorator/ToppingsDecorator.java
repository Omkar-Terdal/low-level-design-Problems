package org.example.lld.DesignPattern.StructuralPattern.Decorator;

public abstract  class ToppingsDecorator extends BasePizza{

}

package org.example.lld.InterviewProblems.CouponMangement.r2.Repository;

import java.util.HashMap;
import java.util.Map;

public class InMemoryCouponUsageUsageRepository implements CouponUsageRepository {
	private Map<String,Integer> couponUsage = new HashMap<>();
	private Map<String,Map<String,Integer>> userUsage = new HashMap<>();

	@Override
	public int getCouponUsageCount(String couponId){
		return couponUsage.getOrDefault(couponId,0);
	}

	@Override
	public int getUserUsageCount(String couponId, String userId){
		return userUsage.getOrDefault(couponId,new HashMap<>())
				.getOrDefault(userId,0);
	}

	@Override
	public void incrementUserUsageCount(String couponId, String userId){
		couponUsage.compute(couponId, (k,v)-> v==null? 1: v+1);

		userUsage.computeIfAbsent(couponId,k->new HashMap<>())
				.compute(userId,(k,v)->v==null ? 1:v+1);
	}
}

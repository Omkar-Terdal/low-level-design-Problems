package org.example.lld.DesignPattern.CreationalPattern.AbstractFactoryPattern;

public class ModernChair implements Chair {

	@Override
	public void sitOn() {
		System.out.println("sitting on modernChair");
	}
}

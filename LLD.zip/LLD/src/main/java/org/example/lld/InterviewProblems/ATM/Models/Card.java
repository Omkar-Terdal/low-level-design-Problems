package org.example.lld.InterviewProblems.ATM.Models;

public class Card {
	private String cardNumber;
	private int pin;
	private Account account;

	public Card(String cardNumber, int pin, Account account) {
		this.cardNumber = cardNumber;
		this.pin = pin;
		this.account = account;
	}

	public String getCardNumber() {
		return cardNumber;
	}
	public boolean authenticateCard(int pin){
		return this.pin==pin;
	}

	public Account getAccount() {
		return account;
	}

}

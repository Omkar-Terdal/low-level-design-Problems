package org.example.lld.DesignPattern.BehaviouralPattern.StratergryPattern.WithStratergyPattern;


import org.example.lld.DesignPattern.BehaviouralPattern.StratergryPattern.WithStratergyPattern.Stratergy.NormalDriveStratergy;

public class VehicleMain {

	public static void main(String[] args) {
		Vehicle vehicle = new Vehicle(new NormalDriveStratergy());
		vehicle.drive();

		Vehicle vehicle2 = new GoodsVehicle(new NormalDriveStratergy());
		vehicle2.drive();

		// if you want to create goodVehicle object then need to create a new constructor with driver stratergy param
	}

//	Yes, you can do that. Java allows it.
//
//	class SportsVehicle extends Vehicle {
//		@Override
//		public void drive() {
//			enableTurbo();
//			System.out.println("Sports Drive");
//		}
//	}
//
//	class OffRoadVehicle extends Vehicle {
//		@Override
//		public void drive() {
//			System.out.println("Sports Drive");
//		}
//	}

//	But now ask yourself:
//class SportsVehicle extends Vehicle {
//    @Override
//    public void drive() {
//        enableTurbo();
//        System.out.println("Sports Drive");
//    }
//}
//
//class OffRoadVehicle extends Vehicle {
//    @Override
//    public void drive() {
//        System.out.println("Sports Drive");
//    }
//}
//	Should OffRoadVehicle have different behavior from SportsVehicle?
//
//	If the answer is yes, then your code is perfectly fine. They are two different algorithms.
//
//	If the answer is no, then you've created inconsistent behavior.

//	Let's say the requirement is:
//
//	Every vehicle that uses "Sports Drive" should enable Turbo.
//
//	Then your code becomes:
//
//	SportsVehicle
//      ↓
//	enableTurbo();
//	Sports Drive

//	OffRoadVehicle
//       ↓
//	Sports Drive
//	Now two vehicles that are supposed to use the same driving algorithm behave differently.
//	That's a bug.

}

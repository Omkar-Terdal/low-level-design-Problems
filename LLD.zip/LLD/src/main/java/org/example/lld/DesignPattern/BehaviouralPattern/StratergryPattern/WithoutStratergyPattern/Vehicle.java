package org.example.lld.DesignPattern.BehaviouralPattern.StratergryPattern.WithoutStratergyPattern;

import java.sql.SQLOutput;

public class Vehicle {

	public void drive(){
		System.out.println("vehicle drive");
	}
}

package org.example.lld.InterviewProblems.VendingMachine.model;

public class Transaction {
	private final Product product;
	private final double paidAmount;
	private final double change;
	private final String status;

	public Transaction(Product product, double paidAmount, double change, String status) {
		this.product = product;
		this.paidAmount = paidAmount;
		this.change = change;
		this.status = status;
	}

	public Product getProduct() {
		return product;
	}

	public double getPaidAmount() {
		return paidAmount;
	}

	public double getChange() {
		return change;
	}

	public String getStatus() {
		return status;
	}

	@Override
	public String toString() {
		return "Transaction{product=" + product.getName() +
				", paidAmount=" + paidAmount +
				", change=" + change +
				", status='" + status + '\'' +
				'}';
	}
}

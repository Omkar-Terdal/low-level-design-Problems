package org.example.lld.DesignPattern.StructuralPattern.Decorator;

public abstract class BasePizza {
		abstract int cost();

		// need to create it as abstract bcz we cant able to create direct object of this class
		// and in real world there will be not base pizza that's the reason
}

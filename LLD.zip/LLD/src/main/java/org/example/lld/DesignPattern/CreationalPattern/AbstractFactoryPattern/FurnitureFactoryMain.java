package org.example.lld.DesignPattern.CreationalPattern.AbstractFactoryPattern;

public class FurnitureFactoryMain {
	public static void main(String[] args) {
		FurnitureFactory modernFactory=new ModernFurnitureFactory();
		Chair modernChair=modernFactory.createChair();
		modernChair.sitOn();
		Bed bed=modernFactory.createBed();
		bed.lieOn();

		FurnitureFactory traditionalFactory=new TraditionalFurnitureFactory();
		Chair TraditionalChair=traditionalFactory.createChair();
		TraditionalChair.sitOn();
		Bed TraditionalChairBed=traditionalFactory.createBed();
		TraditionalChairBed.lieOn();
	}
}

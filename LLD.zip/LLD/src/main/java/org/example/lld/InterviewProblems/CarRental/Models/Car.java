package org.example.lld.InterviewProblems.CarRental.Models;

import org.example.lld.InterviewProblems.CarRental.Enums.CarStatus;
import org.example.lld.InterviewProblems.CarRental.Enums.CarType;

public class Car {
	private final String carId;
	private final String regNumber;
	private final CarType type;
	private final double dailyRate;
	private final String storeId;
	private CarStatus status;

	public Car(String carId, String regNumber, CarType type, double dailyRate, String storeId) {
		this.carId = carId;
		this.regNumber = regNumber;
		this.type = type;
		this.dailyRate = dailyRate;
		this.storeId = storeId;
		this.status = CarStatus.AVAILABLE;
	}

	public String getCarId() {
		return carId;
	}

	public String getRegNumber() {
		return regNumber;
	}

	public CarType getType() {
		return type;
	}

	public double getDailyRate() {
		return dailyRate;
	}

	public String getStoreId() {
		return storeId;
	}

	public CarStatus getStatus() {
		return status;
	}

	public void setStatus(CarStatus status) {
		this.status = status;
	}
}

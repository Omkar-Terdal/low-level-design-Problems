package org.example.lld.InterviewProblems.Splitwise.SplitStratergy;

import org.example.lld.InterviewProblems.Splitwise.Models.Expense;
import org.example.lld.InterviewProblems.Splitwise.Models.PercentageSplit;
import org.example.lld.InterviewProblems.Splitwise.Models.Split;

import java.util.List;

public class PercentageSplitStratergy implements SplitStrategry {

	@Override
	public void calculatePrice(double amount, List<Split> splitList) {
		double totalPercentage=0;

		for(Split split : splitList){
			PercentageSplit percentageSplit = (PercentageSplit)split;
			totalPercentage+=percentageSplit.getPercentage();
		}

		if(totalPercentage!=100){
			throw new IllegalArgumentException("Percentage is not equal to 100");
		}

		for(Split split : splitList){
			PercentageSplit percentageSplit=(PercentageSplit) split;
			double splitAmount=(amount*percentageSplit.getPercentage())/100;
			percentageSplit.setAmount(splitAmount);
		}

	}
}

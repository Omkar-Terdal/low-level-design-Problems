package org.example.lld.DesignPattern.CreationalPattern.AbstractFactoryPattern;

public class TraditionalBed implements Bed {
	@Override
	public void lieOn() {
		System.out.println("laying on Traditional bed");
	}
}

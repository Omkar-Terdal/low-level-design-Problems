package org.example.lld.InterviewProblems.CouponMangement.r2.Models;

import org.example.lld.InterviewProblems.CouponMangement.r2.Enums.UserSegment;

public class User {
	private String userID;
	private String userName;
	private String userEmail;
	private Cart cart;
	private UserSegment userSegment;

	public User(Cart cart,
	            String userID,
	            String userName,
	            String userEmail,
	            UserSegment  userSegment) {
		this.cart = cart;
		this.userEmail = userEmail;
		this.userID = userID;
		this.userName = userName;
		this.userSegment = userSegment;
	}

	public Cart getCart() {
		return cart;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public String getUserID() {
		return userID;
	}

	public String getUserName() {
		return userName;
	}

	public UserSegment getUserSegment() {
		return userSegment;
	}
}

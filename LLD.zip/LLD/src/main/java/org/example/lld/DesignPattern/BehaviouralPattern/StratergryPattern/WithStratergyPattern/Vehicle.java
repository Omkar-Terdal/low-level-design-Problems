package org.example.lld.DesignPattern.BehaviouralPattern.StratergryPattern.WithStratergyPattern;

import org.example.lld.DesignPattern.BehaviouralPattern.StratergryPattern.WithStratergyPattern.Stratergy.DriverStratergy;

public class Vehicle {

	DriverStratergy driverStratergy;

	public Vehicle(DriverStratergy driverStratergy){
		this.driverStratergy = driverStratergy;
	}

	public void drive(){
		driverStratergy.drive();
	}
}

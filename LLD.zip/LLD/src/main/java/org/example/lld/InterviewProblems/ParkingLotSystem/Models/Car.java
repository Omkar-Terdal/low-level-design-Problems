package org.example.lld.InterviewProblems.ParkingLotSystem.Models;

import org.example.lld.InterviewProblems.ParkingLotSystem.Enums.VehicelType;

public class Car extends Vehicle {
	public Car(String plateNumber) {
		super(plateNumber,VehicelType.CAR);
	}
}

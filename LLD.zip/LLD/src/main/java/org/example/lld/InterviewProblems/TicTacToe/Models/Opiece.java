package org.example.lld.InterviewProblems.TicTacToe.Models;

import org.example.lld.InterviewProblems.TicTacToe.Enums.PieceType;

public class Opiece extends PlayingPiece{

	public Opiece() {
		super(PieceType.O);
	}
}

package org.example.lld.InterviewProblems.CouponMangement.r2.Stratergy.Constraints;

import org.example.lld.InterviewProblems.CouponMangement.r2.Models.Cart;
import org.example.lld.InterviewProblems.CouponMangement.r2.Models.Coupon;
import org.example.lld.InterviewProblems.CouponMangement.r2.Models.User;
import org.example.lld.InterviewProblems.CouponMangement.r2.Models.ValidationResult;

public interface Constraints {
	ValidationResult validate(User user, Cart cart, Coupon coupon);

}

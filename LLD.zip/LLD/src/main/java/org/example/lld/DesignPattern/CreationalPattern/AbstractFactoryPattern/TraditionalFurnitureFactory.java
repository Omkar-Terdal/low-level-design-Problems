package org.example.lld.DesignPattern.CreationalPattern.AbstractFactoryPattern;

public class TraditionalFurnitureFactory implements FurnitureFactory {
	@Override
	public Chair createChair() {
		return new TraditionalChair();
	}

	@Override
	public Bed createBed() {
		return new TraditionalBed();
	}
}

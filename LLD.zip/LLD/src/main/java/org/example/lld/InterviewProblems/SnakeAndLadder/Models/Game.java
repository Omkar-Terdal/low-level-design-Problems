package org.example.lld.InterviewProblems.SnakeAndLadder.Models;


import java.util.LinkedList;
import java.util.Queue;

public class Game {
	private Board board;
	private Dice dice;
	private Queue<Player> q;

	public Game(Board board, Dice dice, Queue<Player> players) {
		this.board = board;
		this.dice = dice;
		this.q = players;
	}

	public void startGame() {
		boolean gameOver = false;
		while (!gameOver) {
			Player currentPlayer = q.poll();
			int diceNumber = dice.roll();
			System.out.println("--------------------------------");
			System.out.println("Current Player : " + currentPlayer.getName());
			System.out.println("Current Position : " + currentPlayer.getCurrentPosition());
			System.out.println("Dice Rolled : " + diceNumber);
			move(currentPlayer, diceNumber);
			System.out.println("New Position : " + currentPlayer.getCurrentPosition());
			if (currentPlayer.getCurrentPosition() == board.getSize()) {
				System.out.println(currentPlayer.getName() + "Winner");
				gameOver = true;
			}else{
				q.offer(currentPlayer);
			}
		}
	}

	private void move(Player currentPlayer, int diceNumber) {
		int newPosition = currentPlayer.getCurrentPosition() + diceNumber;
		System.out.println("Position after dice = " + newPosition);

		if (newPosition > board.getSize()) {
			return;
		}
		int nextPosition = board.getPostition(newPosition);
		currentPlayer.setCurrentPosition(nextPosition);
	}

}

package org.example.lld.InterviewProblems.Elevator.Models;

import org.example.lld.InterviewProblems.Elevator.Enums.DoorState;

public class Door {
	private DoorState doorState;

	public  Door() {
		this.doorState=DoorState.CLOSE;
	}
	public DoorState getDoorState() {
		return doorState;
	}
	public void openDoor() {
		doorState=DoorState.OPEN;
	}
	public void closeDoor() {
		doorState=DoorState.CLOSE;
	}

	@Override
	public String toString() {
		return "Door{" +
				"doorState=" + doorState +
				'}';
	}
}

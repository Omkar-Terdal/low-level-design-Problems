package org.example.lld.DesignPattern.CreationalPattern.FactoryPattern;

public interface Shape {
	void draw();
}

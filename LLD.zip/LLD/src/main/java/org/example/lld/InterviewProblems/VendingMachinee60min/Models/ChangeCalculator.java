package org.example.lld.InterviewProblems.VendingMachinee60min.Models;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ChangeCalculator {

	private final List<Integer> denominations;

	public ChangeCalculator(List<Integer> denominations) {
		this.denominations = new ArrayList<>(denominations);
		this.denominations.sort(Collections.reverseOrder());
	}

	public List<Integer> calculateChange(int amount) {

		List<Integer> result = new ArrayList<>();

		for (int denomination : denominations) {

			int count = amount / denomination;

			for (int i = 0; i < count; i++) {
				result.add(denomination);
			}

			amount %= denomination;
		}

		if (amount != 0) {
			throw new IllegalStateException(
					"Cannot provide exact change"
			);
		}

		return result;
	}
}

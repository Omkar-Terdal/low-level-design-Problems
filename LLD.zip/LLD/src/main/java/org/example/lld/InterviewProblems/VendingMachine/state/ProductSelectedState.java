package org.example.lld.InterviewProblems.VendingMachine.state;

import org.example.lld.InterviewProblems.VendingMachine.machine.VendingMachine;
import org.example.lld.InterviewProblems.VendingMachine.model.Product;

public class ProductSelectedState implements VendingMachineState {

	@Override
	public void selectProduct(VendingMachine machine, Product product) {
		System.out.println("Product already selected: " + machine.getSelectedProduct().getName());
	}

	@Override
	public void insertMoney(VendingMachine machine, double amount) {
		machine.setInsertedAmount(machine.getInsertedAmount() + amount);
		System.out.println("Inserted: " + amount + ", Total: " + machine.getInsertedAmount());

		if (machine.getInsertedAmount() >= machine.getSelectedProduct().getPrice()) {
			machine.setState(new MoneyInsertedState());
		} else {
			double remaining = machine.getSelectedProduct().getPrice() - machine.getInsertedAmount();
			System.out.println("Insert " + remaining + " more");
		}
	}

	@Override
	public void dispenseProduct(VendingMachine machine) {
		System.out.println("Please insert money first");
	}

	@Override
	public void cancelTransaction(VendingMachine machine) {
		System.out.println("Transaction cancelled");
		machine.setSelectedProduct(null);
		machine.setInsertedAmount(0);
		machine.setState(new IdleState());
	}
}

package org.example.lld.InterviewProblems.ParkingLotSystem.Models;

import org.example.lld.InterviewProblems.ParkingLotSystem.Enums.VehicelType;

public class Truck extends Vehicle {
	public Truck(String VehiclePlateNumber, VehicelType vehicelType) {
		super(VehiclePlateNumber, vehicelType);
	}
}

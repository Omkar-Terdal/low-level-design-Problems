package org.example.lld.InterviewProblems.Elevator.Models;

import org.example.lld.InterviewProblems.Elevator.Enums.Direction;
import org.example.lld.InterviewProblems.Elevator.Interface.ButtonListner;

public class HallButton {
	private Direction direction;
	private int floorNumber;
	private ButtonListner listner;
	public HallButton(Direction direction, int floorNumber) {
		this.direction = direction;
		this.floorNumber = floorNumber;
	}
	public Direction getDirection() {
		return direction;
	}
	public int getFloorNumber() {
		return floorNumber;
	}

	public void press(){
		listner.onPressHallButton(floorNumber,direction);
	}

	@Override
	public String toString() {
		return "HallButton{" +
				"floorNumber=" + floorNumber +
				", direction=" + direction +
				'}';
	}
}

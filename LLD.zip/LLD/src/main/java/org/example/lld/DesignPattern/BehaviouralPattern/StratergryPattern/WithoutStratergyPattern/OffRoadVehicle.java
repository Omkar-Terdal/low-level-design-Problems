package org.example.lld.DesignPattern.BehaviouralPattern.StratergryPattern.WithoutStratergyPattern;

public class OffRoadVehicle extends Vehicle{

	@Override
	public void drive() {
		System.out.println("Running off Road speed capacbility");
	}
}

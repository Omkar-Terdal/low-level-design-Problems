package org.example.lld.InterviewProblems.CarRental.Enums;

public enum CarType {
	HATCHBACK,
	SEDAN,
	SUV,
	LUXURY
}

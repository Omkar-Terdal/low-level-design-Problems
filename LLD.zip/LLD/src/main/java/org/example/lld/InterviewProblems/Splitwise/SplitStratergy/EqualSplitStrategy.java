package org.example.lld.InterviewProblems.Splitwise.SplitStratergy;

import org.example.lld.InterviewProblems.Splitwise.Models.Expense;
import org.example.lld.InterviewProblems.Splitwise.Models.Split;
import org.example.lld.InterviewProblems.Splitwise.Models.User;

import java.util.ArrayList;
import java.util.List;

public class EqualSplitStrategy implements SplitStrategry {

	@Override
	public void calculatePrice(double amount,List<Split> splitList) {
		double splitAmount = amount/splitList.size();
		for(Split split : splitList) {
			split.setAmount(splitAmount);
		}
	}
}

package org.example.lld.InterviewProblems.TicTacToe.Enums;

public enum PieceType {
	X,
	O
}

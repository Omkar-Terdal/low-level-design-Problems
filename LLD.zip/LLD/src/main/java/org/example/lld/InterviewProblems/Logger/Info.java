package org.example.lld.InterviewProblems.Logger;

public class Info extends LogProcesser{

	Info(LogProcesser nextLogProcessor){
		super(nextLogProcessor);
	}

	public void log(int level,String message){
		if(level==INFO){
			System.out.println(level+":"+message);
		}else{
			super.log(level,message);
		}
	}
}

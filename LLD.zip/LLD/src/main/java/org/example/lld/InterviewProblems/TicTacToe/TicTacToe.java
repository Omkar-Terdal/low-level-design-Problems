package org.example.lld.InterviewProblems.TicTacToe;

import org.example.lld.InterviewProblems.TicTacToe.Models.Game;

public class TicTacToe {
	public static void main(String[] args) {
		Game game = new Game(10);
		game.startGame();
	}
}

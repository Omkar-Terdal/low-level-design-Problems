package org.example.lld.InterviewProblems.BookMyShow.Models;

import org.example.lld.InterviewProblems.BookMyShow.Enums.*;

import java.awt.print.Book;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BookMyShowMain {
	public static void main(String[] args) {
		Movie movie = new Movie(
				1L,
				"Interstellar",
				"English",
				"Sci-Fi",
				169
		);
		Seat seat1 = new Seat(1L, "A", 1, SeatType.REGULAR, SeatStatus.AVAILABLE);
		Seat seat2 = new Seat(2L, "A", 2, SeatType.REGULAR, SeatStatus.AVAILABLE);

		Screen screen=new Screen(1L);
		screen.addSeats(seat1);
		screen.addSeats(seat2);

		Show show =new Show(1L,movie,screen, LocalDateTime.now(),LocalDateTime.now().plusHours(3),screen.getSeatsList());

		screen.addShows(show);

		Theatre theatre=new Theatre(1L,"Mantri Mall","Bangalore", List.of(screen));

		City city=new City("Bangalore");
		city.addTheatre(theatre);

		User user=new User(1,"omkar","omkarteral7@gmail.com");

		List<Seat> selectedSeats = new ArrayList<>();
		selectedSeats.add(seat1);
		selectedSeats.add(seat2);

		BookMyShow bookMyShow=new BookMyShow();
		bookMyShow.addCity(city);
		bookMyShow.addMovie(movie);
		bookMyShow.addUser(user);

		BookingService bookingService = new BookingService();

		Booking booking = bookingService.bookTicket(
				user,
				show,
				screen.getSeatsList(),
				PaymentMethod.UPI
		);


		if (booking != null) {

			bookMyShow.addBooking(booking);

			System.out.println("===== Booking Successful =====");
			System.out.println("\nMovie : " + booking.getShow().getMovie().getTitle());
			System.out.println("User : " + booking.getUser().getName());
			System.out.println("Seats : " + booking.getBookedSeats().size());
			System.out.println("Amount : " + booking.getPayment().getAmount());
			System.out.println("Payment Status : " + booking.getPayment().getPaymentStatus());
			System.out.println("Booking Status : " + booking.getBookingStatus());

		} else {

			System.out.println("Booking Failed");
		}

		// Verify seat status
		System.out.println("\nSeat Status After Booking:");
		System.out.println("A1 : " + seat1.getSeatStatus());
		System.out.println("A2 : " + seat2.getSeatStatus());

	}
}

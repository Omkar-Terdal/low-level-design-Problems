package org.example.lld.DesignPattern.CreationalPattern.FactoryPattern;

public class Triangle implements Shape{
	@Override
	public void draw() {
		System.out.println("Drawing Triangle");
	}
}

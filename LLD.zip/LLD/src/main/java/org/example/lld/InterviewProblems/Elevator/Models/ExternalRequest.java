package org.example.lld.InterviewProblems.Elevator.Models;

import org.example.lld.InterviewProblems.Elevator.Enums.Direction;

public class ExternalRequest extends Request {
	private int sourceFloor;
	private Direction direction;

	public ExternalRequest(int sourceFloor, Direction direction) {
		this.sourceFloor = sourceFloor;
		this.direction = direction;
	}

	public int getSourceFloor() {
		return sourceFloor;
	}
	public Direction getDirection() {
		return direction;
	}
}

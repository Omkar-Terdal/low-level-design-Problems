package org.example.lld.InterviewProblems.CouponMangement.r2.Stratergy.CouponType;

import org.example.lld.InterviewProblems.CouponMangement.r2.Models.Cart;
import org.example.lld.InterviewProblems.CouponMangement.r2.Models.CartItem;
import org.example.lld.InterviewProblems.CouponMangement.r2.Models.Product;

public class BXGY implements CouponType {
	private Product product;
	private int buyQuantity;
	private int freeQuantity;


	public BXGY(int buyQuantity, int freeQuantity, Product product) {
		this.buyQuantity = buyQuantity;
		this.freeQuantity = freeQuantity;
		this.product = product;
	}

	@Override
	public double calculateDiscount(Cart cart){
		for(CartItem cartItem:cart.getCartItemList()){
			if(cartItem.getProduct().equals(product)){
				int quantity = cartItem.getQuantity();
				int groupSize=buyQuantity+freeQuantity;
				int eligibleGroupSize=quantity/groupSize;

				return eligibleGroupSize* freeQuantity*product.getPrice();
			}
		}
		return 0;
	}

}

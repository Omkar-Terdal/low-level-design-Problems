package org.example.lld.InterviewProblems.VendingMachinee60min.Models;

import java.util.HashMap;
import java.util.Map;

import java.util.HashMap;
import java.util.Map;

public class Inventory {

	private final Map<String, InventoryItem> items;

	public Inventory() {
		items = new HashMap<>();
	}

	public void addProduct(Product product, int quantity) {
		if (product == null) {
			throw new IllegalArgumentException("Product cannot be null");
		}

		if (quantity < 0) {
			throw new IllegalArgumentException("Quantity cannot be negative");
		}

		InventoryItem existingItem = items.get(product.getId());

		if (existingItem == null) {
			items.put(
					product.getId(),
					new InventoryItem(product, quantity)
			);
		} else {
			existingItem.increase(quantity);
		}
	}

	public Product getProduct(String productId) {
		InventoryItem item = items.get(productId);

		if (item == null) {
			return null;
		}

		return item.getProduct();
	}

	public boolean isAvailable(String productId) {
		InventoryItem item = items.get(productId);

		return item != null && item.getQuantity() > 0;
	}

	public int getQuantity(String productId) {
		InventoryItem item = items.get(productId);

		if (item == null) {
			return 0;
		}

		return item.getQuantity();
	}

	public void reduceStock(String productId) {
		InventoryItem item = items.get(productId);

		if (item == null) {
			throw new IllegalArgumentException("Product not found");
		}

		item.decrease();
	}

	public void restock(String productId, int quantity) {
		InventoryItem item = items.get(productId);

		if (item == null) {
			throw new IllegalArgumentException("Product not found");
		}

		item.increase(quantity);
	}

	public void displayProducts() {
		if (items.isEmpty()) {
			System.out.println("No products available");
			return;
		}

		for (InventoryItem item : items.values()) {
			Product product = item.getProduct();

			System.out.println(
					product.getId()
							+ " | "
							+ product.getProductName()
							+ " | ₹"
							+ product.getPrice()
							+ " | Stock: "
							+ item.getQuantity()
			);
		}
	}
}
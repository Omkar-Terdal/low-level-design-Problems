package org.example.lld.InterviewProblems.ParkingLotSystem.Models;

import java.time.LocalDateTime;

public class Ticket {
	private String ticketId;
	private Vehicle vehicle;
	private LocalDateTime entryTime;
	private ParkingSpots parkingSpot;
	private LocalDateTime exitTime;

	public Ticket(String ticketId, Vehicle vehicle,ParkingSpots parkingSpot, LocalDateTime entryTime) {
		this.ticketId = ticketId;
		this.vehicle = vehicle;
		this.entryTime = entryTime;
		this.parkingSpot = parkingSpot;
		this.exitTime = null;
	}

	public String getTicketId() {
		return ticketId;
	}

	public void setExitTime(){
		this.exitTime = LocalDateTime.now();
	}

	public ParkingSpots getParkingSpot(){
		return parkingSpot;
	}

	public LocalDateTime getEntryTime() {
		return entryTime;
	}

	public LocalDateTime getExitTime() {
		return exitTime;
	}

	@Override
	public String toString() {
		return "Ticket{" +
				"ticketId='" + ticketId + '\'' +
				", vehicle=" + vehicle.getVehiclePlateNumber() +
				", spot=" + parkingSpot.getSpotNumber() +
				", entryTime=" + entryTime +
				'}';
	}



}

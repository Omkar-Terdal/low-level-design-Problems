package org.example.lld.DesignPattern.BehaviouralPattern.StratergryPattern.WithStratergyPattern.Stratergy;

public class OffRoadStratergy implements   DriverStratergy {

	@Override
	public void drive() {
		System.out.println("Off DriveStratergy drive");
	}
}

package org.example.lld;

import org.example.lld.DesignPattern.BehaviouralPattern.StratergryPattern.WithoutStratergyPattern.OffRoadVehicle;
import org.example.lld.DesignPattern.BehaviouralPattern.StratergryPattern.WithoutStratergyPattern.Vehicle;


public class LldApplication {

	public static void main(String[] args) {
		Vehicle vehicle = new OffRoadVehicle();
		vehicle.drive();

	}

}

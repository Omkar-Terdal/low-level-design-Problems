package org.example.lld.DesignPattern.CreationalPattern.FactoryPattern;

public class ShapeMain {
	public static void main(String[] args) {
		ShapeFactory shapeFactory = new ShapeFactory();
		Shape shape=shapeFactory.getShape("Circle");
		Shape shape1 =shapeFactory.getShape("Triangle");
		shape.draw();
		shape1.draw();
	}
}

package org.example.lld.DesignPattern.CreationalPattern.FactoryPattern;

public class Circle implements Shape{
	@Override
	public void draw() {
		System.out.println("Drawing Circle");
	}
}

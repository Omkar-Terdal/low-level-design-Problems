package org.example.lld.InterviewProblems.VendingMachine;

import org.example.lld.InterviewProblems.VendingMachine.inventory.Inventory;
import org.example.lld.InterviewProblems.VendingMachine.machine.VendingMachine;
import org.example.lld.InterviewProblems.VendingMachine.model.Product;
import org.example.lld.InterviewProblems.VendingMachine.payment.CashPayment;

public class Main {

	public static void main(String[] args) {
		Product coke = new Product("P1", "Coke", 25.0);
		Product chips = new Product("P2", "Chips", 40.0);

		Inventory inventory = new Inventory();
		inventory.addProduct(coke, 2);
		inventory.addProduct(chips, 1);

		VendingMachine vendingMachine = new VendingMachine(inventory, new CashPayment());

		System.out.println("----- Buying Coke -----");
		vendingMachine.selectProduct(coke);
		vendingMachine.insertMoney(10);
		vendingMachine.insertMoney(20);
		vendingMachine.dispenseProduct();

		System.out.println("\n----- Cancelling mid-transaction -----");
		vendingMachine.selectProduct(chips);
		vendingMachine.insertMoney(20);
		vendingMachine.cancelTransaction();

		System.out.println("\n----- Restocking Chips -----");
		inventory.restock(chips, 3);
		System.out.println("Chips quantity: " + inventory.getQuantity(chips));
	}
}

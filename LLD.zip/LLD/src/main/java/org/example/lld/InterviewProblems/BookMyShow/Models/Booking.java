package org.example.lld.InterviewProblems.BookMyShow.Models;


import org.example.lld.InterviewProblems.BookMyShow.Enums.BookingStatus;

import java.util.List;

public class Booking {
	private Long bookingId;
	private User user;
	private Show show;
	private List<Seat> bookedSeats;
	private Payment payment;
	private BookingStatus bookingStatus;

	public Booking(Long bookingId, User user, Show show, List<Seat> bookedSeats, Payment payment, BookingStatus bookingStatus) {
		this.bookingId = bookingId;
		this.user = user;
		this.show = show;
		this.bookedSeats = bookedSeats;
		this.payment = payment;
		this.bookingStatus = bookingStatus;
	}

	public Long getBookingId() {
		return bookingId;
	}

	public User getUser() {
		return user;
	}
	public Show getShow() {
		return show;
	}
	public List<Seat> getBookedSeats() {
		return bookedSeats;
	}
	public Payment getPayment() {
		return payment;
	}
	public BookingStatus getBookingStatus() {
		return bookingStatus;
	}
	public void setBookingStatus(BookingStatus bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

}

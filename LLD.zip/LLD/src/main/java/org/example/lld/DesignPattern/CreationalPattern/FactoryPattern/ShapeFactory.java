package org.example.lld.DesignPattern.CreationalPattern.FactoryPattern;

public class ShapeFactory {

	public Shape getShape(String shapeType){
		Shape shape = null;
		if(shapeType.equalsIgnoreCase("Circle")){
			shape = new Circle();
		}else if(shapeType.equalsIgnoreCase("Triangle")){
			shape = new Triangle();
		}else if(shapeType.equalsIgnoreCase("Rectangle")){
			shape = new Rectangle();
		}
		return shape;
	}
}

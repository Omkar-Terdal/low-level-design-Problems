package org.example.lld.InterviewProblems.Splitwise.Enums;

public enum SplitTypes {
	EXACT,
	EQUAL,
	PERCENTAGE
}

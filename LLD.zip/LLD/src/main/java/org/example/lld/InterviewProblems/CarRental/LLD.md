# Car Rental System — LLD (1-hour interview scope)

Reference problem: ZoomCar / car-rental. This is the **minimal** design — enough to code and defend in ~60 min.

## 1. Scope

**In**
- Multiple stores, each with its own car inventory (per city).
- Search available cars by city + car type + date range.
- Reserve a car, cancel, pick up, return.
- Price the rental on return (per-day rate) and record a payment.

**Out (say this out loud, don't build it)**
- Auth / login, real payment gateway, refunds.
- One-way rental (pickup store ≠ drop store), insurance add-ons, damage handling.
- Reviews, loyalty, surge/seasonal pricing, notifications.
- Persistence, concurrency control, distributed inventory.

## 2. Requirements

| # | Functional |
|---|---|
| FR1 | `searchCars(city, type, start, end)` → cars free for the whole window |
| FR2 | `createReservation(customer, carId, start, end)` → SCHEDULED reservation, car → RESERVED |
| FR3 | `cancelReservation(id)` → only if SCHEDULED, car → AVAILABLE |
| FR4 | `pickupCar(id)` → SCHEDULED → ONGOING, car → RENTED |
| FR5 | `returnCar(id)` → ONGOING → COMPLETED, car → AVAILABLE, create PAID `Payment` = rate × days |

NFR: extensible pricing (Strategy), single service entry point, each op validates state + inputs.

## 3. Entities

| Class | Responsibility |
|---|---|
| `Car` | id, regNumber, `CarType`, `dailyRate`, `storeId`, mutable `CarStatus` |
| `Customer` | id, name, drivingLicense |
| `Store` | id, name, city, `List<Car>` |
| `Reservation` | id, customer, car, start, end, `ReservationStatus`; `getDays()`, `overlaps()` |
| `Payment` | id, reservationId, amount, `PaymentStatus` |
| `PricingStrategy` (iface) | `calculatePrice(Car, days)` → `DailyPricingStrategy` (rate × days) |
| `CarRentalService` | facade + in-memory maps (`stores`, `reservations`, `payments`); all 5 operations + helpers `isFree`, `findCar`, `validateDates` |

Enums: `CarType` (HATCHBACK/SEDAN/SUV/LUXURY), `CarStatus` (AVAILABLE/RESERVED/RENTED/UNDER_MAINTENANCE), `ReservationStatus` (SCHEDULED/ONGOING/COMPLETED/CANCELLED), `PaymentStatus` (PENDING/PAID/FAILED).

## 4. Class diagram (text)

```
CarRentalService
  ├─ Map<String,Store>       stores
  ├─ Map<String,Reservation> reservations
  ├─ Map<String,Payment>     payments
  └─ PricingStrategy ── DailyPricingStrategy

Store 1─* Car        (Car.status drives quick availability)
Reservation *─1 Car
Reservation *─1 Customer
Payment 1─1 Reservation (by id)
```

## 5. Availability check

Two layers, keep both:
- `Car.status` — fast filter, and blocks a car that's physically RENTED / in maintenance.
- `Reservation.overlaps(start,end)` scan over SCHEDULED + ONGOING reservations for that car — the real correctness check, lets future bookings not collide.

`isFree(car, start, end)` = status ≠ maintenance **and** no overlapping active reservation.

## 6. State machines

```
Reservation: SCHEDULED ──pickup──▶ ONGOING ──return──▶ COMPLETED
             SCHEDULED ──cancel──▶ CANCELLED
Car:         AVAILABLE ─reserve─▶ RESERVED ─pickup─▶ RENTED ─return─▶ AVAILABLE
             RESERVED ─cancel──▶ AVAILABLE
```

## 7. Patterns used

| Pattern | Where | Why |
|---|---|---|
| Strategy | `PricingStrategy` | weekend / seasonal / long-rental pricing = new class, no service change |
| Facade | `CarRentalService` | one coordinated API over inventory + reservations + payments |
| Repository (in-memory) | the 3 maps | swap for DB later without touching call sites |
| State (implicit) | `CarStatus` / `ReservationStatus` + guards | illegal transitions throw |

## 8. Suggested 60-min split

1. 0–8 min — clarify scope, lock the 5 operations, list out-of-scope.
2. 8–15 — enums + `Car` / `Customer` / `Store` / `Reservation` / `Payment` skeletons.
3. 15–25 — `CarRentalService`: `searchCars`, `isFree`, `createReservation`.
4. 25–40 — `cancel` / `pickup` / `return` + `PricingStrategy`.
5. 40–50 — `main` walkthrough (search → reserve → pickup → return), dry-run.
6. 50–60 — follow-ups discussion (below).

## 9. Follow-ups (discuss, don't code)

- **Concurrency** — two users reserve the last car: move `isFree` + reserve under a per-car lock, or a DB row `UPDATE ... WHERE status='AVAILABLE'` and check affected rows / optimistic `version`.
- **One-way rental** — add `dropStoreId` to `Reservation`; on return, car joins the drop store's inventory.
- **Pricing variants** — `WeekendPricingStrategy`, `LongRentalDiscountStrategy`; or compose with a decorator for add-ons (GPS, child seat, insurance).
- **Payment** — `PaymentGateway` interface, PENDING → PAID/FAILED, retry; block pickup until PAID if pre-paid model.
- **Search at scale** — index cars by `(city, type)`; availability via a reservations table indexed on `(carId, startDate)` instead of a full scan.
- **Maintenance / damage** — `UNDER_MAINTENANCE` transitions, block reservation, service log.
- **DB schema** — `store`, `car(store_id FK, status)`, `reservation(car_id FK, customer_id FK, start, end, status, version)`, `payment(reservation_id FK, amount, status)`; indexes `(car_id, status)`, `(reservation.car_id, start_date)`.

## 10. Run

```
javac -d /tmp/out $(find . -name '*.java')
java -cp /tmp/out org.example.lld.InterviewProblems.CarRental.CarRentalMain
```

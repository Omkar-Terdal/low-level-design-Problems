package org.example.lld.InterviewProblems.BookMyShow.Models;

import org.example.lld.InterviewProblems.BookMyShow.Enums.SeatStatus;
import org.example.lld.InterviewProblems.BookMyShow.Enums.SeatType;

public class Seat {
	private Long seatId;
	private String row;
	private int seatNumber;
	private SeatType seatType;
	private SeatStatus seatStatus;

	public Seat(Long seatId, String row, int seatNumber, SeatType seatType, SeatStatus seatStatus) {
		this.seatId = seatId;
		this.row = row;
		this.seatNumber = seatNumber;
		this.seatType = seatType;
		this.seatStatus=seatStatus;
	}

	public Long getSeatId() {
		return seatId;
	}
	public String getRow() {
		return row;
	}

	public int getSeatNumber() {
		return seatNumber;
	}
	public SeatType getSeatType() {
		return seatType;
	}
	public SeatStatus getSeatStatus() {
		return seatStatus;
	}
	public void setSeatStatus(SeatStatus seatStatus) {
		this.seatStatus = seatStatus;
	}

	@Override
	public String toString() {
		return "Seats{"+
				"seatId"+ seatId +
				", row=" + row +
				", seatNumber="+ seatNumber +
				", seatType="+ seatType +
				", seatStatus="+ seatStatus+ "}";

	}
}

package org.example.lld.InterviewProblems.SnakeAndLadder.Models;


import java.util.*;

public class SnakeAndLadderMain {

	public static void main(String[] args) {
		List<Snake> snakes = new ArrayList<>(Arrays.asList(
				new Snake(17, 7),
				new Snake(54, 34),
				new Snake(62, 19),
				new Snake(64, 60),
				new Snake(87, 24),
				new Snake(93, 73),
				new Snake(95, 75),
				new Snake(99, 78)
		));

		List<Ladder> ladders = new ArrayList<>(Arrays.asList(
				new Ladder(2, 23),
				new Ladder(8, 34),
				new Ladder(20, 77),
				new Ladder(29, 41),
				new Ladder(50, 67),
				new Ladder(71, 92),
				new Ladder(80, 99)
		));

		Board board=new Board(100,snakes,ladders);
		Dice dice=new Dice(6);

		Queue<Player> playerList = new LinkedList<>(Arrays.asList(
				new Player("omkar"),
				new Player("Rahul"),
				new Player("Arpit")));

		Game game=new Game(board,dice,playerList);
		game.startGame();

	}
}

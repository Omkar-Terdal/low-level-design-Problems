package org.example.lld.InterviewProblems.Elevator.Enums;

public enum Direction {
	UP,
	DOWN,
	IDLE
}

package org.example.lld.InterviewProblems.CouponMangement.r2.Models;

public class CouponResult {

	private boolean success;
	private double discount;
	private double finalAmount;
	private String message;

	public CouponResult(boolean success,
	                    double discount,
	                    double finalAmount,
	                    String message) {
		this.success = success;
		this.discount = discount;
		this.finalAmount = finalAmount;
		this.message = message;
	}

	public static CouponResult success(double discount,
	                                   double finalAmount) {

		return new CouponResult(
				true,
				discount,
				finalAmount,
				"Coupon applied successfully."
		);
	}

	public static CouponResult failure(String message) {

		return new CouponResult(
				false,
				0,
				0,
				message
		);
	}

	public boolean isSuccess() {
		return success;
	}

	public double getDiscount() {
		return discount;
	}

	public double getFinalAmount() {
		return finalAmount;
	}

	public String getMessage() {
		return message;
	}
}
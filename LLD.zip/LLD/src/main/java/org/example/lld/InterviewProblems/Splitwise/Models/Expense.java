package org.example.lld.InterviewProblems.Splitwise.Models;

import java.util.ArrayList;
import java.util.List;

public class Expense {
	private Long id;
	private String description;
	private Double amount;
	private User paidBy;
	private List<Split> splitList;
	private List<User> users;
	private List<Double> exactAmounts;
	private List<Double> percentages;

	public Expense(Long id, String description, Double amount, User paidBy,List<Split> splitList) {
		this.id = id;
		this.description = description;
		this.amount = amount;
		this.paidBy = paidBy;
		this.splitList =splitList;
		this.users = new ArrayList<>();
		this.exactAmounts = new ArrayList<>();
		this.percentages = new ArrayList<>();
	}

	public Long getId() {
		return id;
	}

	public String getDescription() {
		return description;
	}
	public Double getAmount() {
		return amount;
	}


	public User getPaidBy() {
		return paidBy;
	}
	public List<Split> getSplitList() {
		return splitList;
	}

	public void addSplit(Split split){
		this.splitList.add(split);
	}

	@Override
	public String toString() {
		return "Expense{" +
				"id=" + id +
				", description='" + description + '\'' +
				", amount=" + amount +
				", paidBy=" + paidBy +
				", splitList=" + splitList +
				'}';
	}
}

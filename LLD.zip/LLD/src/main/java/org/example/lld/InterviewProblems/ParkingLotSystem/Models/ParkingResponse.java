package org.example.lld.InterviewProblems.ParkingLotSystem.Models;

public class ParkingResponse {
	private boolean success;
	private String message;
	private Ticket ticket;

	public ParkingResponse(boolean success, String message, Ticket ticket) {
		this.success = success;
		this.message = message;
		this.ticket = ticket;
	}

	public boolean isSuccess() {
		return success;
	}
	public Ticket getTicket() {
		return ticket;
	}
	public String getMessage() {
		return message;
	}

	@Override
	public String toString() {
		return "ParkingResponse [success=" + success + ", message=" + message + ", ticket=" + ticket + "]";
	}
}

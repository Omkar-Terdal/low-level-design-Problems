package org.example.lld.DesignPattern.BehaviouralPattern.StratergryPattern.WithoutStratergyPattern;

public class NormalVehicle extends Vehicle{

	@Override
	public void drive() {
		System.out.println("Running normal speed capacbility");
	}
}

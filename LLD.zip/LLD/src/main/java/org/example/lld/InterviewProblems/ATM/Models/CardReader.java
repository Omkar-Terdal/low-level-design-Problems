package org.example.lld.InterviewProblems.ATM.Models;



public class CardReader {
	private Card insertCard;
	public CardReader(Card insertCard) {
		this.insertCard = insertCard;
		System.out.println("Card inserted");
	}
	public Card readCard() {
		return insertCard;
	}
	public void insertCard(Card card) {
		this.insertCard = card;
	}
	public Card ejectCard() {
		Card card=insertCard;
		this.insertCard = null;
		System.out.println("Card EJECTED");
		return card;
	}
	public boolean isCardInserted(){
		return insertCard!=null;
	}
}

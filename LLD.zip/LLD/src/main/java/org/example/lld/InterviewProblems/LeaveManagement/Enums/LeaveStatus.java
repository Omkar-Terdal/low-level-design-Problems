package org.example.lld.InterviewProblems.LeaveManagement.Enums;

public enum LeaveStatus {
	PENDING,
	APPROVED,
	REJECTED,
	CANCELED
}

package org.example.lld.DesignPattern.BehaviouralPattern.ObserverPattern;

import java.util.ArrayList;
import java.util.List;

public class YoutubeChannel {

	List<Observer> observers = new ArrayList<>();
	private boolean newVideo = false;

	public void subscribe(Observer observer) {
		observers.add(observer);
	}

	public void uplodaVideo(){
		newVideo=true;
		notifyAllSubscribers();
	}

	private void notifyAllSubscribers(){
		if(newVideo){
			for(Observer observer : observers){
				observer.update();
			}
		}
	}



}

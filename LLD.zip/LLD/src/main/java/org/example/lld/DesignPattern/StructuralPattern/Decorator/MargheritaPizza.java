package org.example.lld.DesignPattern.StructuralPattern.Decorator;

public class MargheritaPizza extends BasePizza{

	@Override
	public int cost() {
		return 100;
	}
}

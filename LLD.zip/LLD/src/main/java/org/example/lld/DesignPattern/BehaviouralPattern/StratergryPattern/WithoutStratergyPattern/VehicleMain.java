package org.example.lld.DesignPattern.BehaviouralPattern.StratergryPattern.WithoutStratergyPattern;


public class VehicleMain {

	public static void main(String[] args) {
		Vehicle vehicle = new Vehicle();
		vehicle.drive();

	}

}

package org.example.lld.InterviewProblems.Elevator.Models;

import org.example.lld.InterviewProblems.Elevator.Enums.Direction;
import org.example.lld.InterviewProblems.Elevator.Interface.ButtonListner;
import org.example.lld.InterviewProblems.Elevator.Interface.ElevatorPanelListener;
import org.example.lld.InterviewProblems.Elevator.Stratergy.ElevatorStratergy;

import java.util.ArrayList;
import java.util.List;

public class ElevatorController implements ElevatorPanelListener {
	private List<Elevator> elevators=new ArrayList<>();
	private ElevatorStratergy elevatorStratergy;

	public ElevatorController(List<Elevator> elevators, ElevatorStratergy elevatorStratergy) {
		this.elevators=elevators;
		this.elevatorStratergy=elevatorStratergy;
	}

//	@Override
//	public void onPressHallButton(int floorNumber, Direction direction) {
//		ExternalRequest request=new ExternalRequest(floorNumber,direction);
//		Elevator elevator=elevatorStratergy.selectStratergy(elevators,request);
//		elevator.addExternalRequest(request);
//	}
	public void onFloorButtonPressed(Elevator elevator,
	                                  int destinationFloor) {

		InternalRequest request =
				new InternalRequest(destinationFloor);

		elevator.addInternalRequest(request);
	}
}

package org.example.lld.DesignPattern.BehaviouralPattern.ObserverPattern;

public class ObserverMain {

	public static void main(String[] args) {
		YoutubeChannel channel = new YoutubeChannel();

		Subscribe omkar=new Subscribe("Omkar");
		// subscribe -> omkar  actual object
		// observer  -> omkar  reference to that object

		Subscribe rahul=new Subscribe("Rahul");

		EmailObserver omkar1=new EmailObserver("Omkar");

		channel.subscribe(omkar);
		channel.subscribe(rahul);
		channel.subscribe(omkar1);

		channel.uplodaVideo();


	}
}

package org.example.lld.InterviewProblems.ParkingLotSystem.PaymentStratergy;

public interface PaymentStratergy {
	void pay(double amount);
}

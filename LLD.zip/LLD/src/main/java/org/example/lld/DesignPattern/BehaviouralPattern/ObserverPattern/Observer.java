package org.example.lld.DesignPattern.BehaviouralPattern.ObserverPattern;

public interface Observer {

	void update();
}

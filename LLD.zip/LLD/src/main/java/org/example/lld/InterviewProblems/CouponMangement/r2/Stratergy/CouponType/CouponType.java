package org.example.lld.InterviewProblems.CouponMangement.r2.Stratergy.CouponType;

import org.example.lld.InterviewProblems.CouponMangement.r2.Models.Cart;

public interface CouponType {
	double calculateDiscount(Cart cart);
}

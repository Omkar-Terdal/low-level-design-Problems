package org.example.lld.InterviewProblems.CarRental.Models;

import org.example.lld.InterviewProblems.CarRental.Enums.ReservationStatus;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Reservation {
	private final String reservationId;
	private final Customer customer;
	private final Car car;
	private final LocalDate startDate;
	private final LocalDate endDate;
	private ReservationStatus status;

	public Reservation(String reservationId, Customer customer, Car car,
	                   LocalDate startDate, LocalDate endDate) {
		this.reservationId = reservationId;
		this.customer = customer;
		this.car = car;
		this.startDate = startDate;
		this.endDate = endDate;
		this.status = ReservationStatus.SCHEDULED;
	}

	/** Rental days, minimum 1 (a same-day rental still costs a day). */
	public long getDays() {
		long days = ChronoUnit.DAYS.between(startDate, endDate);
		return Math.max(days, 1);
	}

	public boolean overlaps(LocalDate start, LocalDate end) {
		return !start.isAfter(endDate) && !end.isBefore(startDate);
	}

	public String getReservationId() {
		return reservationId;
	}

	public Customer getCustomer() {
		return customer;
	}

	public Car getCar() {
		return car;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public ReservationStatus getStatus() {
		return status;
	}

	public void setStatus(ReservationStatus status) {
		this.status = status;
	}
}

package org.example.lld.InterviewProblems.CarRental.Enums;

public enum PaymentStatus {
	PENDING,
	PAID,
	FAILED
}

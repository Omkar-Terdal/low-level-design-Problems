package org.example.lld.InterviewProblems.CouponMangement.r2.Stratergy.ApplicabilityRules;

import org.example.lld.InterviewProblems.CouponMangement.r2.Enums.UserSegment;
import org.example.lld.InterviewProblems.CouponMangement.r2.Models.Cart;
import org.example.lld.InterviewProblems.CouponMangement.r2.Models.User;

import java.util.Set;

public class UserSegmentRule implements ApplicabilityRules{
	private Set<UserSegment> allowedUserSegment;

	public UserSegmentRule(Set<UserSegment> allowedUserSegment) {
		this.allowedUserSegment = allowedUserSegment;
	}

	@Override
	public boolean isApplicable(User user, Cart cart) {

	return allowedUserSegment.contains(user.getUserSegment());
	}
}

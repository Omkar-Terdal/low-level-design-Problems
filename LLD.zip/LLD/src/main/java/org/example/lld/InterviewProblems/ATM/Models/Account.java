package org.example.lld.InterviewProblems.ATM.Models;

public class Account {
	private double balance;
	private String AccountNumber;

	public  Account(double balance, String AccountNumber){
		this.balance = balance;
		this.AccountNumber = AccountNumber;
	}
	public double getBalance() {
		return balance;
	}
	public String getAccountNumber() {
		return AccountNumber;
	}

	public void debitAmount(double amount) {
		if(amount>balance){
			throw new RuntimeException("Insufficient Balance");
		}
		this.balance -= amount;
	}

	public void creditAmount(double amount) {
		if(amount<=0){
			throw new RuntimeException("Insufficient Balance");
		}
		this.balance += amount;
	}



}

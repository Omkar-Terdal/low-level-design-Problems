package org.example.lld.InterviewProblems.LeaveManagement.Models;

import org.example.lld.InterviewProblems.LeaveManagement.Enums.LeaveStatus;
import org.example.lld.InterviewProblems.LeaveManagement.Enums.LeaveType;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

public class LeaveManagementService {
	private Map<String,Employee> employeeMap;
	private List<LeaveApprovalHistory> leaveApprovalHistory;
	private Map<String, LeaveRequest> leaveRequests;
	private Map<String,List<LeaveRequest>> employeeLeaveRequests;

	public LeaveManagementService() {
		this.employeeMap = new HashMap<>();
		this.leaveApprovalHistory = new ArrayList<>();
		this.leaveRequests = new HashMap<>();
		this.employeeLeaveRequests = new HashMap<>();
	}
	public void addEmployee(Employee employee) {

		if (employee == null) {
			throw new IllegalArgumentException("Employee cannot be null");
		}

		if (employeeMap.containsKey(employee.employerId())) {
			throw new IllegalArgumentException("Employee already exists");
		}

		employeeMap.put(employee.employerId(), employee);
	}

	public LeaveRequest applyLeave(Employee employee, LocalDate start, LocalDate end, LeaveType leaveType,String reason) {
		if(employee == null) {
			throw new IllegalArgumentException("Employee is null");
		}
		if(!employeeMap.containsKey(employee.employerId())){
			throw new IllegalArgumentException("Employee not found");
		}

		List<LeaveRequest> leaveRequests = employeeLeaveRequests.getOrDefault(employee.employerId(),
				Collections.emptyList());
		for(LeaveRequest existing : leaveRequests) {
			if (!start.isAfter(existing.getEndTime()) &&
					!end.isBefore(existing.getStartTime())) {
				throw new IllegalArgumentException("Overlapping leave request");
			}
		}
		Integer balance=employee.leaveBalance().get(leaveType);
		if(balance==null ||  balance<=0){
			throw new IllegalArgumentException("Leave balance cannot be zero");
		}


		LeaveRequest leaveRequest=new LeaveRequest(
					UUID.randomUUID().toString(),
					employee,
					leaveType,
					start,
					end,
					LeaveStatus.PENDING,
					LocalDateTime.now(),
					reason
				);

		this.leaveRequests.put(leaveRequest.getReqId(), leaveRequest);
		employeeLeaveRequests.computeIfAbsent(employee.employerId(),k->new ArrayList<>()).add(leaveRequest);
		LeaveApprovalHistory leavehistory= new LeaveApprovalHistory(
				"H1",
				leaveRequest,
				LeaveStatus.PENDING,
				employee,
				LocalDateTime.now(),
				"Applied Leave"
				);

		leaveApprovalHistory.add(leavehistory);

		return leaveRequest;
	}

	public void approveLeave(String requestId ,Employee manager) {
		LeaveRequest leaveRequest = validateManagerRequest(requestId, manager);
		if (leaveRequest.getLeaveStatus() != LeaveStatus.PENDING)
			throw new IllegalArgumentException("Leave request is not PENDING");
		leaveRequest.setLeaveStatus(LeaveStatus.APPROVED);
		Map<LeaveType, Integer> balance = leaveRequest.getEmployee().leaveBalance();

		Integer remainingLeaves =
				balance.get(leaveRequest.getLeaveType());

		if (remainingLeaves == null || remainingLeaves <= 0) {
			throw new IllegalArgumentException("Insufficient leave balance");
		}
		balance.put(leaveRequest.getLeaveType(),remainingLeaves - 1);

		LeaveApprovalHistory leavehistory = new LeaveApprovalHistory(
				UUID.randomUUID().toString(),
				leaveRequest,
				LeaveStatus.APPROVED,
				manager,
				LocalDateTime.now(),
				"Approved"
		);
		leaveApprovalHistory.add(leavehistory);

	}


	public void rejectLeave(String requestId,Employee manager){
		LeaveRequest leaveRequests = validateManagerRequest(requestId,manager);

		if(leaveRequests.getLeaveStatus() != LeaveStatus.PENDING){
			throw new IllegalArgumentException( "Only pending requests can be rejected");
		}

		leaveRequests.setLeaveStatus(LeaveStatus.REJECTED);
		LeaveApprovalHistory leavehistory = new LeaveApprovalHistory(
				UUID.randomUUID().toString(),
				leaveRequests,
				LeaveStatus.REJECTED,
				manager,
				LocalDateTime.now(),
				"Rejected"
		);
		leaveApprovalHistory.add(leavehistory);
	}

	public void cancelLeave(String requestId, Employee employee) {

		LeaveRequest leaveRequest = validateEmployeeRequest(requestId, employee);

		if (leaveRequest.getLeaveStatus() == LeaveStatus.REJECTED ||
				leaveRequest.getLeaveStatus() == LeaveStatus.CANCELED) {
			throw new IllegalArgumentException("Cannot cancel this request.");
		}

		if (!LocalDate.now().isBefore(leaveRequest.getStartTime())) {
			throw new IllegalArgumentException("Cannot cancel after leave has started.");
		}

		if (leaveRequest.getLeaveStatus() == LeaveStatus.APPROVED) {
			Map<LeaveType, Integer> balance = leaveRequest.getEmployee().leaveBalance();

			balance.put(
					leaveRequest.getLeaveType(),
					balance.get(leaveRequest.getLeaveType()) + 1
			);
		}

		leaveRequest.setLeaveStatus(LeaveStatus.CANCELED);

		leaveApprovalHistory.add(
				new LeaveApprovalHistory(
						UUID.randomUUID().toString(),
						leaveRequest,
						LeaveStatus.CANCELED,
						employee,
						LocalDateTime.now(),
						"Cancelled"
				)
		);
	}
	public Map<LeaveType,Integer> getLeaveBalance(Employee employee) {
		if (employee == null) {
			throw new IllegalArgumentException("Employee cannot be null");
		}

		if (!employeeMap.containsKey(employee.employerId())) {
			throw new IllegalArgumentException("Employee not found");
		}
		return employee.leaveBalance();
	}

	public List<LeaveRequest> getPendingRequests(Employee manager) {
		if (manager == null) {
			throw new IllegalArgumentException("Employee cannot be null");
		}

		if (!employeeMap.containsKey(manager.employerId())) {
			throw new IllegalArgumentException("Employee not found");
		}
		List<LeaveRequest> leaveRequests = new ArrayList<>();
		for(LeaveRequest leaveRequest: this.leaveRequests.values()){
			if(leaveRequest.getLeaveStatus() == LeaveStatus.PENDING && leaveRequest.getEmployee().manager().employerId().equals(manager.employerId())) {
				leaveRequests.add(leaveRequest);
			}
		}
		return leaveRequests;
	}

	private LeaveRequest validateEmployeeRequest(String requestId, Employee employee) {

		if (requestId == null || requestId.isEmpty()) {
			throw new IllegalArgumentException("Request id cannot be null");
		}

		LeaveRequest leaveRequest = leaveRequests.get(requestId);

		if (leaveRequest == null) {
			throw new IllegalArgumentException("Leave request not found");
		}

		if (!leaveRequest.getEmployee().employerId()
				.equals(employee.employerId())) {
			throw new IllegalArgumentException(
					"Employee cannot access another employee's leave request");
		}

		return leaveRequest;
	}
	private LeaveRequest validateManagerRequest(String requestId, Employee employee) {
		if(requestId == null || requestId.isEmpty()){
			throw new IllegalArgumentException("requestId is null");
		}

		LeaveRequest  leaveRequests = this.leaveRequests.get(requestId);
		if(leaveRequests==null){
			throw new IllegalArgumentException("request not found");
		}
		if(!leaveRequests.getEmployee().manager().employerId().equals(employee.employerId())){
			throw new IllegalArgumentException("Only reporting manager can approve");
		}
		return leaveRequests;
	}
}

package org.example.lld.InterviewProblems.CarRental.Models;

public class Customer {
	private final String customerId;
	private final String name;
	private final String drivingLicense;

	public Customer(String customerId, String name, String drivingLicense) {
		this.customerId = customerId;
		this.name = name;
		this.drivingLicense = drivingLicense;
	}

	public String getCustomerId() {
		return customerId;
	}

	public String getName() {
		return name;
	}

	public String getDrivingLicense() {
		return drivingLicense;
	}
}

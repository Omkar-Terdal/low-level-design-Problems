package org.example.lld.InterviewProblems.Splitwise.Models;

import org.example.lld.InterviewProblems.Splitwise.SplitStratergy.SplitStrategry;

import java.util.ArrayList;
import java.util.List;

public class EqualSplit extends Split {

	public EqualSplit(User user) {
		super(user,0);
	}
}

package org.example.lld.InterviewProblems.CarRental.Strategy;

import org.example.lld.InterviewProblems.CarRental.Models.Car;

/** Flat per-day rate of the car. Swap in weekend / seasonal / long-rental discount variants later. */
public class DailyPricingStrategy implements PricingStrategy {
	@Override
	public double calculatePrice(Car car, long days) {
		return car.getDailyRate() * days;
	}
}

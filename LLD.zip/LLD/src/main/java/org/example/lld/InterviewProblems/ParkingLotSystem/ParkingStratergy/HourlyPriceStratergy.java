package org.example.lld.InterviewProblems.ParkingLotSystem.ParkingStratergy;

import org.example.lld.InterviewProblems.ParkingLotSystem.Models.Ticket;

import java.time.Duration;

public class HourlyPriceStratergy implements PriceStratergy {

	@Override
	public double calculatePrice(Ticket ticket) {
		long hours= Duration.between(ticket.getEntryTime(),ticket.getExitTime()).toHours();
		if(hours==0){
			return 1;
		}

		return hours*50;
	}
}

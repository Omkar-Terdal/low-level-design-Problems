package org.example.lld.InterviewProblems.TicTacToe.Models;

import org.example.lld.InterviewProblems.TicTacToe.Enums.PieceType;

public class Xpiece extends PlayingPiece{

	public Xpiece() {
		super(PieceType.X);
	}
}

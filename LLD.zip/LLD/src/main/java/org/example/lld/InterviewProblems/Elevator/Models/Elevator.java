package org.example.lld.InterviewProblems.Elevator.Models;

import org.example.lld.InterviewProblems.Elevator.Enums.Direction;
import org.example.lld.InterviewProblems.Elevator.Enums.ElevatorState;
import org.example.lld.InterviewProblems.Elevator.Interface.ElevatorPanelListener;

import java.util.LinkedList;
import java.util.Queue;

public class Elevator {
	private int  id;
	private Direction direction;
	private int currentFloor;
	private ElevatorState state;
	private Door door;
	private Display display;
	private ElevatorPanel elevatorPanel;
	private Queue<ExternalRequest> externalRequestQueue;
	private Queue<InternalRequest> internalRequestQueue;

	public Elevator(int elevatorId, ElevatorPanelListener elevatorPanelListner) {
		this.id = elevatorId;
		this.direction=Direction.IDLE;
		this.currentFloor=0;
		this.state=ElevatorState.IDLE;
		this.door=new Door();
		this.display=new Display();
		this.elevatorPanel = new ElevatorPanel(this,elevatorPanelListner);
		this.externalRequestQueue = new LinkedList<>();
		this.internalRequestQueue=new LinkedList<>();
	}

	public int getId(){
		return this.id;
	}
	public Direction getDirection(){
		return this.direction;
	}
	public int getCurrentFloor(){
		return this.currentFloor;
	}
	public ElevatorState getState(){
		return this.state;
	}
	public Door getDoor(){
		return this.door;
	}
	public Display getDisplay(){
		return this.display;
	}
	public ElevatorPanel getElevatorPanel(){
		return this.elevatorPanel;
	}
	public Queue<ExternalRequest> getExternalRequestQueue(){
		return this.externalRequestQueue;
	}

	public void addExternalRequest(ExternalRequest externalRequest){
		this.externalRequestQueue.add(externalRequest);
	}
	public Queue<InternalRequest> getInternalRequestQueue(){
		return this.internalRequestQueue;
	}
	public void addInternalRequest(InternalRequest internalRequest){
		this.internalRequestQueue.add(internalRequest);
	}

}

package org.example.lld.InterviewProblems.VendingMachine.payment;

public class CashPayment implements Payment {

	@Override
	public void pay(double amount) {
		System.out.println("Received cash payment: " + amount);
	}

	@Override
	public void refund(double amount) {
		if (amount > 0) {
			System.out.println("Returning change: " + amount);
		}
	}
}

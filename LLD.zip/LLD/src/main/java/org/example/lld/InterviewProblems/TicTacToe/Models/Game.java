package org.example.lld.InterviewProblems.TicTacToe.Models;

import org.example.lld.InterviewProblems.TicTacToe.Enums.PieceType;
import org.example.lld.InterviewProblems.TicTacToe.PieceFactory.PieceFactory;

import java.sql.SQLOutput;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Game {
	private Board board;
	private Queue<Player> q;
	private Scanner scanner;
	private PieceFactory pieceFactory;


	public Game(int size) {
		this.board = new Board(size);
		this.q = new LinkedList<>();
		this.scanner = new Scanner(System.in);

		initializeGame();
	}

	private void initializeGame() {
		System.out.println("Enter 1st Player Name");
		String playerName1 = scanner.next();
		System.out.println("Enter 2nd Player Name");
		String playerName2 = scanner.next();

		System.out.println(playerName1 +", choose piece X/O");
		String pieceX = scanner.next().toUpperCase();

		PlayingPiece piece1;
		PlayingPiece piece2;
		PieceFactory pieceFactory = new PieceFactory();
		if(pieceX.equals("X")){
			piece1=pieceFactory.createPlayingPiece(PieceType.X);
			piece2=pieceFactory.createPlayingPiece(PieceType.O);
		}else{
			piece1=pieceFactory.createPlayingPiece(PieceType.O);
			piece2=pieceFactory.createPlayingPiece(PieceType.X);
		}
		Player p1 = new Player(playerName1, piece1);
		Player p2 = new Player(playerName2, piece2);

		q.offer(p1);
		q.offer(p2);

	}

	public void startGame() {
		while (true) {
			board.printBoard();
			Player p1 = q.peek();
			System.out.println(p1.getName()+ "'s turn");

			int row =scanner.nextInt();
			int col = scanner.nextInt();

			boolean placed=board.placePiece(row,col, p1.getPlayingPiece());

			if(!placed){
				System.out.println("Invalid move. Try again.");
				continue;
			}
			if(board.checkWinner(row,col,p1.getPlayingPiece())){
				System.out.println("Congratulations! " + p1.getName() +"You win!");
				board.printBoard();
				break;
			}
			if(board.isBoardFull()){
				System.out.println("Draw Game");
				board.printBoard();
				break;
			}
			q.poll();
			q.offer(p1);
		}
	}

}

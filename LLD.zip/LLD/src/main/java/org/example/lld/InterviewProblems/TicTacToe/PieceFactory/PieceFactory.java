package org.example.lld.InterviewProblems.TicTacToe.PieceFactory;

import org.example.lld.InterviewProblems.TicTacToe.Enums.PieceType;
import org.example.lld.InterviewProblems.TicTacToe.Models.Opiece;
import org.example.lld.InterviewProblems.TicTacToe.Models.PlayingPiece;
import org.example.lld.InterviewProblems.TicTacToe.Models.Xpiece;

public class PieceFactory {

	public PlayingPiece createPlayingPiece(PieceType pieceType) {
		return switch (pieceType){
			case O -> new Opiece();
			case X -> new Xpiece();
		};
	}
}

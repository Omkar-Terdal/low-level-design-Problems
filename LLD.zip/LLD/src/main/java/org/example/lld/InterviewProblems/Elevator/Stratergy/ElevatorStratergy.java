package org.example.lld.InterviewProblems.Elevator.Stratergy;


import org.example.lld.InterviewProblems.Elevator.Models.Elevator;
import org.example.lld.InterviewProblems.Elevator.Models.Request;

import java.util.List;

public interface ElevatorStratergy {
	Elevator selectStratergy(List<Elevator> elevators, Request request);
}

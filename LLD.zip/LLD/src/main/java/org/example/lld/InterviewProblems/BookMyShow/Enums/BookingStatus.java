package org.example.lld.InterviewProblems.BookMyShow.Enums;

public enum BookingStatus {
	PENDING,
	CONFIRMED,
	CANCELLED
}

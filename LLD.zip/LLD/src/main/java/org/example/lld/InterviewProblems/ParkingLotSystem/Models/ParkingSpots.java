package org.example.lld.InterviewProblems.ParkingLotSystem.Models;

import org.example.lld.InterviewProblems.ParkingLotSystem.Enums.VehicelType;

public class ParkingSpots {

	private Long parkingSpotId;
	private VehicelType parkingSpotType;
	private Vehicle parkedVehicle;

	public ParkingSpots(Long parkingSpotId, VehicelType parkingSpotType) {
		this.parkingSpotId = parkingSpotId;
		this.parkingSpotType = parkingSpotType;
		this.parkedVehicle = null;
	}

	public VehicelType getParkingSpotType() {
		return parkingSpotType;
	}

	public boolean canPark(Vehicle vehicle) {
		return parkedVehicle==null && parkingSpotType==vehicle.getVehicleType();
	}

	public Vehicle getParkedVehicle() {
		return parkedVehicle;
	}

	public boolean isAvailable(){
		return parkedVehicle == null;
	}
	public void parkVehicle(Vehicle parkedVehicle){
		this.parkedVehicle = parkedVehicle;
	}

	public void removeVehicle(){
		this.parkedVehicle = null;
	}

	public Long getSpotNumber() {
		return parkingSpotId;
	}



}

package org.example.lld.InterviewProblems.CouponMangement.r2;

import org.example.lld.InterviewProblems.CouponMangement.r2.Enums.UserSegment;
import org.example.lld.InterviewProblems.CouponMangement.r2.Models.*;
import org.example.lld.InterviewProblems.CouponMangement.r2.Repository.CouponUsageRepository;
import org.example.lld.InterviewProblems.CouponMangement.r2.Repository.InMemoryCouponUsageUsageRepository;
import org.example.lld.InterviewProblems.CouponMangement.r2.Service.CouponService;
import org.example.lld.InterviewProblems.CouponMangement.r2.Stratergy.ApplicabilityRules.ApplicabilityRules;
import org.example.lld.InterviewProblems.CouponMangement.r2.Stratergy.ApplicabilityRules.CategoryRule;
import org.example.lld.InterviewProblems.CouponMangement.r2.Stratergy.ApplicabilityRules.UserSegmentRule;
import org.example.lld.InterviewProblems.CouponMangement.r2.Stratergy.Constraints.*;
import org.example.lld.InterviewProblems.CouponMangement.r2.Stratergy.CouponType.CouponType;
import org.example.lld.InterviewProblems.CouponMangement.r2.Stratergy.CouponType.PercentageCoupon;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

public class CouponMangementMain {
	public static void main(String[] args) {

		// ---------------- Product ----------------
		Product laptop = new Product(
				"Electronics",
				1000.0,
				"P1",
				"Laptop"
		);

		// ---------------- Cart ----------------
		CartItem cartItem = new CartItem(laptop, 2);

		Cart cart = new Cart(
				List.of(cartItem)
		);

		// ---------------- User ----------------
		User user = new User(
				cart,
				"U1",
				"Omkar",
				"omkar@example.com",   // whatever your constructor expects
				UserSegment.PREMIUM
		);

		// ---------------- Coupon Type ----------------
		CouponType couponType = new PercentageCoupon(20);

		// ---------------- Applicability Rules ----------------
		ApplicabilityRules categoryRule =
				new CategoryRule(
						Set.of("Electronics")
				);

		ApplicabilityRules userSegmentRule =
				new UserSegmentRule(
						Set.of(UserSegment.PREMIUM)
				);

		// ---------------- Repository ----------------
		CouponUsageRepository repository =
				new InMemoryCouponUsageUsageRepository();

		// ---------------- Constraints ----------------
		Constraints minimumCartConstraint =
				new MinimumCartValueConstraint(500);

		Constraints maxUsageConstraint =
				new MaxUsageConstraint(

						repository,
						100
				);

		Constraints perUserUsageConstraint =
				new PerUserUsageConstraint(
						repository,
						2
				);

		Constraints dateRangeConstraint =
				new DateRangeConstraint(
						LocalDate.now().minusDays(1),
						LocalDate.now().plusDays(10)
				);

		// ---------------- Coupon ----------------
		Coupon coupon = new Coupon(
				couponType,
				"SAVE20",
				"C1",
				"20% OFF on Electronics",
				List.of(
						categoryRule,
						userSegmentRule
				),
				List.of(
						minimumCartConstraint,
						maxUsageConstraint,
						perUserUsageConstraint,
						dateRangeConstraint
				)
		);

		// ---------------- Coupon Service ----------------
		CouponService couponService =
				new CouponService(repository);

		// ---------------- Apply Coupon ----------------
		CouponResult result =
				couponService.applyCoupon(
						coupon,
						user,
						cart
				);

		// ---------------- Output ----------------
		System.out.println("Success      : " + result.isSuccess());
		System.out.println("Message      : " + result.getMessage());
		System.out.println("Discount     : " + result.getDiscount());
		System.out.println("Final Amount : " + result.getFinalAmount());
	}
}

package org.example.lld.InterviewProblems.VendingMachine.machine;

import org.example.lld.InterviewProblems.VendingMachine.inventory.Inventory;
import org.example.lld.InterviewProblems.VendingMachine.model.Product;
import org.example.lld.InterviewProblems.VendingMachine.payment.Payment;
import org.example.lld.InterviewProblems.VendingMachine.state.IdleState;
import org.example.lld.InterviewProblems.VendingMachine.state.VendingMachineState;

public class VendingMachine {
	private final Inventory inventory;
	private final Payment payment;
	private Product selectedProduct;
	private double insertedAmount;
	private VendingMachineState currentState;

	public VendingMachine(Inventory inventory, Payment payment) {
		this.inventory = inventory;
		this.payment = payment;
		this.insertedAmount = 0;
		this.currentState = new IdleState();
	}

	public void selectProduct(Product product) {
		currentState.selectProduct(this, product);
	}

	public void insertMoney(double amount) {
		currentState.insertMoney(this, amount);
	}

	public void dispenseProduct() {
		currentState.dispenseProduct(this);
	}

	public void cancelTransaction() {
		currentState.cancelTransaction(this);
	}

	public void returnChange() {
		double change = insertedAmount - (selectedProduct != null ? selectedProduct.getPrice() : 0);
		if (change > 0) {
			payment.refund(change);
		}
		insertedAmount = 0;
		selectedProduct = null;
	}

	public void setState(VendingMachineState state) {
		this.currentState = state;
	}

	public Inventory getInventory() {
		return inventory;
	}

	public Payment getPayment() {
		return payment;
	}

	public Product getSelectedProduct() {
		return selectedProduct;
	}

	public void setSelectedProduct(Product product) {
		this.selectedProduct = product;
	}

	public double getInsertedAmount() {
		return insertedAmount;
	}

	public void setInsertedAmount(double amount) {
		this.insertedAmount = amount;
	}

	public VendingMachineState getCurrentState() {
		return currentState;
	}
}

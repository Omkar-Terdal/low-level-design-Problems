package org.example.lld.InterviewProblems.SnakeAndLadder.Models;

import java.util.List;

public class Board {
	private int size;
	private List<Snake> snakeList;
	private List<Ladder> ladderList;

	public Board(int size,List<Snake> snakeList, List<Ladder> ladderList){
		this.size = size;
		this.snakeList = snakeList;
		this.ladderList = ladderList;
	}

	public List<Snake> getSnakeList() {
		return snakeList;
	}

	public void setSnakeList(List<Snake> snakeList) {
		this.snakeList = snakeList;
	}

	public List<Ladder> getLadderList() {
		return ladderList;
	}

	public void setLadderList(List<Ladder> ladderList) {
		this.ladderList = ladderList;
	}

	public int getPostition(int position){
		for(Snake snake : snakeList){
			if(position==snake.getHead()){
				return snake.getTail();
			}
		}

		for(Ladder  ladder: ladderList){
			if(position==ladder.getStart()){
				return ladder.getEnd();
			}
		}
		return position;
	}

	public int getSize(){
		return size;
	}


}

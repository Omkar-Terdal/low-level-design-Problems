package org.example.lld.InterviewProblems.VendingMachine.state;

import org.example.lld.InterviewProblems.VendingMachine.machine.VendingMachine;
import org.example.lld.InterviewProblems.VendingMachine.model.Product;
import org.example.lld.InterviewProblems.VendingMachine.model.Transaction;

public class DispensingState implements VendingMachineState {

	@Override
	public void selectProduct(VendingMachine machine, Product product) {
		System.out.println("Please wait, dispensing in progress");
	}

	@Override
	public void insertMoney(VendingMachine machine, double amount) {
		System.out.println("Please wait, dispensing in progress");
	}

	@Override
	public void dispenseProduct(VendingMachine machine) {
		Product product = machine.getSelectedProduct();
		double paidAmount = machine.getInsertedAmount();

		machine.getPayment().pay(paidAmount);
		machine.getInventory().reduceStock(product);

		double change = paidAmount - product.getPrice();
		System.out.println("Dispensing: " + product.getName());

		Transaction transaction = new Transaction(product, paidAmount, change, "SUCCESS");
		System.out.println(transaction);

		machine.returnChange();
		machine.setState(new IdleState());
	}

	@Override
	public void cancelTransaction(VendingMachine machine) {
		System.out.println("Cannot cancel, dispensing already in progress");
	}
}

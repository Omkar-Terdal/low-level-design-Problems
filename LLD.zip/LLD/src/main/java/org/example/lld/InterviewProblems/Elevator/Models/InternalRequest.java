package org.example.lld.InterviewProblems.Elevator.Models;

public class InternalRequest extends Request {
	private int destinationFloor;

	public InternalRequest(int destinationFloor) {
		this.destinationFloor = destinationFloor;
	}

	public int getDestinationFloor() {
		return destinationFloor;
	}
}

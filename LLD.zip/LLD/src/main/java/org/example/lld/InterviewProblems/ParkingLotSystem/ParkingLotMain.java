package org.example.lld.InterviewProblems.ParkingLotSystem;

import org.example.lld.InterviewProblems.ParkingLotSystem.Enums.VehicelType;
import org.example.lld.InterviewProblems.ParkingLotSystem.Models.*;
import org.example.lld.InterviewProblems.ParkingLotSystem.ParkingStratergy.HourlyPriceStratergy;

import java.util.ArrayList;
import java.util.List;

public class ParkingLotMain {

	public static void main(String[] args) {
		List<ParkingSpots> floor1List = new ArrayList<>();
		floor1List.add(new ParkingSpots(1L, VehicelType.CAR));
		floor1List.add(new ParkingSpots(2L,VehicelType.CAR));
		floor1List.add(new ParkingSpots(3L, VehicelType.BIKE));
		floor1List.add(new ParkingSpots(4L,VehicelType.BIKE));
		floor1List.add(new ParkingSpots(5L, VehicelType.TRUCK));
		floor1List.add(new ParkingSpots(6L,VehicelType.TRUCK));

		List<ParkingSpots> floor2List = new ArrayList<>();
//		floor2List.add(new ParkingSpots(1L, VehicelType.CAR));
//		floor2List.add(new ParkingSpots(2L,VehicelType.CAR));
		floor2List.add(new ParkingSpots(3L, VehicelType.BIKE));
		floor2List.add(new ParkingSpots(4L,VehicelType.BIKE));
		floor2List.add(new ParkingSpots(5L, VehicelType.TRUCK));
		floor2List.add(new ParkingSpots(6L,VehicelType.TRUCK));

		List<ParkingFloors> parkingFloorsList=new ArrayList<>();
		parkingFloorsList.add(new ParkingFloors(1L,floor1List));
		parkingFloorsList.add(new ParkingFloors(2L,floor2List));


		ParkingLot parkingLot = new ParkingLot(parkingFloorsList,new  HourlyPriceStratergy());

		Vehicle car=new Car("KA22ABDC1244");

		ParkingResponse parkingResponse=parkingLot.parkVehicle(car);
		Ticket ticket=parkingResponse.getTicket();
		System.out.println(ticket);
		double amount =parkingLot.exitVehicle(ticket.getTicketId());

		System.out.println("Total parking amount is "+amount);

		Vehicle car2=new Car("KA22ABDC1244");
		Vehicle car3=new Car("KA22ABDC1244");
		Vehicle car4=new Car("KA22ABDC1244");

		System.out.println(parkingLot.parkVehicle(car2));
		System.out.println(parkingLot.parkVehicle(car3));
		System.out.println(parkingLot.parkVehicle(car4));
		parkingLot.displayAvailability();
	}
}

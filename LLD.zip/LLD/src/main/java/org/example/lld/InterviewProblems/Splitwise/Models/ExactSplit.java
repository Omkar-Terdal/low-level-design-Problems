package org.example.lld.InterviewProblems.Splitwise.Models;

public class ExactSplit extends Split {

	public ExactSplit(User user, double amount) {
		super(user,amount);
	}

}

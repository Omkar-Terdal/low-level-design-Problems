package org.example.lld.InterviewProblems.TicTacToe.Models;

import org.example.lld.InterviewProblems.TicTacToe.Enums.PieceType;

public abstract class PlayingPiece {

	private PieceType type;

	public PlayingPiece(PieceType type) {
		this.type = type;
	}

	public PieceType getType() {
		return type;
	}

	public void setType(PieceType type) {
		this.type = type;
	}
}

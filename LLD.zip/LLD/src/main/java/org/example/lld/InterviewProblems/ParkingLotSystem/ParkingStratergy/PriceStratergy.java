package org.example.lld.InterviewProblems.ParkingLotSystem.ParkingStratergy;

import org.example.lld.InterviewProblems.ParkingLotSystem.Models.Ticket;

public interface PriceStratergy {

	double calculatePrice(Ticket ticket);
}

package org.example.lld.DesignPattern.CreationalPattern.AbstractFactoryPattern;

public interface Chair {
	void sitOn();
}

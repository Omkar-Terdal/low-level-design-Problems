package org.example.lld.InterviewProblems.Elevator.Stratergy;

import org.example.lld.InterviewProblems.Elevator.Models.Elevator;
import org.example.lld.InterviewProblems.Elevator.Models.ExternalRequest;
import org.example.lld.InterviewProblems.Elevator.Models.Request;

import java.util.List;

public class NearestElevatorStratergy implements ElevatorStratergy{

	@Override
	public Elevator selectStratergy(List<Elevator> elevators, Request request) {
		Elevator nearestElevator=null;
		int minDistance=Integer.MAX_VALUE;
		for(Elevator e:elevators){
			int distance=Math.abs(e.getCurrentFloor()- ((ExternalRequest)request).getSourceFloor());
			if(distance<minDistance){
				minDistance=distance;
				nearestElevator=e;
			}
		}
		return nearestElevator;
	}
}

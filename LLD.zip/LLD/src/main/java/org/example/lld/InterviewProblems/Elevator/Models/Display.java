package org.example.lld.InterviewProblems.Elevator.Models;

import org.example.lld.InterviewProblems.Elevator.Enums.Direction;

public class Display {
	private int currentFloor;
	private Direction direction;

	public Display() {
		this.currentFloor = 0;
		this.direction = Direction.IDLE;
	}

	public int getCurrentFloor() {
		return currentFloor;
	}

	public void setCurrentFloor(int currentFloor) {
		this.currentFloor = currentFloor;
	}

	public Direction getDirection() {
		return direction;
	}

	public void setDirection(Direction direction) {
		this.direction = direction;
	}

	@Override
	public String toString() {
		return "Display{" +
				"currentFloor=" + currentFloor +
				", direction=" + direction +
				'}';
	}
}

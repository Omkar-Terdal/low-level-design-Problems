package org.example.lld.InterviewProblems.VendingMachine.payment;

public interface Payment {
	void pay(double amount);
	void refund(double amount);
}

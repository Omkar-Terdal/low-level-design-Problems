package org.example.lld.InterviewProblems.BookMyShow.Enums;

public enum SeatType {
	REGULAR,
	PREMIUM,
	VIP
}

package org.example.lld.InterviewProblems.ATM.Models;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class CashDispenser {
	private TreeMap<Integer,Integer> notes;

	public CashDispenser(){
		this.notes = new  TreeMap<>((a, b) -> b - a);
	}


	public void addNotes(int denomination,int amount){
		notes.put(denomination,
				notes.getOrDefault(denomination,0)+amount);
	}

	public boolean canDispense(int amount){
		int remaining =amount;

		for(Map.Entry<Integer,Integer> entry : notes.entrySet()){

			int denomination = entry.getKey();
			int availableNotes = entry.getValue();

			int notesNeeded = remaining/denomination;
			int notesToUse= Math.min(notesNeeded,availableNotes);

			remaining -= notesToUse*denomination;

		}
		return remaining==0;
	}

	public void dispense(int amount){
		if(!canDispense(amount)){
			throw new RuntimeException("Unable to Dispense requested amount");
		}
		int remaining = amount;
		Map<Integer,Integer> dispenseNotes = new HashMap<>();
		for(Map.Entry<Integer,Integer> entry : notes.entrySet()){
			int denomination = entry.getKey();
			int availableNotes = entry.getValue();
			int notesNeeded = remaining/denomination;
			int notesToUse= Math.min(notesNeeded,availableNotes);

			if(notesToUse>0){
				dispenseNotes.put(denomination,notesToUse);
				notes.put(denomination,
						availableNotes-notesToUse);
				remaining -= notesToUse*denomination;
			}

		}
		System.out.println("Successfully dispensed amount: "+amount);

		for(Map.Entry<Integer,Integer> entry : dispenseNotes.entrySet()){
			System.out.println(entry.getKey()+" x  "+entry.getValue());
		}
	}

	public void printAvailableCash(){
		for(Map.Entry<Integer,Integer> entry : notes.entrySet()){
			System.out.println(entry.getKey()+" x  "+entry.getValue());
		}
	}

}
